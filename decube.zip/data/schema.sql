--
-- PostgreSQL database dump
--

\restrict Sa4TXINeqLTEfVhGEz87Xm2nXfFHaOPxmUp90z62dofrmQYP5dxusFUaNUHbNNg

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: prevent_owner_role_change(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.prevent_owner_role_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF OLD.role = 'owner' AND NEW.role <> OLD.role THEN
    RAISE EXCEPTION 'Cannot change role of global owner user (id=%)', OLD.id;
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.prevent_owner_role_change() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    actor_user_id bigint NOT NULL,
    actor_role text NOT NULL,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    meta jsonb,
    changes jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: calendar_days; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.calendar_days (
    date date NOT NULL,
    code smallint NOT NULL,
    is_workday boolean NOT NULL,
    norm_hours numeric(4,1) DEFAULT 0.0 NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.calendar_days OWNER TO planning_user;

--
-- Name: change_log; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.change_log (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    user_id bigint NOT NULL,
    ts text NOT NULL,
    action text NOT NULL,
    details text NOT NULL
);


ALTER TABLE public.change_log OWNER TO planning_user;

--
-- Name: change_log_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.change_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.change_log_id_seq OWNER TO planning_user;

--
-- Name: change_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.change_log_id_seq OWNED BY public.change_log.id;


--
-- Name: employees; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.employees (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    group_code text NOT NULL,
    full_name text NOT NULL,
    active integer DEFAULT 1 NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    tab_no text,
    role text DEFAULT 'viewer'::text NOT NULL,
    birth_date text,
    "position" text,
    email text,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.employees OWNER TO planning_user;

--
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.employees_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO planning_user;

--
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- Name: groups; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    code text NOT NULL,
    title text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_active integer DEFAULT 1 NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text) NOT NULL
);


ALTER TABLE public.groups OWNER TO planning_user;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO planning_user;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: norm_hours; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.norm_hours (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    hours_norm double precision NOT NULL
);


ALTER TABLE public.norm_hours OWNER TO planning_user;

--
-- Name: norm_hours_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.norm_hours_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.norm_hours_id_seq OWNER TO planning_user;

--
-- Name: norm_hours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.norm_hours_id_seq OWNED BY public.norm_hours.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.password_resets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    ip text,
    ua text
);


ALTER TABLE public.password_resets OWNER TO planning_user;

--
-- Name: password_resets_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.password_resets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_resets_id_seq OWNER TO planning_user;

--
-- Name: password_resets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.password_resets_id_seq OWNED BY public.password_resets.id;


--
-- Name: schedule_days; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.schedule_days (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    date text NOT NULL,
    group_code text NOT NULL,
    employee_id bigint NOT NULL,
    status text NOT NULL,
    slots text NOT NULL
);


ALTER TABLE public.schedule_days OWNER TO planning_user;

--
-- Name: schedule_days_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.schedule_days_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.schedule_days_id_seq OWNER TO planning_user;

--
-- Name: schedule_days_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.schedule_days_id_seq OWNED BY public.schedule_days.id;


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.tenants (
    id bigint NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    is_active integer DEFAULT 1 NOT NULL,
    created_at text DEFAULT to_char(now(), 'YYYY-MM-DD HH24:MI:SS'::text) NOT NULL,
    join_code text
);


ALTER TABLE public.tenants OWNER TO planning_user;

--
-- Name: tenants_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.tenants_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_id_seq OWNER TO planning_user;

--
-- Name: tenants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.tenants_id_seq OWNED BY public.tenants.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: planning_user
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL,
    employee_id bigint,
    email text
);


ALTER TABLE public.users OWNER TO planning_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: planning_user
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO planning_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: planning_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: change_log id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.change_log ALTER COLUMN id SET DEFAULT nextval('public.change_log_id_seq'::regclass);


--
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: norm_hours id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.norm_hours ALTER COLUMN id SET DEFAULT nextval('public.norm_hours_id_seq'::regclass);


--
-- Name: password_resets id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.password_resets ALTER COLUMN id SET DEFAULT nextval('public.password_resets_id_seq'::regclass);


--
-- Name: schedule_days id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.schedule_days ALTER COLUMN id SET DEFAULT nextval('public.schedule_days_id_seq'::regclass);


--
-- Name: tenants id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.tenants ALTER COLUMN id SET DEFAULT nextval('public.tenants_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: calendar_days calendar_days_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.calendar_days
    ADD CONSTRAINT calendar_days_pkey PRIMARY KEY (date);


--
-- Name: change_log change_log_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.change_log
    ADD CONSTRAINT change_log_pkey PRIMARY KEY (id);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: groups groups_tenant_id_code_key; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_tenant_id_code_key UNIQUE (tenant_id, code);


--
-- Name: norm_hours norm_hours_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.norm_hours
    ADD CONSTRAINT norm_hours_pkey PRIMARY KEY (id);


--
-- Name: norm_hours norm_hours_tenant_id_year_month_key; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.norm_hours
    ADD CONSTRAINT norm_hours_tenant_id_year_month_key UNIQUE (tenant_id, year, month);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: schedule_days schedule_days_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.schedule_days
    ADD CONSTRAINT schedule_days_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_code_key; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_code_key UNIQUE (code);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_actor_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_actor_time ON public.audit_log USING btree (tenant_id, actor_user_id, created_at DESC);


--
-- Name: idx_audit_tenant_action_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_tenant_action_time ON public.audit_log USING btree (tenant_id, action, created_at DESC);


--
-- Name: idx_audit_tenant_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_tenant_time ON public.audit_log USING btree (tenant_id, created_at DESC);


--
-- Name: idx_calendar_days_month; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_calendar_days_month ON public.calendar_days USING btree (date);


--
-- Name: idx_emp_tenant_birth; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_emp_tenant_birth ON public.employees USING btree (tenant_id, birth_date);


--
-- Name: idx_emp_tenant_tabno; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_emp_tenant_tabno ON public.employees USING btree (tenant_id, tab_no);


--
-- Name: idx_employees_tenant_group; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_employees_tenant_group ON public.employees USING btree (tenant_id, group_code);


--
-- Name: idx_groups_tenant; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_groups_tenant ON public.groups USING btree (tenant_id);


--
-- Name: idx_groups_tenant_code; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_groups_tenant_code ON public.groups USING btree (tenant_id, code);


--
-- Name: idx_log_tenant_ts; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_log_tenant_ts ON public.change_log USING btree (tenant_id, ts);


--
-- Name: idx_password_resets_expires; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_password_resets_expires ON public.password_resets USING btree (expires_at);


--
-- Name: idx_password_resets_expires_at; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_password_resets_expires_at ON public.password_resets USING btree (expires_at);


--
-- Name: idx_password_resets_token_hash; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_password_resets_token_hash ON public.password_resets USING btree (token_hash);


--
-- Name: idx_password_resets_used_at; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_password_resets_used_at ON public.password_resets USING btree (used_at);


--
-- Name: idx_password_resets_user_id; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_password_resets_user_id ON public.password_resets USING btree (user_id);


--
-- Name: idx_sched; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_sched ON public.schedule_days USING btree (tenant_id, date, group_code, employee_id);


--
-- Name: idx_sched_tenant_group_date; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE INDEX idx_sched_tenant_group_date ON public.schedule_days USING btree (tenant_id, group_code, date);


--
-- Name: idx_sched_unique; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_sched_unique ON public.schedule_days USING btree (tenant_id, date, group_code, employee_id);


--
-- Name: idx_tenants_join_code; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_tenants_join_code ON public.tenants USING btree (join_code);


--
-- Name: idx_users_tenant_email; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_users_tenant_email ON public.users USING btree (tenant_id, email);


--
-- Name: idx_users_tenant_username; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX idx_users_tenant_username ON public.users USING btree (tenant_id, username);


--
-- Name: uniq_users_username; Type: INDEX; Schema: public; Owner: planning_user
--

CREATE UNIQUE INDEX uniq_users_username ON public.users USING btree (username);


--
-- Name: users trg_prevent_owner_role_change; Type: TRIGGER; Schema: public; Owner: planning_user
--

CREATE TRIGGER trg_prevent_owner_role_change BEFORE UPDATE OF role ON public.users FOR EACH ROW EXECUTE FUNCTION public.prevent_owner_role_change();


--
-- Name: audit_log audit_log_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id);


--
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: change_log change_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.change_log
    ADD CONSTRAINT change_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: change_log change_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.change_log
    ADD CONSTRAINT change_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: employees employees_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: groups groups_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: norm_hours norm_hours_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.norm_hours
    ADD CONSTRAINT norm_hours_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: password_resets password_resets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: schedule_days schedule_days_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.schedule_days
    ADD CONSTRAINT schedule_days_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: schedule_days schedule_days_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.schedule_days
    ADD CONSTRAINT schedule_days_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: users users_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id);


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: planning_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO planning_user;


--
-- Name: TABLE audit_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_log TO planning_user;


--
-- Name: SEQUENCE audit_log_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.audit_log_id_seq TO planning_user;


--
-- PostgreSQL database dump complete
--

\unrestrict Sa4TXINeqLTEfVhGEz87Xm2nXfFHaOPxmUp90z62dofrmQYP5dxusFUaNUHbNNg

