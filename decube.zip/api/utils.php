<?php
// api/utils.php

declare(strict_types=1);

function json_response(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function get_weekday_name(string $dateStr): string {
    $dt = new DateTime($dateStr);
    $day = (int)$dt->format('w'); // 0=Вс .. 6=Сб
    $names = ['Воскресенье','Понедельник','Вторник','Среда','Четверг','Пятница','Суббота'];
    return $names[$day] ?? '';
}

function get_weekday_short(string $dateStr): string {
    $dt = new DateTime($dateStr);
    $day = (int)$dt->format('w'); // 0=Вс .. 6=Сб
    $names = ['Вс','Пн','Вт','Ср','Чт','Пт','Сб'];
    return $names[$day] ?? '';
}

function get_month_name(int $month): string {
    $names = [
        1 => 'Январь', 2 => 'Февраль', 3 => 'Март', 4 => 'Апрель',
        5 => 'Май', 6 => 'Июнь', 7 => 'Июль', 8 => 'Август',
        9 => 'Сентябрь', 10 => 'Октябрь', 11 => 'Ноябрь', 12 => 'Декабрь'
    ];
    return $names[$month] ?? '';
}

/**
 * ISO-недели (как в DateTime::setISODate): Пн–Вс, 1..52/53.
 * label: "N (Пн dd.mm - Вс dd.mm)"
 */
function get_week_list_for_year(int $year): array {
    $weeks = [];

    // ISO неделя 1 — та, что содержит 4 января
    $dt = new DateTime();
    $dt->setISODate($year, 1);
    $firstMon = clone $dt;

    // max weeks: неделя, в которую попадает 28 декабря (ISO правило)
    $dtMax = new DateTime();
    $dtMax->setDate($year, 12, 28);
    $maxWeek = (int)$dtMax->format('W');

    for ($w = 1; $w <= $maxWeek; $w++) {
        $d = new DateTime();
        $d->setISODate($year, $w);
        $start = $d->format('Y-m-d');
        $end = (clone $d)->modify('+6 days')->format('Y-m-d');

        $label = $w . ' (Пн ' . (new DateTime($start))->format('d.m') . ' - Вс ' . (new DateTime($end))->format('d.m') . ')';

        $weeks[] = [
            'index' => $w,
            'start' => $start,
            'end'   => $end,
            'label' => $label,
        ];
    }

    return $weeks;
}

/** Возвращает [start,end] ISO-недели или null */
function get_week_range(int $year, int $weekIndex): ?array {
    if ($year <= 0 || $weekIndex <= 0) return null;

    $dtMax = new DateTime();
    $dtMax->setDate($year, 12, 28);
    $maxWeek = (int)$dtMax->format('W');
    if ($weekIndex > $maxWeek) return null;

    $d = new DateTime();
    $d->setISODate($year, $weekIndex);
    $start = $d->format('Y-m-d');
    $end = (clone $d)->modify('+6 days')->format('Y-m-d');

    return [$start, $end];
}

/**
 * Подсчёт часов по слотам:
 * статус 'Я' или 'РВ' -> кол-во '1' * 0.5
 */
function count_hours_from_slots(string $status, string $slots): float {
    if ($status !== 'Я' && $status !== 'РВ') return 0.0;

    $count = 0;
    $len = strlen($slots);
    for ($i = 0; $i < $len; $i++) {
        if ($slots[$i] === '1') $count++;
    }
    return $count * 0.5;
}

function is_weekend(string $dateStr): bool {
    $dt = new DateTime($dateStr);
    $w = (int)$dt->format('w'); // 0=Вс, 6=Сб
    return $w === 0 || $w === 6;
}

function get_extra_holidays_2026(): array {
    return [
        '2026-01-01','2026-01-02','2026-01-05','2026-01-06','2026-01-07','2026-01-08','2026-01-09',
        '2026-02-23','2026-03-09','2026-05-01','2026-05-11','2026-06-12','2026-11-04','2026-12-31',
    ];
}

function is_extra_holiday(string $dateStr): bool {
    $year = (int)substr($dateStr, 0, 4);
    if ($year === 2026) {
        return in_array($dateStr, get_extra_holidays_2026(), true);
    }
    return false;
}

function is_holiday_any(string $dateStr): bool {
    return is_weekend($dateStr) || is_extra_holiday($dateStr);
}


// ===== DB helpers (PG migration safe) =====

/**
 * Return column data_type from information_schema (cached per request).
 * @return string|null e.g. 'boolean', 'integer', 'text'
 */
function column_data_type(PDO $pdo, string $table, string $column): ?string
{
    static $cache = [];
    $k = $table . '.' . $column;
    if (array_key_exists($k, $cache)) return $cache[$k];

    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public'
              AND table_name = :t
              AND column_name = :c
            LIMIT 1
        ");
        $st->execute([':t' => $table, ':c' => $column]);
        $dt = strtolower((string)($st->fetchColumn() ?: ''));
        $cache[$k] = ($dt !== '') ? $dt : null;
        return $cache[$k];
    } catch (Throwable $e) {
        $cache[$k] = null;
        return null;
    }
}

/**
 * Build SQL snippet for "active" filtering that works with boolean or int flags.
 * Example return: ' AND is_active = TRUE' or ' AND is_active = 1' or '' (unknown type).
 */
function active_where(PDO $pdo, string $table, string $column = 'is_active'): string
{
    $dt = column_data_type($pdo, $table, $column);
    if ($dt === 'boolean') return " AND {$column} = TRUE";
    if ($dt !== null) return " AND {$column} = 1";
    return '';
}

/**
 * Safe boolean interpretation for PDO values (pgsql often returns 't'/'f').
 */
function db_bool(mixed $v, bool $default = false): bool
{
    if ($v === null) return $default;
    if (is_bool($v)) return $v;
    if (is_int($v)) return $v !== 0;
    $s = strtolower(trim((string)$v));
    if ($s === '') return $default;
    return in_array($s, ['1','t','true','yes','y','on'], true);
}

