<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/security.php';
if (function_exists('require_same_origin')) require_same_origin();

try {
    $ctx = require __DIR__ . '/guard.php';
} catch (Throwable $e) {
    http_response_code(401);
    echo json_encode(['error'=>'unauthorized'], JSON_UNESCAPED_UNICODE);
    exit;
}

$pdo = $ctx['pdo'] ?? null;
$tid = (int)($ctx['tid'] ?? 0);

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if (!($pdo instanceof PDO) || $tid <= 0) json_out(['error'=>'ctx_failed'], 500);

$date = isset($_GET['date']) ? (string)$_GET['date'] : '';
if (!preg_match('~^\d{4}-\d{2}-\d{2}$~', $date)) json_out(['error'=>'bad_date'], 400);

const STATUSES = ['Я','РВ','РВ1'];

/* ===== helpers ===== */

function parse_slots_to_bools(string $slotsRaw): array {
    $s = trim($slotsRaw);
    if ($s === '') return [];

    if ($s[0] === '[' || $s[0] === '{') {
        $j = json_decode($s, true);
        if (is_array($j)) {
            return array_map(fn($v) => ($v==1 || $v==='1' || $v===true), $j);
        }
    }

    if (preg_match('~^[01]+$~', $s)) {
        return array_map(fn($c)=>$c==='1', str_split($s));
    }

    if (strpos($s, ',') !== false) {
        return array_map(fn($v)=>($v==='1'||$v==='true'), array_map('trim', explode(',', $s)));
    }

    preg_match_all('~[01]~', $s, $m);
    return array_map(fn($c)=>$c==='1', $m[0] ?? []);
}

function calc_day_hours(array $bools): float {
    return count(array_filter($bools)) * 0.5;
}

/** Рендер только клеток */
function render_slots_cells(array $bools): string {
    if (!$bools) return '';

    $n = count($bools);
    if ($n % 2 !== 0) $n--;

    // title 06:00, 06:30...
    $labels = [];
    $h=6; $m=0;
    for ($i=0; $i<$n; $i++){
        $labels[] = sprintf('%02d:%02d', $h, $m);
        $m += 30;
        if ($m >= 60) { $m = 0; $h = ($h + 1) % 24; }
    }

    // ВАЖНО: ds- классы (чтобы не конфликтовало с недельным расписанием)
    $html = '<div class="ds-line ds-line--cells"><div class="ds-hourboxes">';

    for ($hour = 0; $hour < 24; $hour++) {
        $i0 = $hour * 2;
        $i1 = $i0 + 1;

        $w0 = !empty($bools[$i0]);
        $w1 = !empty($bools[$i1]);

        $t0 = htmlspecialchars($labels[$i0] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $t1 = htmlspecialchars($labels[$i1] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        $html .= '<div class="ds-hourbox">';
        $html .= '<span class="ds-cell'.($w0?' is-work':'').'" title="'.$t0.'"></span>';
        $html .= '<span class="ds-cell'.($w1?' is-work':'').'" title="'.$t1.'"></span>';
        $html .= '</div>';
    }

    $html .= '</div></div>';
    return $html;
}



/* ===== SQL ===== */

$pgArray = '{' . implode(',', array_map(fn($x)=>'"'.$x.'"', STATUSES)) . '}';

$st = $pdo->prepare("
  SELECT
    d.employee_id,
    d.group_code,
    d.status,
    d.slots,
    e.full_name,
    e.sort_order,
    g.sort_order AS g_sort,
    g.title AS group_title
  FROM schedule_days d
  JOIN employees e ON e.id = d.employee_id
  JOIN groups g ON g.tenant_id = d.tenant_id AND g.code = d.group_code
  WHERE d.tenant_id = :tid
    AND d.date = :d
    AND d.status = ANY(:statuses)
    AND COALESCE(e.is_active,true)=true
    AND COALESCE(e.active,1)=1
    AND COALESCE(g.is_active,1)=1
  ORDER BY g.sort_order, g.title, e.sort_order, e.full_name
");

$st->bindValue(':tid',$tid,PDO::PARAM_INT);
$st->bindValue(':d',$date,PDO::PARAM_STR);
$st->bindValue(':statuses',$pgArray,PDO::PARAM_STR);
$st->execute();

$rows = [];
while($r=$st->fetch(PDO::FETCH_ASSOC)){
    $b = parse_slots_to_bools((string)($r['slots'] ?? ''));
    $rows[] = [
        'employee_id'=>(int)$r['employee_id'],
        'group_code'=>(string)$r['group_code'],
        'group_title'=>(string)($r['group_title'] ?? ''),
        'name'=>(string)$r['full_name'],
        'status'=>(string)$r['status'],
        'day_hours'=>calc_day_hours($b),
        'time_html'=>render_slots_cells($b),
    ];
}

json_out(['date'=>$date,'rows'=>$rows]);
