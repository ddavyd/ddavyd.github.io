<?php
// api/rate_limit.php — простой rate-limit без миграций (файловое хранилище)
// Подходит как быстрый hotfix. Для кластера/нескольких серверов лучше вынести в БД/Redis.

declare(strict_types=1);

function rl_path(string $key): string
{
    return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
        . DIRECTORY_SEPARATOR
        . 'planning_rl_' . sha1($key) . '.json';
}

/**
 * @return array{ok:bool, reset:int, count:int}
 */
function rl_check(string $key, int $limit, int $windowSec): array
{
    $path = rl_path($key);
    $now  = time();

    $fp = @fopen($path, 'c+');
    if (!$fp) {
        // fail-open, чтобы не положить логин, если tmp недоступен
        return ['ok' => true, 'reset' => $now + $windowSec, 'count' => 0];
    }

    @flock($fp, LOCK_EX);

    $raw = stream_get_contents($fp);
    $data = [];
    if (is_string($raw) && $raw !== '') {
        $tmp = json_decode($raw, true);
        if (is_array($tmp)) $data = $tmp;
    }

    $reset = (int)($data['reset'] ?? 0);
    $count = (int)($data['count'] ?? 0);

    if ($reset <= $now) {
        $reset = $now + $windowSec;
        $count = 0;
    }

    $count++;

    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, json_encode(['reset' => $reset, 'count' => $count], JSON_UNESCAPED_UNICODE));

    @flock($fp, LOCK_UN);
    fclose($fp);

    return ['ok' => ($count <= $limit), 'reset' => $reset, 'count' => $count];
}

function rl_429(array $state): void
{
    $reset = (int)($state['reset'] ?? 0);
    $retryAfter = max(1, $reset - time());

    http_response_code(429);
    header('Content-Type: application/json; charset=utf-8');
    header('Retry-After: ' . $retryAfter);
    echo json_encode(['error' => 'too_many_requests'], JSON_UNESCAPED_UNICODE);
    exit;
}
