<?php
// api/smtp_config.php
declare(strict_types=1);

return [
    'host' => 'mail.planning646.ru',
    'port' => 587,
    'starttls' => true,

    'username' => 'no-reply@planning646.ru',
    'password' => '1029384756*QaZ',

    'from_email' => 'no-reply@planning646.ru',
    'from_name'  => 'Planning646',
    'reply_to'   => 'no-reply@planning646.ru',

    // имя для EHLO
    'ehlo' => 'mail.planning646.ru',
];
