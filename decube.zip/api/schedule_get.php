<?php
// api/schedule_get.php — стабильная версия (PG) анти-502: JSON на фаталах + statement_timeout + быстрее сборка
// FIX: кэш больше НЕ в /tmp (permission denied на хостинге). Кэшируем в /data/cache внутри проекта.

declare(strict_types=1);

// warnings/notices -> exceptions (чтобы не превращались в непонятные 502)
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

// фаталы тоже в JSON (иначе nginx/php-fpm отдаёт 502 и пусто)
register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'error' => 'fatal',
        'details' => ($e['message'] ?? 'unknown') . ' @ ' . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
});

require_once __DIR__ . '/security.php';
require_same_origin();
require_once __DIR__ . '/utils.php';

try {
    $ctx = require __DIR__ . '/guard.php';

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];

// --- employees.is_active filter (boolean/int/missing) ---
function employees_active_expr(PDO $pdo, string $alias = ''): string {
    $p = $alias !== '' ? $alias . '.' : '';
    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='employees' AND column_name='is_active'
            LIMIT 1
        ");
        $st->execute();
        $t = strtolower((string)($st->fetchColumn() ?: ''));
        if ($t === 'boolean') return "(COALESCE({$p}is_active, TRUE) = TRUE)";
        if ($t !== '')        return "(COALESCE({$p}is_active, 1)::int <> 0)";
    } catch (Throwable $e) {}
    return "1=1"; // если колонки нет — считаем всех активными
}
$EMP_ACTIVE0 = employees_active_expr($pdo, '');

    $role = strtolower(trim((string)($ctx['role'] ?? '')));
    $tid  = (int)($ctx['tid'] ?? 0);

    // не даём запросам зависать и выбивать 502 по таймауту прокси
    try { $pdo->exec("SET statement_timeout TO 8000"); } catch (Throwable $ignore) {}

    $group = trim((string)($_GET['group'] ?? ''));
    $year  = (int)($_GET['year'] ?? 0);
    $week  = (int)($_GET['week'] ?? 0);

    if ($group === '' || $year < 2000 || $year > 2100 || $week < 1 || $week > 53) {
        http_response_code(400);
        json_response(['error' => 'missing_parameters']);
        exit;
    }

    // ограничения по группе: только для admin/viewer
    $scopeGroup = trim((string)($ctx['scopeGroup'] ?? ''));
    if (in_array($role, ['admin', 'viewer'], true)) {
        if ($scopeGroup !== '' && $group !== $scopeGroup) {
            http_response_code(403);
            json_response(['error' => 'forbidden']);
            exit;
        }
    }

    // диапазон дат недели (ISO)
    $dt = (new DateTimeImmutable('now'))->setISODate($year, $week);
    $start = $dt->format('Y-m-d');
    $end   = $dt->modify('+6 days')->format('Y-m-d');

    // ===== микро-кэш (FIX: не /tmp, а /data/cache)
    $cacheTtl  = 0;
    $cacheKey  = sha1("sched|tid={$tid}|g={$group}|y={$year}|w={$week}|{$start}|{$end}");

    $cacheDir = realpath(__DIR__ . '/../data');
    if ($cacheDir === false) {
        $cacheDir = __DIR__ . '/../data';
    }
    $cacheDir .= '/cache';

    // создаём папку кэша если её нет (без фаталов)
    if (!is_dir($cacheDir)) {
        @mkdir($cacheDir, 0775, true);
    }

    $cacheFile = $cacheDir . "/planning_cache_{$cacheKey}.json";

    if (is_file($cacheFile)) {
        $age = time() - (int)@filemtime($cacheFile);
        if ($age >= 0 && $age <= $cacheTtl) {
            $raw = @file_get_contents($cacheFile);
            if (is_string($raw) && $raw !== '') {
                header('Content-Type: application/json; charset=utf-8');
                echo $raw;
                exit;
            }
        }
    }

    $weekdayNames = [
        1 => 'Понедельник', 2 => 'Вторник', 3 => 'Среда', 4 => 'Четверг',
        5 => 'Пятница', 6 => 'Суббота', 7 => 'Воскресенье',
    ];

    $zero48 = str_repeat('0', 48);

    // 1) сотрудники группы (лимит защитный, чтобы случайно не положить сервер)
    $maxEmployees = 600; // если у тебя реально больше — скажи, поднимем и будем оптимизировать дальше
    $st = $pdo->prepare('
        SELECT id, full_name
        FROM employees
        WHERE tenant_id = :tid AND ' . $EMP_ACTIVE0 . ' AND group_code = :g
        ORDER BY full_name
        LIMIT ' . (int)$maxEmployees . '
    ');
    $st->execute([':tid' => $tid, ':g' => $group]);
    $emps = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    // быстрые массивы без лишних аллокаций
    $empIds = [];
    $empNamesById = [];
    foreach ($emps as $e) {
        $eid = (int)($e['id'] ?? 0);
        if ($eid <= 0) continue;
        $empIds[] = $eid;
        $empNamesById[$eid] = (string)($e['full_name'] ?? '');
    }

    // если сотрудников нет — всё равно возвращаем 7 дней, но пустых
    if (!$empIds) {
        $outDays = [];
        $cur = new DateTimeImmutable($start);
        for ($i = 0; $i < 7; $i++) {
            $d = $cur->format('Y-m-d');
            $n = (int)$cur->format('N');
            $outDays[] = ['date' => $d, 'weekday' => $weekdayNames[$n] ?? (string)$n, 'employees' => []];
            $cur = $cur->modify('+1 day');
        }

        $payload = ['group'=>$group,'year'=>$year,'week'=>$week,'start'=>$start,'end'=>$end,'days'=>$outDays];
        $json = json_encode($payload, JSON_UNESCAPED_UNICODE);

        if (is_string($json) && $json !== '') {
            @file_put_contents($cacheFile, $json, LOCK_EX);
            header('Content-Type: application/json; charset=utf-8');
            echo $json;
            exit;
        }

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($payload, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 2) расписание за неделю
    // ВАЖНО: фильтруем employee_id по списку сотрудников группы, чтобы не тянуть лишнее.
    // В PDO нормально передать int[] нельзя, поэтому делаем через string_to_array.
    $st = $pdo->prepare('
        SELECT date::text AS d, employee_id, status, slots
        FROM schedule_days
        WHERE tenant_id = :tid
          AND group_code = :g
          AND date BETWEEN :d1 AND :d2
          AND employee_id = ANY(string_to_array(:eids, \',\')::int[])
    ');
    $st->execute([
        ':tid'  => $tid,
        ':g'    => $group,
        ':d1'   => $start,
        ':d2'   => $end,
        ':eids' => implode(',', $empIds),
    ]);

    // sched[date][eid] = [status,slots]
    $sched = [];
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $d   = (string)($r['d'] ?? '');
        $eid = (int)($r['employee_id'] ?? 0);
        if ($d === '' || $eid <= 0) continue;

        $sched[$d][$eid] = [
            'status' => (string)($r['status'] ?? 'В'),
            'slots'  => (string)($r['slots'] ?? $zero48),
        ];
    }

    // 3) собрать 7 дней
    $outDays = [];
    $cur = new DateTimeImmutable($start);

    for ($i = 0; $i < 7; $i++) {
        $d = $cur->format('Y-m-d');
        $n = (int)$cur->format('N');

        $dayEmployees = [];
        $dayMap = $sched[$d] ?? null;

        foreach ($empIds as $eid) {
            $row = ($dayMap && isset($dayMap[$eid])) ? $dayMap[$eid] : null;
            $dayEmployees[] = [
                'employee_id' => $eid,
                'name'        => $empNamesById[$eid] ?? '',
                'status'      => $row['status'] ?? 'В',
                'slots'       => $row['slots']  ?? $zero48,
            ];
        }

        $outDays[] = [
            'date'      => $d,
            'weekday'   => $weekdayNames[$n] ?? (string)$n,
            'employees' => $dayEmployees,
        ];

        $cur = $cur->modify('+1 day');
    }

    $payload = [
        'group' => $group,
        'year'  => $year,
        'week'  => $week,
        'start' => $start,
        'end'   => $end,
        'days'  => $outDays,
    ];

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if (is_string($json) && $json !== '') {
        @file_put_contents($cacheFile, $json, LOCK_EX);
        header('Content-Type: application/json; charset=utf-8');
        echo $json;
        exit;
    }

    json_response($payload);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    json_response(['error' => 'schedule_get_failed', 'details' => $e->getMessage()]);
    exit;
}
