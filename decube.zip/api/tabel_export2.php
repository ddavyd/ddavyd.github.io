<?php
// api/tabel_export2.php
// Вариант экспорта: в строке "статусов" для Я/РВ/РВ1 подставляем диапазон часов "HH-HH" (или "H:30") по слотам.
// ИТОГОВЫЕ СТОЛБЦЫ (Норма/Факт/РВ/Разница) И НИЖНИЕ ИТОГИ — НЕ выводим.

declare(strict_types=1);

require_once __DIR__ . '/security.php';
require_same_origin();

$ctx = require __DIR__ . '/guard.php';
$pdo  = $ctx['pdo'];

// --- employees.is_active filter (boolean/int/missing) ---
function employees_active_expr(PDO $pdo, string $alias = ''): string {
    $p = $alias !== '' ? $alias . '.' : '';
    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='employees' AND column_name='is_active'
            LIMIT 1
        ");
        $st->execute();
        $t = strtolower((string)($st->fetchColumn() ?: ''));
        if ($t === 'boolean') return "(COALESCE({$p}is_active, TRUE) = TRUE)";
        if ($t !== '')        return "(COALESCE({$p}is_active, 1)::int <> 0)";
    } catch (Throwable $e) {}
    return "1=1";
}
$EMP_ACTIVE0 = employees_active_expr($pdo, '');

$role = $ctx['role'];
$tid  = $ctx['tid'];

if ($role === 'viewer') {
    http_response_code(403);
    exit('read_only');
}

require_once __DIR__ . '/utils.php';

$requestedGroup = trim((string)($_GET['group'] ?? ''));
$year  = (int)($_GET['year'] ?? 0);
$month = (int)($_GET['month'] ?? 0);

if ($year <= 0 || $month < 1 || $month > 12) {
    http_response_code(400);
    exit('bad_params');
}

$scopeGroup = $ctx['scopeGroup'] ?? '';
$exportAll = false;
$group = '';

if (in_array($role, ['owner', 'tenant_admin'], true)) {
    if ($requestedGroup === '' || $requestedGroup === 'all') $exportAll = true;
    else $group = $requestedGroup;
} elseif ($role === 'admin') {
    if ($scopeGroup === '') {
        http_response_code(403);
        exit('no_group_scope');
    }
    $group = $scopeGroup;
} else {
    http_response_code(403);
    exit('no_permission');
}

function pad2(int $n): string { return str_pad((string)$n, 2, '0', STR_PAD_LEFT); }

// формат времени для экспорта: "13" если :00, иначе "13:30"
function fmt_time_short(int $minutes): string {
    $minutes = $minutes % (24 * 60);
    if ($minutes < 0) $minutes += 24 * 60;
    $h = intdiv($minutes, 60);
    $m = $minutes % 60;
    if ($m === 0) return (string)$h;
    return $h . ':' . pad2($m);
}

// слоты 48 по 30 мин: 06:00..05:30. Возвращаем "start-end" по первому/последнему активному слоту.
function slots_to_range(string $slots): string {
    $len = strlen($slots);
    if ($len <= 0) return '';
    $first = -1;
    $last  = -1;
    for ($i = 0; $i < $len; $i++) {
        if ($slots[$i] === '1') {
            if ($first < 0) $first = $i;
            $last = $i;
        }
    }
    if ($first < 0 || $last < 0) return '';

    // базовая ось: 06:00 + index*30
    $startMin = 6 * 60 + $first * 30;
    $endMin   = 6 * 60 + ($last + 1) * 30;

    // на всякий случай (если вдруг пересечение суток) — оставляем как HH(:MM) по модулю 24ч
    $s = fmt_time_short($startMin);
    $e = fmt_time_short($endMin);

    return $s . '-' . $e;
}

$start = new DateTime(sprintf('%04d-%02d-01', $year, $month));
$end   = (clone $start)->modify('last day of this month');

// дни месяца
$days = [];
$cursor = clone $start;
while ($cursor <= $end) {
    $dateStr = $cursor->format('Y-m-d');
    $days[] = [
        'date'    => $dateStr,
        'weekday' => get_weekday_short($dateStr) ?: get_weekday_name($dateStr),
    ];
    $cursor->modify('+1 day');
}

// сотрудники
if ($exportAll) {
    $sql = "SELECT id, full_name, group_code FROM employees WHERE tenant_id = :tid AND " . $EMP_ACTIVE0 . " ORDER BY group_code, full_name";
    $st = $pdo->prepare($sql);
    $st->execute([':tid' => $tid]);
} else {
    $sql = "SELECT id, full_name, group_code FROM employees WHERE tenant_id = :tid AND " . $EMP_ACTIVE0 . " AND group_code = :g ORDER BY full_name";
    $st = $pdo->prepare($sql);
    $st->execute([':tid' => $tid, ':g' => $group]);
}
$employees = $st->fetchAll(PDO::FETCH_ASSOC);

// порядок как был
$fixedOrder = [
    'Давыдов Д.',
    'Ионова Е.',
    'Побединская Е.',
    'Марчишак В.',
    'Хабибрахманова В.',
    'Бехтер М.',
    'Беляев Д.',
    'Хомиченко В.',
    'Наринян А.',
    'Григоренко М.',
    'Бойченко Ю.',
    'Беляева М.',
    'Чаплыгина Э.',
];
$orderIndex = [];
foreach ($fixedOrder as $idx => $name) $orderIndex[$name] = $idx;

usort($employees, function($a, $b) use ($orderIndex) {
    $aName = $a['full_name'] ?? '';
    $bName = $b['full_name'] ?? '';
    $aHas = array_key_exists($aName, $orderIndex);
    $bHas = array_key_exists($bName, $orderIndex);
    if ($aHas && $bHas) return $orderIndex[$aName] <=> $orderIndex[$bName];
    if ($aHas && !$bHas) return -1;
    if ($bHas && !$aHas) return 1;
    return strcmp($aName, $bName);
});

// расписание
if ($exportAll) {
    $st2 = $pdo->prepare("SELECT * FROM schedule_days WHERE tenant_id = :tid AND date BETWEEN :s AND :e");
    $st2->execute([':tid' => $tid, ':s' => $start->format('Y-m-d'), ':e' => $end->format('Y-m-d')]);
} else {
    $st2 = $pdo->prepare("SELECT * FROM schedule_days WHERE tenant_id = :tid AND group_code = :g AND date BETWEEN :s AND :e");
    $st2->execute([':tid' => $tid, ':g' => $group, ':s' => $start->format('Y-m-d'), ':e' => $end->format('Y-m-d')]);
}
$rows = $st2->fetchAll(PDO::FETCH_ASSOC);

$byEmpDate = [];
foreach ($rows as $r) {
    $byEmpDate[(int)$r['employee_id'] . '_' . (string)$r['date']] = $r;
}

$monthName = get_month_name($month);

$fnameScope = $exportAll ? "all" : preg_replace('/[^a-zA-Z0-9_\-]/', '_', $group);

header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"tabel2_{$fnameScope}_{$year}_{$month}.xls\"");

$titleScope = $exportAll ? "все группы" : "группа " . $group;

echo "<html><head><meta charset='utf-8'></head><body>";
echo "<h3>Табель рабочего времени — {$titleScope} — {$monthName} {$year}</h3>";
echo "<table border='1' cellspacing='0' cellpadding='3'>";

// шапка дат
echo "<tr><th>Сотрудник / Дата</th>";
foreach ($days as $d) echo "<th>" . (new DateTime($d['date']))->format('d') . "</th>";
echo "</tr>";

// шапка дней недели
echo "<tr><th>День недели</th>";
foreach ($days as $d) echo "<th>" . htmlspecialchars($d['weekday'], ENT_QUOTES, 'UTF-8') . "</th>";
echo "</tr>";

foreach ($employees as $e) {
    $dayStatuses = [];
    $dayHours = [];
    $dayStyles = [];

    foreach ($days as $d) {
        $key = (int)$e['id'] . '_' . $d['date'];
        $status = 'В';
        $hours = 0.0;
        $slots = '';

        if (isset($byEmpDate[$key])) {
            $row = $byEmpDate[$key];
            $status = (string)$row['status'];
            $slots  = (string)$row['slots'];

            $rawCount = 0;
            $len = strlen($slots);
            for ($i = 0; $i < $len; $i++) if ($slots[$i] === '1') $rawCount++;
            $rawHours = $rawCount * 0.5;

            if ($status === 'Я' || $status === 'РВ' || $status === 'РВ1') $hours = $rawHours;
        }

        // фон как раньше (под статус)
        $bg = '';
        if ($status === 'В') $bg = '#e5e7eb';
        elseif ($status === 'ОТ') $bg = '#dbeafe';
        elseif ($status === 'РВ' || $status === 'РВ1') $bg = '#fecaca';
        elseif ($status === 'НН') $bg = '#fef3c7';
        elseif ($status === 'Б') $bg = '#e0f2fe';
        elseif ($status === 'ОВ') $bg = '#e0e7ff';

        // ПОДМЕНА "статуса" на диапазон для Я/РВ/РВ1
        $cellText = $status;
        if ($status === 'Я' || $status === 'РВ' || $status === 'РВ1') {
            $range = slots_to_range($slots);
            if ($range !== '') $cellText = $range; // иначе оставим как есть (например если слотов нет)
        }

        $dayStatuses[] = $cellText;
        $dayHours[] = $hours;
        $dayStyles[] = $bg ? " style='background:{$bg}'" : "";
    }

    $nameEsc = htmlspecialchars((string)$e['full_name'], ENT_QUOTES, 'UTF-8');

    // 1-я строка: "статусы" (с подменой)
    echo "<tr>";
    echo "<td rowspan='2'><strong>{$nameEsc}</strong></td>";
    foreach ($dayStatuses as $i => $stText) {
        $style = $dayStyles[$i];
        echo "<td{$style}>" . htmlspecialchars((string)$stText, ENT_QUOTES, 'UTF-8') . "</td>";
    }
    echo "</tr>";

    // 2-я строка: часы (как было)
    echo "<tr>";
    foreach ($dayHours as $i => $h) {
        $style = $dayStyles[$i];
        echo "<td{$style}>" . number_format((float)$h, 1, ',', '') . "</td>";
    }
    echo "</tr>";
}

echo "</table></body></html>";
exit;
