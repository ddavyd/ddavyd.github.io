<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$verFile = __DIR__ . '/../version.txt';
$ver = '0';

if (is_file($verFile)) {
    $ver = trim((string)file_get_contents($verFile));
    if ($ver === '') $ver = '0';
}

echo json_encode(['version' => $ver], JSON_UNESCAPED_UNICODE);
