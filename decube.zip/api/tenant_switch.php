<?php
// api/tenant_switch.php — переключение tenant для owner (POST), анти-502

declare(strict_types=1);

require_once __DIR__ . '/utils.php';

// PHP7 совместимость
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

// warnings/notices -> exception
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

// фатал -> JSON (чтобы не было 502 пустым)
register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'fatal',
        'details' => ($e['message'] ?? 'unknown') . ' @ ' . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
});

try {
    if (session_status() === PHP_SESSION_NONE) @session_start();

    require_once __DIR__ . '/security.php';
    require_same_origin();
    require_post(); // важно: у тебя вызов идёт POST

    header('Content-Type: application/json; charset=utf-8');

    $ctx  = require __DIR__ . '/guard.php';
    $role = strtolower(trim((string)($ctx['role'] ?? '')));

    if ($role !== 'owner') {
        http_response_code(403);
        echo json_encode(['ok'=>false, 'error' => 'forbidden'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // читаем tid из FORM или JSON
    $tid = 0;
    if (!empty($_POST) && is_array($_POST)) {
        $tid = (int)($_POST['tid'] ?? 0);
    } else {
        $raw = file_get_contents('php://input');
        $raw = is_string($raw) ? trim($raw) : '';
        if ($raw !== '') {
            $data = json_decode($raw, true);
            if (is_array($data)) $tid = (int)($data['tid'] ?? 0);
        }
    }
    if ($tid < 0) $tid = 0;

    // tid=0 -> сброс на дефолт
    if ($tid === 0) {
        $_SESSION['owner_tid'] = 0;
        // НЕ трогаем current_tid, чтобы не было “скачков” между контекстами
        session_write_close();
        echo json_encode(['ok' => true, 'tid' => 0], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /** @var PDO $pdo */
    $pdo = $ctx['pdo'];

    // разрешаем только существующий + активный tenant
    $sql = "SELECT id FROM tenants WHERE id = :id" . active_where($pdo, 'tenants', 'is_active') . " LIMIT 1";
    $st = $pdo->prepare($sql);
    $st->execute([':id' => $tid]);

    if ((int)$st->fetchColumn() <= 0) {
        http_response_code(400);
        echo json_encode(['ok'=>false, 'error' => 'tenant_not_found_or_inactive'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $_SESSION['owner_tid'] = $tid;
    session_write_close();

    echo json_encode(['ok' => true, 'tid' => $tid], JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'exception','details'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}
