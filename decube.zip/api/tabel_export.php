<?php
// api/tabel_export.php

declare(strict_types=1);

require_once __DIR__ . '/security.php';
require_same_origin();

$ctx = require __DIR__ . '/guard.php';

$pdo  = $ctx['pdo'];

// --- employees.is_active filter (boolean/int/missing) ---
function employees_active_expr(PDO $pdo, string $alias = ''): string {
    $p = $alias !== '' ? $alias . '.' : '';
    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='employees' AND column_name='is_active'
            LIMIT 1
        ");
        $st->execute();
        $t = strtolower((string)($st->fetchColumn() ?: ''));
        if ($t === 'boolean') return "(COALESCE({$p}is_active, TRUE) = TRUE)";
        if ($t !== '')        return "(COALESCE({$p}is_active, 1)::int <> 0)";
    } catch (Throwable $e) {}
    return "1=1"; // если колонки нет — считаем всех активными
}
$EMP_ACTIVE0 = employees_active_expr($pdo, '');

$role = $ctx['role'];
$tid  = $ctx['tid'];

if ($role === 'viewer') {
    http_response_code(403);
    exit('read_only');
}

require_once __DIR__ . '/utils.php';

$requestedGroup = trim((string)($_GET['group'] ?? ''));
$year  = (int)($_GET['year'] ?? 0);
$month = (int)($_GET['month'] ?? 0);
$week  = (int)($_GET['week'] ?? 0);

if ($year <= 0 || $month < 1 || $month > 12) {
    http_response_code(400);
    exit('bad_params');
}

$scopeGroup = $ctx['scopeGroup'] ?? '';
$exportAll = false;
$group = '';

if (in_array($role, ['owner', 'tenant_admin'], true)) {
    if ($requestedGroup === '' || $requestedGroup === 'all') $exportAll = true;
    else $group = $requestedGroup;
} elseif ($role === 'admin') {
    if ($scopeGroup === '') {
        http_response_code(403);
        exit('no_group_scope');
    }
    $group = $scopeGroup;
} else {
    http_response_code(403);
    exit('no_permission');
}

$start = new DateTime(sprintf('%04d-%02d-01', $year, $month));
$end   = (clone $start)->modify('last day of this month');

$days = [];
$cursor = clone $start;
while ($cursor <= $end) {
    $dateStr = $cursor->format('Y-m-d');
    $days[] = [
        'date'    => $dateStr,
        'weekday' => get_weekday_short($dateStr) ?: get_weekday_name($dateStr),
    ];
    $cursor->modify('+1 day');
}

// сотрудники
if ($exportAll) {
    $sql = "SELECT id, full_name, group_code FROM employees WHERE tenant_id = :tid AND " . $EMP_ACTIVE0 . " ORDER BY group_code, full_name";
    $st = $pdo->prepare($sql);
    $st->execute([':tid' => $tid]);
} else {
    $sql = "SELECT id, full_name, group_code FROM employees WHERE tenant_id = :tid AND " . $EMP_ACTIVE0 . " AND group_code = :g ORDER BY full_name";
    $st = $pdo->prepare($sql);
    $st->execute([':tid' => $tid, ':g' => $group]);
}
$employees = $st->fetchAll(PDO::FETCH_ASSOC);

// порядок как был
$fixedOrder = [
    'Давыдов Д.',
    'Ионова Е.',
    'Побединская Е.',
    'Марчишак В.',
    'Хабибрахманова В.',
    'Бехтер М.',
    'Беляев Д.',
    'Хомиченко В.',
    'Наринян А.',
    'Григоренко М.',
    'Бойченко Ю.',
    'Беляева М.',
    'Чаплыгина Э.',
];
$orderIndex = [];
foreach ($fixedOrder as $idx => $name) $orderIndex[$name] = $idx;

usort($employees, function($a, $b) use ($orderIndex) {
    $aName = $a['full_name'] ?? '';
    $bName = $b['full_name'] ?? '';
    $aHas = array_key_exists($aName, $orderIndex);
    $bHas = array_key_exists($bName, $orderIndex);
    if ($aHas && $bHas) return $orderIndex[$aName] <=> $orderIndex[$bName];
    if ($aHas && !$bHas) return -1;
    if ($bHas && !$aHas) return 1;
    return strcmp($aName, $bName);
});

// расписание
if ($exportAll) {
    $st2 = $pdo->prepare("SELECT * FROM schedule_days WHERE tenant_id = :tid AND date BETWEEN :s AND :e");
    $st2->execute([':tid' => $tid, ':s' => $start->format('Y-m-d'), ':e' => $end->format('Y-m-d')]);
} else {
    $st2 = $pdo->prepare("SELECT * FROM schedule_days WHERE tenant_id = :tid AND group_code = :g AND date BETWEEN :s AND :e");
    $st2->execute([':tid' => $tid, ':g' => $group, ':s' => $start->format('Y-m-d'), ':e' => $end->format('Y-m-d')]);
}
$rows = $st2->fetchAll(PDO::FETCH_ASSOC);
$byEmpDate = [];
foreach ($rows as $r) {
    $byEmpDate[(int)$r['employee_id'] . '_' . (string)$r['date']] = $r;
}

// ===== норма (месяц + по дням) =====
// ВАЖНО: берём norm_hours из календаря и уменьшаем норму сотрудника по статусам Б/ОТ/НН/ОВ
// только на рабочие дни (norm_hours > 0). Так экспорт совпадает с тем, что показывает сайт.
$dayNorm = []; // Y-m-d => float
$normHoursMonth = 0.0;
$hasCalendar = false;

try {
    $stCal = $pdo->prepare("
        SELECT date::text AS d, norm_hours
        FROM calendar_days
        WHERE date >= :s AND date <= :e
    ");
    $stCal->execute([
        ':s' => $start->format('Y-m-d'),
        ':e' => $end->format('Y-m-d'),
    ]);
    while ($r = $stCal->fetch(PDO::FETCH_ASSOC)) {
        $d = (string)($r['d'] ?? '');
        if ($d === '') continue;
        $nh = (float)($r['norm_hours'] ?? 0.0);
        $dayNorm[$d] = $nh;
        $normHoursMonth += $nh;
    }
    if ($normHoursMonth > 0.0) $hasCalendar = true;
} catch (Throwable $ignore) {
    $hasCalendar = false;
    $normHoursMonth = 0.0;
    $dayNorm = [];
}

// fallback без календаря: 8ч за будний день
if (!$hasCalendar) {
    $normHoursMonth = 0.0;
    foreach ($days as $d) {
        $dt = new DateTime($d['date']);
        $isWeekend = ((int)$dt->format('N') >= 6);
        $dayNorm[$d['date']] = $isWeekend ? 0.0 : 8.0;
        $normHoursMonth += $dayNorm[$d['date']];
    }
}

$reduceStatuses = ['Б', 'ОТ', 'НН', 'ОВ'];

$monthName = get_month_name($month);
$totalFactHours = 0.0;
$totalRvHoursAll = 0.0;

$fnameScope = $exportAll ? "all" : preg_replace('/[^a-zA-Z0-9_\-]/', '_', $group);
header("Content-Type: application/vnd.ms-excel; charset=utf-8");
header("Content-Disposition: attachment; filename=\"tabel_{$fnameScope}_{$year}_{$month}.xls\"");

$titleScope = $exportAll ? "все группы" : "группа " . $group;

echo "<html><head><meta charset='utf-8'></head><body>";
echo "<h3>Табель рабочего времени — {$titleScope} — {$monthName} {$year}</h3>";
echo "<table border='1' cellspacing='0' cellpadding='3'>";

echo "<tr><th>Сотрудник / Дата</th>";
foreach ($days as $d) echo "<th>" . (new DateTime($d['date']))->format('d') . "</th>";
echo "<th>Норма мес.</th><th>Факт (Я)</th><th>РВ</th></tr>";

echo "<tr><th>День недели</th>";
foreach ($days as $d) echo "<th>" . htmlspecialchars($d['weekday'], ENT_QUOTES, 'UTF-8') . "</th>";
echo "<th></th><th></th><th></th></tr>";

foreach ($employees as $e) {
    $empFactYa = 0.0;
    $empRv = 0.0;

    $normHoursEmployee = $normHoursMonth;

    $dayStatuses = [];
    $dayHours = [];
    $dayStyles = [];

    foreach ($days as $d) {
        $key = (int)$e['id'] . '_' . $d['date'];
        $status = 'В';
        $hours = 0.0;

        if (isset($byEmpDate[$key])) {
            $row = $byEmpDate[$key];
            $status = (string)$row['status'];
            $slots = (string)$row['slots'];

            $rawCount = 0;
            $len = strlen($slots);
            for ($i = 0; $i < $len; $i++) if ($slots[$i] === '1') $rawCount++;
            $rawHours = $rawCount * 0.5;

            if ($status === 'Я' || $status === 'РВ' || $status === 'РВ1') $hours = $rawHours;

            if ($status === 'Я') $empFactYa += $rawHours;
            elseif ($status === 'РВ' || $status === 'РВ1') $empRv += $rawHours;
        }

        // уменьшение нормы по оплачиваемым отсутствиям
        if ($status !== '' && in_array($status, $reduceStatuses, true)) {
            $nh = (float)($dayNorm[$d['date']] ?? 0.0);
            if ($nh > 0.0) $normHoursEmployee -= $nh;
        }

        $bg = '';
        if ($status === 'В') $bg = '#e5e7eb';
        elseif ($status === 'ОТ') $bg = '#dbeafe';
        elseif ($status === 'РВ' || $status === 'РВ1') $bg = '#fecaca';
        elseif ($status === 'НН') $bg = '#fef3c7';
        elseif ($status === 'Б') $bg = '#e0f2fe';
        elseif ($status === 'ОВ') $bg = '#e0e7ff';

        $dayStatuses[] = $status;
        $dayHours[] = $hours;
        $dayStyles[] = $bg ? " style='background:{$bg}'" : "";
    }

    $nameEsc = htmlspecialchars((string)$e['full_name'], ENT_QUOTES, 'UTF-8');

    // 1-я строка: статусы + итоги (rowspan=2)
    echo "<tr>";
    echo "<td rowspan='2'><strong>{$nameEsc}</strong></td>";
    foreach ($dayStatuses as $i => $st) {
        $style = $dayStyles[$i];
        echo "<td{$style}>" . htmlspecialchars($st, ENT_QUOTES, 'UTF-8') . "</td>";
    }
    if ($normHoursEmployee < 0.0) $normHoursEmployee = 0.0;
    echo "<td rowspan='2'>" . number_format($normHoursEmployee, 1, ',', '') . "</td>";
    echo "<td rowspan='2'>" . number_format($empFactYa, 1, ',', '') . "</td>";
    echo "<td rowspan='2'>" . number_format($empRv, 1, ',', '') . "</td>";
    echo "</tr>";

    // 2-я строка: часы
    echo "<tr>";
    foreach ($dayHours as $i => $h) {
        $style = $dayStyles[$i];
        echo "<td{$style}>" . number_format($h, 1, ',', '') . "</td>";
    }
    echo "</tr>";

    $totalFactHours += $empFactYa;
    $totalRvHoursAll += $empRv;
}

echo "<tr><td><strong>Норма часов за месяц (календарь)</strong></td><td colspan='" . count($days) . "'>" . number_format($normHoursMonth, 1, ',', '') . "</td><td></td><td></td><td></td></tr>";
echo "<tr><td><strong>Фактически отработано (Я)</strong></td><td colspan='" . count($days) . "'>" . number_format($totalFactHours, 1, ',', '') . "</td><td></td><td></td><td></td></tr>";
echo "<tr><td><strong>Часов РВ (информативно)</strong></td><td colspan='" . count($days) . "'>" . number_format($totalRvHoursAll, 1, ',', '') . "</td><td></td><td></td><td></td></tr>";
echo "<tr><td><strong>Разница (Факт - Норма календаря)</strong></td><td colspan='" . count($days) . "'>" . number_format($totalFactHours - $normHoursMonth, 1, ',', '') . "</td><td></td><td></td><td></td></tr>";

echo "</table></body></html>";
exit;