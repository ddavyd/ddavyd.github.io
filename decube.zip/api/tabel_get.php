<?php
// api/tabel_get.php — табель (PG) анти-502: JSON на фаталах + statement_timeout + быстрее выборки

declare(strict_types=1);

// warnings/notices -> exceptions
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

// фаталы тоже в JSON (чтобы не было 502)
register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'error' => 'fatal',
        'details' => ($e['message'] ?? 'unknown') . ' @ ' . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
});

require_once __DIR__ . '/security.php';
require_same_origin();
require_once __DIR__ . '/utils.php';

try {
    $ctx = require __DIR__ . '/guard.php';

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];

// --- employees.is_active filter (boolean/int/missing) ---
function employees_active_expr(PDO $pdo, string $alias = ''): string {
    $p = $alias !== '' ? $alias . '.' : '';
    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='employees' AND column_name='is_active'
            LIMIT 1
        ");
        $st->execute();
        $t = strtolower((string)($st->fetchColumn() ?: ''));
        if ($t === 'boolean') return "(COALESCE({$p}is_active, TRUE) = TRUE)";
        if ($t !== '')        return "(COALESCE({$p}is_active, 1)::int <> 0)";
    } catch (Throwable $e) {}
    return "1=1"; // если колонки нет — считаем всех активными
}
$EMP_ACTIVE0 = employees_active_expr($pdo, '');

    $role = strtolower(trim((string)($ctx['role'] ?? '')));
    $tid  = (int)($ctx['tid'] ?? 0);

    // защитимся от “вечных” запросов (иначе nginx->502)
    try {
        $pdo->exec("SET statement_timeout TO 8000"); // 8 секунд
    } catch (Throwable $ignore) {}

    $group = trim((string)($_GET['group'] ?? ''));
    $year  = (int)($_GET['year'] ?? 0);
    $month = (int)($_GET['month'] ?? 0);
    $week  = (int)($_GET['week'] ?? 0);

    if ($group === '' || $year < 2000 || $year > 2100 || ($week <= 0 && ($month < 1 || $month > 12))) {
        http_response_code(400);
        json_response(['error' => 'missing_parameters']);
        exit;
    }

    // ограничения по группе: только для admin/viewer
    $scopeGroup = trim((string)($ctx['scopeGroup'] ?? ''));
    if (in_array($role, ['admin', 'viewer'], true)) {
        if ($scopeGroup !== '' && $group !== $scopeGroup) {
            http_response_code(403);
            json_response(['error' => 'forbidden']);
            exit;
        }
    }

    
    if ($week > 0) {
        $dtStart = (new DateTimeImmutable())->setISODate($year, $week, 1);
        $dtEnd   = $dtStart->modify('+6 day');
        $start   = $dtStart->format('Y-m-d');
        $end     = $dtEnd->format('Y-m-d');
    } else {
        $start = sprintf('%04d-%02d-01', $year, $month);
        $dtStart = new DateTimeImmutable($start);
        $dtEnd   = $dtStart->modify('first day of next month')->modify('-1 day');
        $end     = $dtEnd->format('Y-m-d');
    }
// ===== микро-кэш
    $cacheTtl = 15;
    $cacheKey = sha1("tabel|tid={$tid}|g={$group}|y={$year}|m={$month}|{$start}|{$end}");
    $cacheFile = sys_get_temp_dir() . "/planning_cache_{$cacheKey}.json";

    if (is_file($cacheFile)) {
        $age = time() - (int)@filemtime($cacheFile);
        if ($age >= 0 && $age <= $cacheTtl) {
            $raw = @file_get_contents($cacheFile);
            if (is_string($raw) && $raw !== '') {
                header('Content-Type: application/json; charset=utf-8');
                echo $raw;
                exit;
            }
        }
    }

    $weekdayShort = [1 => 'Пн', 2 => 'Вт', 3 => 'Ср', 4 => 'Чт', 5 => 'Пт', 6 => 'Сб', 7 => 'Вс'];
    $monthNames = [
        1=>'Январь',2=>'Февраль',3=>'Март',4=>'Апрель',5=>'Май',6=>'Июнь',
        7=>'Июль',8=>'Август',9=>'Сентябрь',10=>'Октябрь',11=>'Ноябрь',12=>'Декабрь'
    ];

    // календарь на период
    $cal = [];
    $st = $pdo->prepare('
        SELECT date::text AS d, code, norm_hours
        FROM calendar_days
        WHERE date BETWEEN :d1 AND :d2
    ');
    $st->execute([':d1' => $start, ':d2' => $end]);
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $d = (string)($r['d'] ?? '');
        if ($d === '') continue;
        $cal[$d] = [
            'code' => (int)($r['code'] ?? 0),
            'norm' => (float)($r['norm_hours'] ?? 0),
        ];
    }

    // days + dates
    $days = [];
    $dayInfo = [];
    $dates = [];

    $hasCalendar = !empty($cal);
    $normHoursMonth = 0.0;

    $cur = $dtStart;
    while ($cur <= $dtEnd) {
        $n = (int)$cur->format('N');
        $d = $cur->format('Y-m-d');

        $code = $cal[$d]['code'] ?? null;
        $norm = $cal[$d]['norm'] ?? null;

        $isHoliday = ($code === 1);
        $isShort   = ($code === 2);
        $isWeekend = ($n >= 6);

        $days[] = [
            'date' => $d,
            'weekday' => $n,
            'weekday_short' => $weekdayShort[$n] ?? '',
            'weekend' => $isWeekend,
            'holiday' => $isHoliday,
            'shortday' => $isShort,
            'norm_hours_day' => $norm,
        ];

        // ВАЖНО: для расчёта нормы опираемся на norm_hours (а не на code==holiday),
        // чтобы внешний календарь не ломал норму из‑за "праздничного" code при norm_hours>0.
        $dayInfo[$d] = [
            'weekend' => $isWeekend,
            'holiday' => $isHoliday,
            'norm'    => ($norm !== null ? (float)$norm : null),
        ];
        $dates[] = $d;

        if ($hasCalendar && $norm !== null) $normHoursMonth += (float)$norm;
        $cur = $cur->modify('+1 day');
    }

    if (!$hasCalendar || $normHoursMonth <= 0.0) {
        $normHoursMonth = 0.0;
        foreach ($days as $dd) {
            if (!empty($dd['weekend'])) continue;
            $normHoursMonth += 8.0;
        }
        $hasCalendar = false;
    }

    // сотрудники группы (лимит на всякий случай, чтобы не словить таймаут)
    $maxEmployees = 400; // если нужно — увеличим потом
    $st = $pdo->prepare('
        SELECT id, full_name
        FROM employees
        WHERE tenant_id = :tid AND ' . $EMP_ACTIVE0 . ' AND group_code = :g
        ORDER BY full_name
        LIMIT ' . (int)$maxEmployees . '
    ');
    $st->execute([':tid' => $tid, ':g' => $group]);
    $emps = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

    $empIds = [];
    foreach ($emps as $e) {
        $eid = (int)($e['id'] ?? 0);
        if ($eid > 0) $empIds[] = $eid;
    }

    // расписание за месяц — только по найденным сотрудникам
    $map = [];
    if ($empIds) {
        $st = $pdo->prepare('
            SELECT date::text AS d, employee_id, status, slots
            FROM schedule_days
            WHERE tenant_id = :tid
              AND group_code = :g
              AND date BETWEEN :d1 AND :d2
              AND employee_id = ANY(:eids)
        ');
        $st->bindValue(':tid', $tid, PDO::PARAM_INT);
        $st->bindValue(':g', $group, PDO::PARAM_STR);
        $st->bindValue(':d1', $start, PDO::PARAM_STR);
        $st->bindValue(':d2', $end, PDO::PARAM_STR);
        // ВАЖНО: для ANY нужен int[]
        $st->bindValue(':eids', '{' . implode(',', $empIds) . '}', PDO::PARAM_STR);

        $st->execute();

        while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
            $d = (string)($r['d'] ?? '');
            $eid = (int)($r['employee_id'] ?? 0);
            if ($d === '' || $eid <= 0) continue;
            $map[$eid][$d] = [
                'status' => (string)($r['status'] ?? ''),
                'slots'  => (string)($r['slots'] ?? ''),
            ];
        }
    }

    $slots_to_hours = static function(string $slots): float {
        if ($slots === '') return 0.0;
        $len = strlen($slots);
        if ($len < 48) $slots = str_pad($slots, 48, '0');
        elseif ($len > 48) $slots = substr($slots, 0, 48);
        return substr_count($slots, '1') * 0.5;
    };

    // Статусы, которые уменьшают требуем encourage norm (оплачиваемые отсутствия)
    $reduceStatuses = ['Б', 'ОТ', 'НН', 'ОВ'];

    $employees = [];
    foreach ($emps as $e) {
        $eid = (int)($e['id'] ?? 0);
        if ($eid <= 0) continue;

        $name = (string)($e['full_name'] ?? '');

        $empDays = [];
        $totalYa = 0.0;
        $totalRv = 0.0;
        $normHoursEmployee = $normHoursMonth;

        foreach ($dates as $d) {
            $status = $map[$eid][$d]['status'] ?? '';
            $slots  = $map[$eid][$d]['slots'] ?? '';

            $hours = 0.0;
            if ($status === 'Я' || $status === 'РВ' || $status === 'РВ1') {
                $hours = $slots_to_hours($slots);
                if ($status === 'Я')  $totalYa += $hours;
                if ($status === 'РВ' || $status === 'РВ1') $totalRv += $hours;
            }

            if ($status !== '' && in_array($status, $reduceStatuses, true)) {
                // Если есть производственный календарь — уменьшаем на нормо‑часы дня
                // (только если день рабочий: norm_hours > 0).
                if ($hasCalendar) {
                    $nh = $dayInfo[$d]['norm'] ?? null;
                    if (is_float($nh) && $nh > 0.0) {
                        $normHoursEmployee -= $nh;
                    }
                } else {
                    // Fallback без календаря: уменьшаем на 8ч только в будни.
                    $isWeekend = !empty($dayInfo[$d]['weekend']);
                    if (!$isWeekend) {
                        $normHoursEmployee -= 8.0;
                    }
                }
            }

            $empDays[] = [
                'date' => $d,
                'status' => $status,
                'hours' => $hours,
            ];
        }

        if ($normHoursEmployee < 0.0) $normHoursEmployee = 0.0;

        $employees[] = [
            'employee_id' => $eid,
            'name' => $name,
            'days' => $empDays,
            'normHoursEmployee' => $normHoursEmployee,
            'totalYaHours' => $totalYa,
            'totalRvHours' => $totalRv,
        ];
    }

    $payload = [
        'group' => $group,
        'year' => $year,
        'month' => $month,
        'monthName' => $monthNames[$month] ?? (string)$month,
        'start' => $start,
        'end' => $end,
        'days' => $days,
        'employees' => $employees,
        'calendar' => [
            'source' => 'isdayoff',
            'hasCalendar' => $hasCalendar,
        ],
    ];

    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if (is_string($json)) {
        @file_put_contents($cacheFile, $json, LOCK_EX);
        header('Content-Type: application/json; charset=utf-8');
        echo $json;
        exit;
    }

    json_response($payload);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    json_response(['error' => 'tabel_get_failed', 'details' => $e->getMessage()]);
    exit;
}
