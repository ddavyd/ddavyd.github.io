<?php
declare(strict_types=1);

require_once __DIR__ . '/guard.php';

try {
    $ctx = require __DIR__ . '/guard.php';
    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $tid  = (int)$ctx['tid'];

    $group = $_GET['group'] ?? '';
    $year  = (int)($_GET['year'] ?? 0);
    $month = (int)($_GET['month'] ?? 0);
    $period = $_GET['period'] ?? '1'; // 1 или 2

    if (!$group || !$year || !$month) {
        http_response_code(400);
        echo json_encode(['error'=>'params']);
        exit;
    }

    // 👉 тянем табель
    $_GET['week'] = 0;
    ob_start();
    require __DIR__ . '/tabel_get.php';
    $tabel = json_decode(ob_get_clean(), true);

    if (!$tabel || empty($tabel['employees'])) {
        echo json_encode([]);
        exit;
    }

    // норма месяца
    $monthNorm = 0;
    foreach ($tabel['days'] as $d) {
        if (!empty($d['norm_hours_day'])) {
            $monthNorm += (float)$d['norm_hours_day'];
        }
    }
    if ($monthNorm <= 0) $monthNorm = 160;

    // диапазон дат
    $startDay = ($period == '1') ? 1 : 16;
    $endDay   = ($period == '1') ? 15 : 31;

    $result = [];

    foreach ($tabel['employees'] as $emp) {

        $empId = (int)$emp['employee_id'];

        // 👉 берём оклад
        $st = $pdo->prepare("SELECT salary_base FROM employees WHERE id=:id");
        $st->execute([':id'=>$empId]);
        $salary = (float)($st->fetchColumn() ?: 0);

        if ($salary <= 0) continue;

        $ya = $ov = $ot = $b = $rv = $rv1 = 0;

        foreach ($emp['days'] as $d) {

            $dayNum = (int)substr($d['date'], 8, 2);
            if ($dayNum < $startDay || $dayNum > $endDay) continue;

            $h = (float)$d['hours'];
            $s = $d['status'];

            switch ($s) {
                case 'Я':  $ya += $h; break;
                case 'ОВ': $ov += 8; break;
                case 'ОТ': $ot += 8; break;
                case 'Б':  $b  += 8; break;
                case 'РВ': $rv += $h; break;
                case 'РВ1':$rv1+= $h; break;
                case 'НН': break;
            }
        }

        $rate = $salary / $monthNorm;

        $paid = $ya + $ov + $ot + $b;

        $base = $rate * $paid;
        $rvPay  = $rv * $rate * 2;
        $rv1Pay = $rv1 * $rate;

        $total = $base + $rvPay + $rv1Pay;
        $net   = $total * 0.87;

        $result[] = [
            'name' => $emp['name'],
            'salary' => $salary,
            'hours' => $paid,
            'rv' => $rv,
            'total' => round($total,2),
            'net' => round($net,2),
        ];
    }

    header('Content-Type: application/json');
    echo json_encode($result);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error'=>$e->getMessage()]);
}