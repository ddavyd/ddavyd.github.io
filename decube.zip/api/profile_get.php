<?php
// api/profile_get.php — универсальная стабильная версия (employee_id или username)

declare(strict_types=1);

require_once __DIR__ . '/utils.php';

try {
    $ctx = require __DIR__ . '/guard.php';

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $user = $ctx['user'] ?? [];
    $role = strtolower(trim((string)($ctx['role'] ?? '')));
    $tid  = (int)($ctx['tid'] ?? 0);

    header('Content-Type: application/json; charset=utf-8');

    // 1) пробуем employee_id
    $employeeId = 0;
    if (isset($_GET['employee_id'])) {
        $employeeId = (int)$_GET['employee_id'];
    } elseif (!empty($user['employee_id'])) {
        $employeeId = (int)$user['employee_id'];
    }

    // 2) если employee_id нет — пробуем username (это как раз то, что у тебя в запросе)
    $username = trim((string)($_GET['username'] ?? ''));
    if ($employeeId <= 0 && $username !== '') {
        $st = $pdo->prepare('
            SELECT employee_id
            FROM users
            WHERE tenant_id = :tid AND username = :u
            LIMIT 1
        ');
        $st->execute([':tid' => $tid, ':u' => $username]);
        $employeeId = (int)($st->fetchColumn() ?: 0);
    }

    if ($employeeId <= 0) {
        http_response_code(400);
        echo json_encode([
            'error' => 'invalid_employee',
            'hint'  => 'pass employee_id or username',
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // viewer/admin — только свой профиль
    if (in_array($role, ['admin', 'viewer'], true)) {
        if ((int)($user['employee_id'] ?? 0) !== $employeeId) {
            http_response_code(403);
            echo json_encode(['error' => 'forbidden'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    $st = $pdo->prepare("
        SELECT
            e.id,
            e.full_name,
            e.group_code,
            e.role AS employee_role,
            e.tab_no,
            e.birth_date,
            e.email AS employee_email,
            u.username,
            u.role AS user_role,
            u.email AS user_email
        FROM employees e
        LEFT JOIN users u ON u.employee_id = e.id AND u.tenant_id = :tid
        WHERE e.id = :eid AND e.tenant_id = :tid
        LIMIT 1
    ");

    $st->execute([
        ':eid' => $employeeId,
        ':tid' => $tid,
    ]);

    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) {
        http_response_code(404);
        echo json_encode(['error' => 'not_found'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode($row, JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'error' => 'profile_get_failed',
        'details' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
