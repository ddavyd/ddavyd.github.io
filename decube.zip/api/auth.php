<?php
// api/auth.php — стабильный (PG) + нормальная обработка ошибок

declare(strict_types=1);

require_once __DIR__ . '/security.php';
ensure_session_started();
require_same_origin();

require_once __DIR__ . '/rate_limit.php';

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/utils.php';

header('Content-Type: application/json; charset=utf-8');

function read_input(): array {
    if (!empty($_POST)) {
        return is_array($_POST) ? $_POST : [];
    }
    $raw = file_get_contents('php://input');
    $raw = is_string($raw) ? trim($raw) : '';
    if ($raw === '') return [];

    $data = json_decode($raw, true);
    if (is_array($data)) return $data;

    // на всякий случай поддержим form-urlencoded из raw
    $parsed = [];
    parse_str($raw, $parsed);
    return is_array($parsed) ? $parsed : [];
}

function redirect_for_role(?string $role): string {
    $r = strtolower(trim((string)$role));
    if (in_array($r, ['owner', 'tenant_admin', 'admin'], true)) {
        return '/?r=admin';
    }
    return '/';
}

try {
    $pdo = get_db();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

    if ($method === 'GET') {
        $action = isset($_GET['action']) ? (string)$_GET['action'] : '';

        if ($action === 'me') {
            $user = db_get_current_user($pdo);

            if (!$user) {
                echo json_encode(['authenticated' => false], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $role = $user['role'] ?? null;

            // гарантируем, что CSRF существует и отдаем его фронту
            $ctx = require __DIR__ . '/guard.php';
            $csrf = (string)($ctx['csrf'] ?? '');

            echo json_encode([
                'authenticated'  => true,
                'username'       => $user['username'] ?? null,
                'role'           => $role,
                'employee_id'    => $user['employee_id'] ?? null,
                'employee_name'  => $user['employee_name'] ?? null,
                'group_code'     => $user['employee_group'] ?? null,
                'redirect'       => redirect_for_role(is_string($role) ? $role : null),
                'csrf'           => $csrf,
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo json_encode(['error' => 'unknown_action'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($method === 'POST') {
        $input  = read_input();
        $action = isset($input['action']) ? (string)$input['action'] : '';

        if ($action === 'login') {
            $username = isset($input['username']) ? trim((string)$input['username']) : '';
            $password = isset($input['password']) ? (string)$input['password'] : '';

            if ($username === '' || $password === '') {
                http_response_code(400);
                echo json_encode(['error' => 'missing_credentials'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            // rate-limit: 5 попыток за 10 минут на IP и на username
            $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
            $uKey = strtolower($username);

            $s1 = rl_check('login:ip:' . $ip, 5, 600);
            $s2 = rl_check('login:user:' . $uKey, 5, 600);
            if (!$s1['ok'] || !$s2['ok']) {
                rl_429(!$s1['ok'] ? $s1 : $s2);
            }

            // Ищем пользователя по логину БЕЗ tenant-фильтра (как было)
            $stmt = $pdo->prepare("
                SELECT id, tenant_id, username, password_hash
                FROM users
                WHERE username = :u
                LIMIT 1
            ");
            $stmt->execute([':u' => $username]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$row || !isset($row['password_hash']) || !password_verify($password, (string)$row['password_hash'])) {
                http_response_code(401);
                echo json_encode(['error' => 'Неверный логин или пароль'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            session_regenerate_id(true);

            $_SESSION['user_id']   = (int)$row['id'];
            $_SESSION['tenant_id'] = (int)$row['tenant_id'];

            // обновим CSRF при логине
            $_SESSION['csrf'] = bin2hex(random_bytes(16));

            // сброс owner switch при логине (чтобы не залипало)
            if (!empty($_SESSION['owner_tid'])) {
                $_SESSION['owner_tid'] = 0;
            }

            $fullUser = db_get_current_user($pdo);
            if (!$fullUser) {
                http_response_code(500);
                echo json_encode(['error' => 'login_failed'], JSON_UNESCAPED_UNICODE);
                exit;
            }

            $role = $fullUser['role'] ?? null;

            // guard синхронизирует scope_group/current_tid и вернет csrf
            $ctx = require __DIR__ . '/guard.php';
            $csrf = (string)($ctx['csrf'] ?? (string)($_SESSION['csrf'] ?? ''));

            echo json_encode([
                'authenticated'  => true,
                'username'       => $fullUser['username'] ?? null,
                'role'           => $role,
                'employee_id'    => $fullUser['employee_id'] ?? null,
                'employee_name'  => $fullUser['employee_name'] ?? null,
                'group_code'     => $fullUser['employee_group'] ?? null,
                'redirect'       => redirect_for_role(is_string($role) ? $role : null),
                'csrf'           => $csrf,
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        if ($action === 'logout') {
            $_SESSION = [];

            if (ini_get('session.use_cookies')) {
                $p = session_get_cookie_params();
                setcookie(session_name(), '', time() - 42000,
                    $p['path'] ?? '/',
                    $p['domain'] ?? '',
                    (bool)($p['secure'] ?? false),
                    (bool)($p['httponly'] ?? true)
                );
            }

            @session_destroy();

            echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo json_encode(['error' => 'unknown_action'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed'], JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    // чтобы больше не было "тихих" 500
    error_log('[auth.php] ' . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => 'internal_error',
        // на проде можно убрать, но сейчас пусть поможет быстро найти причину
        'message' => $e->getMessage(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
