<?php
// api/ping.php — health check

declare(strict_types=1);

require_once __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $pdo = get_db();
    $pdo->query('SELECT 1');
    echo json_encode([
        'ok'   => true,
        'time' => date('c'),
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'ok'    => false,
        'error' => 'db_unavailable',
    ], JSON_UNESCAPED_UNICODE);
}
exit;
