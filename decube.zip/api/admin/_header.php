<?php
// admin/_header.php — верхняя панель (БЕЗ tenant switch в хедере)

declare(strict_types=1);

require_once __DIR__ . '/../utils.php';

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

if (isset($ctx) && is_array($ctx)) {
    $pdo  = $ctx['pdo']  ?? ($pdo  ?? null);
    $role = $ctx['role'] ?? ($role ?? '');
    $tid  = $ctx['tid']  ?? ($tid  ?? 0);
    $user = $ctx['user'] ?? ($user ?? []);
} else {
    $pdo  = $pdo  ?? null;
    $role = $role ?? '';
    $tid  = $tid  ?? 0;
    $user = $user ?? [];
}

$role    = strtolower(trim((string)$role));
$tid_eff = (int)$tid;

// tenant badge + list
$tenantBadge = '';
$tenantsList = [];

if ($pdo instanceof PDO) {
    try {
        if ($role === 'owner' && !empty($_SESSION['owner_tid'])) {
            $tid_eff = (int)$_SESSION['owner_tid'];
        }

        // owner: список только активных (оставляем — понадобится на главной админки)
        if ($role === 'owner') {
            $sqlTenants = "SELECT id, name, code FROM tenants WHERE 1=1" . active_where($pdo, 'tenants', 'is_active') . " ORDER BY id ASC";
            $st = $pdo->query($sqlTenants);
            $rows = $st ? ($st->fetchAll(PDO::FETCH_ASSOC) ?: []) : [];

            foreach ($rows as $r) {
                $id = (int)($r['id'] ?? 0);
                if ($id <= 0) continue;
                $nm = trim((string)($r['name'] ?? ''));
                $cd = trim((string)($r['code'] ?? ''));
                $label = trim(($nm !== '' ? $nm : ('#'.$id)) . ($cd !== '' ? " ($cd)" : ''));
                $tenantsList[] = ['id' => $id, 'label' => $label];
            }

            // если выбранный tenant выключен/не найден — берём первый активный
            if ($tid_eff > 0) {
                $sqlOne = "SELECT 1 FROM tenants WHERE id = :id" . active_where($pdo, 'tenants', 'is_active') . " LIMIT 1";
                $st = $pdo->prepare($sqlOne);
                $st->execute([':id' => $tid_eff]);
                $ok = (bool)$st->fetchColumn();
                if (!$ok) {
                    $tid_eff = (int)($tenantsList[0]['id'] ?? 0);
                    if ($tid_eff > 0) $_SESSION['owner_tid'] = $tid_eff;
                }
            } else {
                $tid_eff = (int)($tenantsList[0]['id'] ?? 0);
                if ($tid_eff > 0) $_SESSION['owner_tid'] = $tid_eff;
            }
        }

        // badge: показываем выбранный (если есть)
        if ($tid_eff > 0) {
            $st = $pdo->prepare("SELECT name, code FROM tenants WHERE id = :id LIMIT 1");
            $st->execute([':id' => $tid_eff]);
            $t = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            $name = trim((string)($t['name'] ?? ''));
            $code = trim((string)($t['code'] ?? ''));
            $tenantBadge = trim($name . ($code !== '' ? " ($code)" : ''));
        }

    } catch (Throwable $e) {
        // ignore
    }
}

?><!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Админка</title>
  <link rel="stylesheet" href="/frontend/styles.css?v=admin_ui_1">
  <style>
    body{background:#f6f7fb}
    .admin-topbar{
      display:flex;align-items:center;justify-content:space-between;gap:12px;
      flex-wrap:wrap;padding:10px 12px;border-bottom:1px solid rgba(0,0,0,.08);
      background:#fff; position:sticky; top:0; z-index:10;
    }
    .admin-left,.admin-right{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
    .btn{
      display:inline-flex;align-items:center;gap:8px;padding:8px 12px;
      border:1px solid rgba(0,0,0,.14);border-radius:12px;background:#fff;
      cursor:pointer;text-decoration:none;color:#111827;box-shadow:0 2px 6px rgba(0,0,0,.06)
    }
    .btn:hover{background:#f9fafb}
    .pill{
      display:inline-block;padding:3px 10px;border-radius:999px;
      background:#f1f5f9;border:1px solid #e5e7eb;font-size:13px
    }
    .muted{color:#64748b}
    .tenant-badge{display:inline-block;padding:3px 10px;border-radius:999px;background:#eef2ff;border:1px solid #c7d2fe;font-size:13px}
    .card{background:#fff;border:1px solid rgba(0,0,0,.10);border-radius:16px;padding:14px;box-shadow:0 4px 12px rgba(0,0,0,.06)}
    input[type="text"],input[type="email"],input[type="date"],input[type="password"],select{
      padding:10px 12px;border-radius:12px;border:1px solid rgba(0,0,0,.14);background:#fff;min-width:220px
    }
    table{width:100%;border-collapse:collapse}
    th{font-weight:700;color:#334155}
    th,td{padding:10px;border-bottom:1px solid #eef2f7;vertical-align:top}
  </style>
</head>
<body>

<div class="admin-topbar">
  <div class="admin-left">
    <a class="btn" href="/?r=admin">← Админка</a>
    <a class="btn" href="/">↩ В расписание</a>
    


    <span class="pill"><?= htmlspecialchars($role, ENT_QUOTES, 'UTF-8') ?></span>
    <?php if ($tid_eff > 0): ?>
      <span class="pill">#<?= (int)$tid_eff ?></span>
    <?php endif; ?>

    <?php if ($tenantBadge !== ''): ?>
      <span class="tenant-badge">🏷 <?= htmlspecialchars($tenantBadge, ENT_QUOTES, 'UTF-8') ?></span>
    <?php endif; ?>

    <!-- ВАЖНО: переключатель tenant убрали из хедера -->
  </div>

  <div class="admin-right">
    <span class="muted">Пользователь: <b><?= htmlspecialchars((string)($user['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?></b></span>
    <button class="btn" type="button" id="adminLogoutBtn">🚪 Выйти</button>
  </div>
</div>

<script>
(function(){
  const btn = document.getElementById('adminLogoutBtn');
  if (btn) {
    btn.addEventListener('click', async () => {
      try {
        const fd = new FormData();
        fd.append('action', 'logout');
        await fetch('/api/auth.php', { method:'POST', body:fd, credentials:'same-origin' });
      } catch (e) {}
      window.location.href = '/';
    });
  }
})();
</script>
