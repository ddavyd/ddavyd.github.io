<?php
// api/admin/tenants.php — подразделения (owner)
// FIX:
// 1) В твоей версии toggle был сломан: он находился внутри ветки add и использовал $id (не определён).
// 2) is_active в PG = boolean, поэтому (int)'t' == 0 и UI показывал/считал всё неправильно.
// 3) Toggle теперь корректный для boolean и для legacy int (если вдруг где-то осталось).

declare(strict_types=1);

$ctx = require __DIR__ . '/../guard.php';
require_once __DIR__ . '/../utils.php';

$pdo  = $ctx['pdo'];
$role = strtolower(trim((string)($ctx['role'] ?? '')));

if ($role !== 'owner') {
    http_response_code(403);
    echo 'no_permission';
    exit;
}

require __DIR__ . '/_header.php';

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

// Определяем тип is_active один раз
$dtIsActive = '';
try {
    $dtIsActive = (string)column_data_type($pdo, 'tenants', 'is_active');
} catch (Throwable $ignore) {
    $dtIsActive = '';
}
$isBool = ($dtIsActive === 'boolean');

// Нормализатор "активен ли" для вывода (PG boolean возвращает 't'/'f' или true/false)
function is_active_truthy($v): bool {
    if (is_bool($v)) return $v;
    if (is_int($v)) return $v === 1;
    if (is_string($v)) {
        $s = strtolower(trim($v));
        return in_array($s, ['1', 't', 'true', 'yes', 'y', 'on'], true);
    }
    return false;
}

$err = '';
$ok  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = trim((string)($_POST['action'] ?? ''));

    try {
        if ($action === 'add') {
            $code = trim((string)($_POST['code'] ?? ''));
            $name = trim((string)($_POST['name'] ?? ''));
            if ($code === '' || $name === '') {
                throw new RuntimeException('Введите code и name');
            }

            // Добавляем подразделение активным по умолчанию
            if ($isBool) {
                $st = $pdo->prepare("INSERT INTO tenants (code, name, is_active) VALUES (:c, :n, true)");
            } else {
                $st = $pdo->prepare("INSERT INTO tenants (code, name, is_active) VALUES (:c, :n, 1)");
            }
            $st->execute([':c' => $code, ':n' => $name]);
            $ok = 'Добавлено';
        }

        elseif ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('bad_id');

            if ($isBool) {
                $sql = "UPDATE tenants SET is_active = NOT is_active WHERE id = :id";
            } else {
                $sql = "UPDATE tenants SET is_active = CASE WHEN is_active = 1 THEN 0 ELSE 1 END WHERE id = :id";
            }
            $st = $pdo->prepare($sql);
            $st->execute([':id' => $id]);
            $ok = 'Обновлено';
        }

        elseif ($action === 'regen_join') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('bad_id');

            $newCode = bin2hex(random_bytes(4));
            $st = $pdo->prepare("UPDATE tenants SET join_code = :jc WHERE id = :id");
            $st->execute([':jc' => $newCode, ':id' => $id]);
            $ok = 'Код регистрации обновлён';
        }

    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$rows = [];
try {
    $st = $pdo->query("SELECT id, code, name, join_code, is_active FROM tenants ORDER BY id ASC");
    $rows = $st ? ($st->fetchAll(PDO::FETCH_ASSOC) ?: []) : [];
} catch (Throwable $e) {
    $rows = [];
}

?>
<div class="app-container" style="max-width:1100px;">
  <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
    <h2 style="margin:0;">Подразделения</h2>
    <a class="btn" href="/?r=admin">← Назад</a>
  </div>

  <?php if ($err): ?><div class="error" style="margin-top:10px;"><?= h($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="ok" style="margin-top:10px;"><?= h($ok) ?></div><?php endif; ?>

  <div class="card" style="margin-top:12px;">
    <h3 style="margin-top:0;">Добавить</h3>
    <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center">
      <input type="hidden" name="action" value="add">
      <input type="text" name="code" placeholder="code" required>
      <input type="text" name="name" placeholder="name" required>
      <button class="btn" type="submit">Добавить</button>
    </form>
  </div>

  <div class="card" style="margin-top:12px;">
    <h3 style="margin-top:0;">Список</h3>

    <?php if (!$rows): ?>
      <div class="muted">Подразделений нет</div>
    <?php else: ?>
      <table style="width:100%;border-collapse:collapse;">
        <thead>
          <tr>
            <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">ID</th>
            <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Code</th>
            <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Name</th>
            <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Join code</th>
            <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Active</th>
            <th style="padding:8px;border-bottom:1px solid #e5e7eb;"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $r): $isActive = is_active_truthy($r['is_active'] ?? null); ?>
            <tr>
              <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= (int)($r['id'] ?? 0) ?></td>
              <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= h((string)($r['code'] ?? '')) ?></td>
              <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= h((string)($r['name'] ?? '')) ?></td>
              <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= h((string)($r['join_code'] ?? '')) ?></td>
              <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= $isActive ? '✅' : '⛔' ?></td>
              <td style="padding:8px;border-bottom:1px solid #f1f5f9;text-align:right;white-space:nowrap;">
                <form method="post" style="display:inline;">
                  <input type="hidden" name="action" value="toggle">
                  <input type="hidden" name="id" value="<?= (int)($r['id'] ?? 0) ?>">
                  <button class="btn" type="submit"><?= $isActive ? 'Сделать неактивным' : 'Сделать активным' ?></button>
                </form>
                <form method="post" style="display:inline;" onsubmit="return confirm('Сгенерировать новый код?');">
                  <input type="hidden" name="action" value="regen_join">
                  <input type="hidden" name="id" value="<?= (int)($r['id'] ?? 0) ?>">
                  <button class="btn" type="submit">Новый код</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

</body></html>
