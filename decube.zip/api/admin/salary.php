<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Расчет ЗП</title>
</head>
<body>

<h2>Расчет зарплаты</h2>

Группа: <input id="g"><br>
Год: <input id="y" value="2026"><br>
Месяц: <input id="m" value="3"><br>

Период:
<select id="p">
<option value="1">1-15</option>
<option value="2">16-конец</option>
</select>

<button onclick="load()">Рассчитать</button>

<table border="1" id="t"></table>

<script>
function load(){
    const g=document.getElementById('g').value;
    const y=document.getElementById('y').value;
    const m=document.getElementById('m').value;
    const p=document.getElementById('p').value;

    fetch(`/api/salary_calc.php?group=${g}&year=${y}&month=${m}&period=${p}`)
    .then(r=>r.json())
    .then(data=>{
        let html="<tr><th>Сотрудник</th><th>Начислено</th><th>На руки</th></tr>";
        data.forEach(e=>{
            html+=`<tr>
                <td>${e.name}</td>
                <td>${e.total}</td>
                <td>${e.net}</td>
            </tr>`;
        });
        document.getElementById('t').innerHTML=html;
    });
}
</script>

</body>
</html>