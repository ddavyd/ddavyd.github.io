<?php
// api/admin/audit.php — страница журнала изменений (UI)
// UI FIX:
// 1) время: DD.MM.YYYY HH:MM
// 2) "Показать детали" — шире + компактнее, меньше переносов
// 3) Excel serial для birth_date (34480.0) -> нормальная дата
// 4) action/детали — человекочитаемые (не JSON), включая groups
//
// HOTFIX (НЕ ТРОГАЯ ОСТАЛЬНОЕ):
// - вернул отображение "часов" (интервалы) для schedule: из slots (48 символов) -> "HH:MM–HH:MM, ..."

declare(strict_types=1);

@ini_set('display_errors', '0');
error_reporting(E_ALL);

set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo "<pre style='white-space:pre-wrap;font:14px/1.3 monospace;background:#fff3cd;border:1px solid #ffeeba;padding:12px;border-radius:10px'>";
    echo "ADMIN FATAL:\n";
    echo htmlspecialchars(($e['message'] ?? 'unknown') . "\n" . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0), ENT_QUOTES, 'UTF-8');
    echo "</pre>";
});

try {
    if (!isset($ctx) || !is_array($ctx)) {
        $ctx = require __DIR__ . '/../guard.php';
    }

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $user = $ctx['user'] ?? [];
    $role = strtolower(trim((string)($ctx['role'] ?? '')));
    $tid  = (int)($ctx['tid'] ?? 0);

    if (!($role === 'owner' || $role === 'tenant_admin')) {
        http_response_code(403);
        header('Content-Type: text/html; charset=utf-8');
        echo "<div style='font:14px/1.4 sans-serif;padding:16px'>Доступ запрещён</div>";
        exit;
    }

    require __DIR__ . '/_header.php';

    // tenant info
    $tenantName = '';
    try {
        if ($tid > 0) {
            $st = $pdo->prepare("SELECT name FROM tenants WHERE id = :id LIMIT 1");
            $st->execute([':id' => $tid]);
            $tenantName = (string)($st->fetchColumn() ?: '');
        }
    } catch (Throwable $ignore) {}

    ?>
    <style>
      .wrap{max-width:1180px;margin:0 auto;padding:12px}
      .card{background:#fff;border:1px solid rgba(0,0,0,.10);border-radius:16px;padding:14px;box-shadow:0 4px 12px rgba(0,0,0,.06)}
      .muted{color:#64748b}
      .row{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
      .tbl{width:100%;border-collapse:collapse;margin-top:10px}
      .tbl th,.tbl td{border-top:1px solid #e5e7eb;padding:10px;vertical-align:top;text-align:left;font-size:14px}
      .tbl th{font-size:13px;color:#475569}
      .pill{display:inline-block;padding:2px 8px;border-radius:999px;background:#f1f5f9;border:1px solid #e5e7eb;margin-right:6px;font-size:12px}
      .btn2{display:inline-flex;align-items:center;gap:8px;border:1px solid rgba(0,0,0,.15);border-radius:12px;padding:8px 12px;cursor:pointer}
      .btn2:disabled{opacity:.55;cursor:not-allowed}
      .inp{border:1px solid #e5e7eb;border-radius:12px;padding:8px 10px;min-height:36px}
      .small{font-size:12px}
      details.audit-details{background:#f8fafc;border:1px solid #e5e7eb;border-radius:12px;padding:8px 10px;max-width:860px}
      details.audit-details summary{cursor:pointer;font-weight:600}
      .details-body{margin-top:10px}
      .mini-table{width:100%;border-collapse:collapse}
      .mini-table th,.mini-table td{border-top:1px solid #e5e7eb;padding:8px;vertical-align:top;font-size:13px}
      .mini-table th{font-size:12px;color:#475569}
      .k{color:#0f172a;font-weight:600}
      .v{color:#0f172a}
      .two-col{display:grid;grid-template-columns:1fr 1fr;gap:10px}
      .one-line{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:520px;display:inline-block;vertical-align:bottom}
      @media (max-width: 980px){
        details.audit-details{max-width:100%}
        .two-col{grid-template-columns:1fr}
        .one-line{max-width:280px}
      }
    </style>

    <div class="wrap">
      <div class="card">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap;">
          <div>
            <div style="font-size:18px;font-weight:700;">Журнал изменений</div>
            <div class="muted" style="margin-top:6px;">
              Подразделение: <b><?= htmlspecialchars($tenantName !== '' ? $tenantName : ('#'.$tid), ENT_QUOTES, 'UTF-8') ?></b>
              <span class="pill">#<?= (int)$tid ?></span>
            </div>
          </div>

          <div class="row">
            <a class="btn2" href="/?r=admin">← Назад</a>
          </div>
        </div>

        <hr style="margin:14px 0;border:none;border-top:1px solid #e5e7eb">

        <div class="row" style="align-items:flex-end">
          <div style="display:flex;flex-direction:column;gap:6px">
            <label class="small muted">С</label>
            <input class="inp" type="date" id="fFrom">
          </div>

          <div style="display:flex;flex-direction:column;gap:6px">
            <label class="small muted">По</label>
            <input class="inp" type="date" id="fTo">
          </div>

          <div style="display:flex;flex-direction:column;gap:6px;min-width:220px">
            <label class="small muted">Тип</label>
            <select class="inp" id="fType">
              <option value="">Все типы</option>
              <option value="schedule">Расписание</option>
              <option value="employee">Сотрудники</option>
              <option value="group">Группы</option>
              <option value="tenant">Подразделения</option>
            </select>
          </div>

          <div style="display:flex;flex-direction:column;gap:6px;min-width:260px;flex:1">
            <label class="small muted">Поиск</label>
            <input class="inp" type="text" id="fQ" placeholder="Поиск (логин / действие / ID)">
          </div>

          <button class="btn2" id="btnApply">🔎 Найти</button>
        </div>

        <table class="tbl" id="tbl">
          <thead>
            <tr>
              <th style="width:125px">Время</th>
              <th style="width:90px">Кто</th>
              <th style="width:190px">Действие</th>
              <th>Детали</th>
            </tr>
          </thead>
          <tbody id="tbody">
            <tr><td colspan="4" class="muted">Загрузка…</td></tr>
          </tbody>
        </table>

        <div class="row" style="margin-top:12px;justify-content:space-between">
          <div class="muted small" id="pageInfo"></div>
          <div class="row">
            <button class="btn2" id="btnPrev">← Предыдущие</button>
            <button class="btn2" id="btnNext">Следующие →</button>
          </div>
        </div>
      </div>
    </div>

    <script>
    (function(){
      const tbody = document.getElementById('tbody');
      const pageInfo = document.getElementById('pageInfo');
      const fFrom = document.getElementById('fFrom');
      const fTo = document.getElementById('fTo');
      const fType = document.getElementById('fType');
      const fQ = document.getElementById('fQ');

      const btnApply = document.getElementById('btnApply');
      const btnPrev = document.getElementById('btnPrev');
      const btnNext = document.getElementById('btnNext');

      let limit = 50;
      let offset = 0;

      function esc(s){
        s = (s ?? '') + '';
        return s.replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
      }

      function pad2(n){ n = parseInt(n,10); return (n<10?'0':'')+n; }

      function fmtTime(ts){
        if (!ts) return '';
        const d = new Date(ts);
        if (isNaN(d.getTime())) return esc(ts);
        return `${pad2(d.getDate())}.${pad2(d.getMonth()+1)}.${d.getFullYear()} ${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
      }

      // Excel date serial -> YYYY-MM-DD
      function excelSerialToISO(n){
        const num = Number(n);
        if (!isFinite(num)) return null;
        const days = Math.floor(num);
        const base = Date.UTC(1899, 11, 30);
        const ms = base + days * 86400000;
        const d = new Date(ms);
        if (isNaN(d.getTime())) return null;
        return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth()+1)}-${pad2(d.getUTCDate())}`;
      }

      function prettyDateISOToRU(iso){
        if (!iso || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return iso;
        const [y,m,d] = iso.split('-');
        return `${d}.${m}.${y}`;
      }

      function prettyField(field){
        const f = (field || '').toLowerCase();

        const map = {
          'employee.full_name': 'ФИО',
          'employee.group_code': 'Группа',
          'employee.role': 'Должность',
          'employee.tab_no': 'Табельный №',
          'employee.birth_date': 'Дата рождения',
          'employee.email': 'Email',
          'employee.is_active': 'Активен',
          'user.role': 'Права доступа',

          'group.code': 'Код группы',
          'group.title': 'Название',
          'group.is_active': 'Активна',
          'employees.group_code': 'Группа сотрудников',
        };

        return map[f] || field || 'Поле';
      }

      function prettyRole(v){
        const s = (v ?? '') + '';
        const m = {
          'tenant_admin':'Директор ОП',
          'admin':'Руководитель ТС',
          'viewer':'Продавец',
          'owner':'owner'
        };
        return m[s] || s;
      }

      function prettyBool(v){
        if (v === true) return 'Да';
        if (v === false) return 'Нет';
        if (v === 1) return 'Да';
        if (v === 0) return 'Нет';
        if (v === 'true') return 'Да';
        if (v === 'false') return 'Нет';
        return (v ?? '—') + '';
      }

      function normalizeValue(field, v){
        const f = (field || '').toLowerCase();
        if (v === null || typeof v === 'undefined' || v === '') return '—';

        if (f.includes('birth_date')) {
          if (typeof v === 'number' || (typeof v === 'string' && v.trim() !== '' && isFinite(Number(v)))) {
            const iso = excelSerialToISO(v);
            if (iso) return prettyDateISOToRU(iso);
          }
          const s = (v ?? '') + '';
          if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return prettyDateISOToRU(s);
          return s;
        }

        if (f.endsWith('.role') || f === 'user.role' || f === 'employee.role') {
          return prettyRole(v);
        }

        if (f.includes('is_active')) {
          return prettyBool(v);
        }

        return (v ?? '') + '';
      }

      function actionTitle(it){
        const a = (it.action || '').toLowerCase();
        const et = (it.entity_type || '').toLowerCase();

        const map = {
          'schedule_save': 'Изменено расписание',
          'schedule_copy': 'Скопировано расписание',

          'employee_create': 'Добавлен сотрудник',
          'employee_update': 'Изменены данные сотрудника',
          'employee_import': 'Импорт сотрудников Excel',

          'group_create': 'Добавлена группа',
          'group_update': 'Изменена группа',
          'group_toggle': 'Изменена активность группы',
          'group_move_employees': 'Перемещены сотрудники между группами',
        };

        if (map[a]) return map[a];

        if (et === 'schedule') return 'Изменение расписания';
        if (et === 'employee') return 'Изменение сотрудника';
        if (et === 'group') return 'Изменение группы';
        return it.action || 'Событие';
      }

      function buildUrl(){
        const p = new URLSearchParams();
        p.set('limit', String(limit));
        p.set('offset', String(offset));
        p.set('with_total', '1');

        if (fType.value) p.set('entity_type', fType.value);
        if (fQ.value.trim()) p.set('q', fQ.value.trim());

        if (fFrom.value) p.set('from', fFrom.value + ' 00:00:00');
        if (fTo.value) p.set('to', fTo.value + ' 23:59:59');

        return '/api/audit_get.php?' + p.toString();
      }

      function renderChangesTable(changes){
        if (!changes || !Array.isArray(changes) || changes.length === 0) {
          return `<div class="muted small">Нет деталей</div>`;
        }

        if (changes.length === 1 && changes[0] && changes[0].changes && Array.isArray(changes[0].changes)) {
          changes = changes[0].changes;
        }

        const rows = changes
          .filter(x => x && (x.field || x.before !== undefined || x.after !== undefined))
          .map(x => {
            const field = x.field || 'Поле';
            const before = normalizeValue(field, x.before);
            const after = normalizeValue(field, x.after);
            return `
              <tr>
                <td class="k">${esc(prettyField(field))}</td>
                <td>${esc(before)}</td>
                <td>${esc(after)}</td>
              </tr>
            `;
          }).join('');

        if (!rows) return `<div class="muted small">Нет деталей</div>`;

        return `
          <table class="mini-table">
            <thead>
              <tr>
                <th style="width:38%">Что</th>
                <th style="width:31%">Было</th>
                <th style="width:31%">Стало</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        `;
      }

      function renderGroupDetails(it){
        const meta = it.meta || {};
        const changes = it.changes || [];

        const title = esc(meta.title || '');
        const code = esc(meta.code || meta.from_group_code || '');
        const gid = esc(meta.group_id ?? it.entity_id ?? '');

        const pills = [];
        if (title) pills.push(`<span class="pill">${title}</span>`);
        if (code) pills.push(`<span class="pill">код: ${code}</span>`);
        if (gid) pills.push(`<span class="pill">ID: ${gid}</span>`);

        if ((it.action || '').toLowerCase() === 'group_move_employees') {
          const from = meta.from_group_title ? `${meta.from_group_title} (${meta.from_group_code || ''})` : (meta.from_group_code || '');
          const to = meta.to_group_title ? `${meta.to_group_title} (${meta.to_group_code || ''})` : (meta.to_group_code || '');
          const cnt = meta.employees_count ?? 0;

          const extra = [];
          if (from && to) extra.push(`<span class="pill">перемещение: ${esc(from)} → ${esc(to)}</span>`);
          if (cnt) extra.push(`<span class="pill">сотрудников: ${esc(cnt)}</span>`);
          if (meta.schedule_moved) extra.push(`<span class="pill">расписание перенесено</span>`);

          let empList = '';
          if (Array.isArray(meta.employees) && meta.employees.length > 0) {
            const names = meta.employees.slice(0, 12).map(e => esc(e.full_name || '')).filter(Boolean);
            if (names.length) {
              empList = `<div class="muted small" style="margin-top:8px">Сотрудники: ${names.join(', ')}${meta.employees.length > 12 ? ' …' : ''}</div>`;
            }
          }

          return `
            <details class="audit-details">
              <summary>Показать детали</summary>
              <div class="details-body">
                <div class="row">${pills.join(' ')}</div>
                <div style="margin-top:8px" class="row">${extra.join(' ')}</div>
                <div style="margin-top:10px">${renderChangesTable(changes)}</div>
                ${empList}
              </div>
            </details>
          `;
        }

        return `
          <details class="audit-details">
            <summary>Показать детали</summary>
            <div class="details-body">
              <div class="row">${pills.join(' ')}</div>
              <div style="margin-top:10px">${renderChangesTable(changes)}</div>
            </div>
          </details>
        `;
      }

      function renderEmployeeDetails(it){
        const meta = it.meta || {};
        const changes = it.changes || [];

        const full = meta.full_name ? `<span class="pill"><span class="one-line">${esc(meta.full_name)}</span></span>` : '';
        const id = (meta.employee_id ?? it.entity_id) ? `<span class="pill">ID: ${esc(meta.employee_id ?? it.entity_id)}</span>` : '';
        const grp = meta.group_code ? `<span class="pill">группа: ${esc(meta.group_code)}</span>` : '';

        const moved = (meta.from_group || meta.from_group_code) && (meta.to_group || meta.to_group_code)
          ? `<span class="pill">перемещение: ${esc(meta.from_group || meta.from_group_code)} → ${esc(meta.to_group || meta.to_group_code)}</span>` : '';

        const scheduleMoved = meta.schedule_moved ? `<span class="pill">расписание перенесено</span>` : '';

        return `
          <details class="audit-details">
            <summary>Показать детали</summary>
            <div class="details-body">
              <div class="row">${[full,id,grp].filter(Boolean).join(' ')}</div>
              <div style="margin-top:8px" class="row">${[moved, scheduleMoved].filter(Boolean).join(' ')}</div>
              <div style="margin-top:10px">${renderChangesTable(changes)}</div>
            </div>
          </details>
        `;
      }

      function renderImportDetails(it){
        const meta = it.meta || {};
        const changes = it.changes || [];
        const file = meta.file ? `<span class="pill">файл: ${esc(meta.file)}</span>` : '';
        const ins = (meta.inserted ?? meta.added) !== undefined ? `<span class="pill">добавлено: ${esc(meta.inserted ?? meta.added)}</span>` : '';
        const upd = meta.updated !== undefined ? `<span class="pill">обновлено: ${esc(meta.updated)}</span>` : '';
        const users = meta.users_touched !== undefined ? `<span class="pill">аккаунтов: ${esc(meta.users_touched)}</span>` : '';

        let blocks = '';
        if (Array.isArray(changes) && changes.length) {
          blocks = changes.map((c, i) => {
            const type = (c.type || '').toLowerCase();
            const title = type === 'created' ? 'Создан' : (type === 'updated' ? 'Обновлён' : 'Запись');
            const m = c.meta || c;
            const name = m.full_name ? esc(m.full_name) : '';
            const eid = m.employee_id ? ` (ID ${esc(m.employee_id)})` : '';
            const inner = renderChangesTable(c.changes || c.items || c.fields || []);
            return `
              <div style="border:1px solid #e5e7eb;border-radius:12px;background:#fff;padding:10px;margin-top:10px">
                <div style="font-weight:700">${title}: ${name}${eid} <span class="muted">#${i+1}</span></div>
                <div style="margin-top:8px">${inner}</div>
              </div>
            `;
          }).join('');
        }

        return `
          <details class="audit-details">
            <summary>Показать детали</summary>
            <div class="details-body">
              <div class="row">${[file,ins,upd,users].filter(Boolean).join(' ')}</div>
              ${blocks ? `<div style="margin-top:6px">${blocks}</div>` : `<div class="muted small" style="margin-top:10px">Детали импорта не переданы</div>`}
            </div>
          </details>
        `;
      }

      function renderScheduleDetails(it){
        const meta = it.meta || {};
        const changes = it.changes || [];

        const pills = [];
        if (meta.group_code) pills.push(`<span class="pill">группа: ${esc(meta.group_code)}</span>`);
        if (meta.week && meta.year) pills.push(`<span class="pill">неделя: ${esc(meta.week)}/${esc(meta.year)}</span>`);
        if (meta.changes_count !== undefined) pills.push(`<span class="pill">изменений: ${esc(meta.changes_count)}</span>`);
        if (meta.saved !== undefined) pills.push(`<span class="pill">сохранено: ${esc(meta.saved)}</span>`);
        if (meta.copied !== undefined) pills.push(`<span class="pill">скопировано: ${esc(meta.copied)}</span>`);

        // ====== HOTFIX: slots(48) -> интервалы времени (06:00..05:00) ======
        function hhmm(totalMin){
          // totalMin может быть > 24*60, приводим по кругу суток
          const day = 24*60;
          let m = totalMin % day;
          if (m < 0) m += day;
          const h = Math.floor(m/60);
          const mm = m % 60;
          return `${pad2(h)}:${pad2(mm)}`;
        }

        function slotsToRanges(slots){
          if (!slots || typeof slots !== 'string') return '';
          const s = slots.trim();
          if (s.length !== 48) return '';
          // 0-й слот = 06:00-06:30
          const startBaseMin = 6*60;
          const ranges = [];
          let i = 0;
          while (i < 48){
            if (s[i] !== '1'){ i++; continue; }
            const start = i;
            while (i < 48 && s[i] === '1') i++;
            const end = i; // exclusive
            const stMin = startBaseMin + start*30;
            const enMin = startBaseMin + end*30;
            ranges.push(`${hhmm(stMin)}–${hhmm(enMin)}`);
          }
          return ranges.join(', ');
        }

        function statusAndSlots(obj){
          if (!obj || typeof obj !== 'object') return '—';
          const st = (obj.status ?? '') + '';
          // пробуем достать slots (как в твоём логе), иначе оставим как было (time) если вдруг есть
          const ranges = slotsToRanges(obj.slots || obj.slots_str || obj.slots48 || '');
          const time = (obj.time ?? '') + '';
          const tail = ranges || time;
          if (st && tail) return `${st}, ${tail}`;
          if (st) return st;
          if (tail) return tail;
          return '—';
        }
        // ====== /HOTFIX ======

        let rows = '';
        if (Array.isArray(changes) && changes.length) {
          rows = changes.map(c => {
            const dt = esc(c.date || '');
            const emp = esc(c.full_name || c.employee_name || '');
            const before = statusAndSlots(c.before || null);
            const after  = statusAndSlots(c.after || null);
            return `
              <tr>
                <td>${dt}</td>
                <td>${emp}</td>
                <td>${esc(before)}</td>
                <td>${esc(after)}</td>
              </tr>
            `;
          }).join('');
        }

        return `
          <details class="audit-details">
            <summary>Показать детали</summary>
            <div class="details-body">
              <div class="row">${pills.join(' ')}</div>
              ${rows ? `
                <table class="mini-table" style="margin-top:10px">
                  <thead>
                    <tr>
                      <th style="width:120px">Дата</th>
                      <th>Сотрудник</th>
                      <th style="width:170px">Было</th>
                      <th style="width:170px">Стало</th>
                    </tr>
                  </thead>
                  <tbody>${rows}</tbody>
                </table>
              ` : `<div class="muted small" style="margin-top:10px">Детали изменений не переданы</div>`}
            </div>
          </details>
        `;
      }

      function renderDetails(it){
        const et = (it.entity_type || '').toLowerCase();
        const act = (it.action || '').toLowerCase();

        if (et === 'employee' && act === 'employee_import') return renderImportDetails(it);
        if (et === 'employee') return renderEmployeeDetails(it);
        if (et === 'group') return renderGroupDetails(it);
        if (et === 'schedule') return renderScheduleDetails(it);

        return `
          <details class="audit-details">
            <summary>Показать детали</summary>
            <div class="details-body">
              ${renderChangesTable(it.changes || [])}
            </div>
          </details>
        `;
      }

      function render(items){
        if (!items || items.length === 0){
          tbody.innerHTML = `<tr><td colspan="4" class="muted">Пока нет записей</td></tr>`;
          return;
        }

        tbody.innerHTML = items.map(it => {
          const who = it.actor_username ? it.actor_username : '—';
          const action = actionTitle(it);

          return `
            <tr>
              <td>${esc(fmtTime(it.created_at))}</td>
              <td><b>${esc(who)}</b></td>
              <td><span class="pill">${esc(action)}</span></td>
              <td>${renderDetails(it)}</td>
            </tr>
          `;
        }).join('');
      }

      async function load(){
        tbody.innerHTML = `<tr><td colspan="4" class="muted">Загрузка…</td></tr>`;
        try{
          const res = await fetch(buildUrl(), {credentials:'same-origin'});
          const data = await res.json();
          if (!data || !data.ok){
            throw new Error((data && data.error) ? data.error : 'bad_response');
          }
          render(data.items || []);
          const total = (typeof data.total === 'number') ? data.total : null;
          pageInfo.textContent = total === null
            ? `Показаны записи: ${offset + 1}…${offset + (data.items?.length || 0)}`
            : `Показаны записи: ${total === 0 ? 0 : (offset + 1)}…${offset + (data.items?.length || 0)} из ${total}`;
          btnPrev.disabled = (offset <= 0);
          btnNext.disabled = (total !== null) ? (offset + limit >= total) : ((data.items?.length || 0) < limit);
        }catch(e){
          tbody.innerHTML = `<tr><td colspan="4" style="color:#b91c1c">Ошибка: ${esc(e.message || String(e))}</td></tr>`;
          pageInfo.textContent = '';
        }
      }

      btnApply.addEventListener('click', function(){
        offset = 0;
        load();
      });
      btnPrev.addEventListener('click', function(){
        offset = Math.max(0, offset - limit);
        load();
      });
      btnNext.addEventListener('click', function(){
        offset = offset + limit;
        load();
      });

      // по умолчанию: последние 7 дней
      try{
        const d = new Date();
        const to = d.toISOString().slice(0,10);
        d.setDate(d.getDate() - 7);
        const from = d.toISOString().slice(0,10);
        fFrom.value = from;
        fTo.value = to;
      }catch(_){}

      load();
    })();
    </script>

    </body></html>
    <?php
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo "<pre style='white-space:pre-wrap;font:14px/1.3 monospace;background:#fee2e2;border:1px solid #fecaca;padding:12px;border-radius:10px'>";
    echo "ADMIN ERROR:\n";
    echo htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    echo "\n\n";
    echo htmlspecialchars($e->getFile() . ':' . $e->getLine(), ENT_QUOTES, 'UTF-8');
    echo "</pre>";
    exit;
}
