<?php
// api/admin/tenant_switch.php — ЕДИНСТВЕННЫЙ обработчик переключения tenant

declare(strict_types=1);

require_once __DIR__ . '/../utils.php';

// PHP7-safe
if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

// фаталы → JSON (чтобы не было 502)
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'error' => 'fatal',
        'details' => ($e['message'] ?? 'unknown') . ' @ ' . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
});

require_once __DIR__ . '/../security.php';
require_same_origin();
require_post();

header('Content-Type: application/json; charset=utf-8');

$ctx  = require __DIR__ . '/../guard.php';
$role = strtolower(trim((string)($ctx['role'] ?? '')));

if ($role !== 'owner') {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'forbidden'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

$tid = (int)($_POST['tid'] ?? 0);
if ($tid <= 0) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'bad_tid'], JSON_UNESCAPED_UNICODE);
    exit;
}

/** @var PDO $pdo */
$pdo = $ctx['pdo'];

// ❗️разрешаем ТОЛЬКО активные подразделения
$st = $pdo->prepare("
    SELECT id
    FROM tenants
    WHERE id = :id AND is_active = 1
    LIMIT 1
");
$st->execute([':id' => $tid]);

if ((int)$st->fetchColumn() <= 0) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'tenant_not_active'], JSON_UNESCAPED_UNICODE);
    exit;
}

$_SESSION['owner_tid'] = $tid;
session_write_close();

echo json_encode(['ok'=>true,'tid'=>$tid], JSON_UNESCAPED_UNICODE);
exit;
