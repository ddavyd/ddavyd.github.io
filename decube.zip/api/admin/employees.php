<?php
// api/admin/employees.php — сотрудники (PG + users join) + фильтр активных

declare(strict_types=1);

$ctx = require __DIR__ . '/../guard.php';

$pdo  = $ctx['pdo'];
$role = strtolower(trim((string)($ctx['role'] ?? '')));
$tid  = (int)($ctx['tid'] ?? 0);

if (!in_array($role, ['owner', 'tenant_admin', 'admin'], true)) {
    http_response_code(403);
    echo 'no_permission';
    exit;
}

require __DIR__ . '/_header.php';
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function ensure_employee_active_column(PDO $pdo): string {
    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='employees' AND column_name='is_active'
            LIMIT 1
        ");
        $st->execute();
        $t = strtolower((string)($st->fetchColumn() ?: ''));
        if ($t !== '') return $t;
    } catch (Throwable $e) {}

    try {
        $pdo->exec("ALTER TABLE employees ADD COLUMN is_active boolean NOT NULL DEFAULT TRUE");
        return 'boolean';
    } catch (Throwable $e) {
        return 'missing';
    }
}

$activeType = ensure_employee_active_column($pdo);
$activeExpr = ($activeType === 'integer')
    ? "(COALESCE(e.is_active,1)::int <> 0)"
    : "(COALESCE(e.is_active,TRUE) = TRUE)";

$q = trim((string)($_GET['q'] ?? ''));
$showInactive = !empty($_GET['show_inactive']); // чекбокс

$where = "e.tenant_id = :tid";
$params = [':tid' => $tid];

if (!$showInactive) {
    $where .= " AND {$activeExpr}";
}

if ($q !== '') {
    $where .= " AND (
        e.full_name ILIKE :q
        OR COALESCE(e.tab_no,'') ILIKE :q
        OR COALESCE(e.email,'') ILIKE :q
        OR COALESCE(e.group_code,'') ILIKE :q
        OR COALESCE(u.username,'') ILIKE :q
        OR COALESCE(u.email,'') ILIKE :q
    )";
    $params[':q'] = '%' . $q . '%';
}

$st = $pdo->prepare("
    SELECT
        e.id, e.full_name, e.group_code, e.role, e.tab_no, e.birth_date,
        e.email AS employee_email,
        {$activeExpr} AS is_active,
        u.username AS login,
        u.email AS user_email
    FROM employees e
    LEFT JOIN users u
      ON u.employee_id = e.id AND u.tenant_id = e.tenant_id
    WHERE {$where}
    ORDER BY e.full_name
");
$st->execute($params);
$rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

?>
<div class="app-container" style="max-width:1100px;">
  <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
    <h2 style="margin:0;">Сотрудники</h2>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a href="/?r=admin" class="btn">← Назад</a>
      <a href="/?r=admin_employee_edit" class="btn">➕ Добавить сотрудника</a>
      <?php if (in_array($role, ['owner','tenant_admin'], true)): ?>
        <a href="/?r=admin_employees_import" class="btn">⬆️ Импорт</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="card" style="margin-top:12px;">
    <form method="get" action="/" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:0;">
      <input type="hidden" name="r" value="admin_employees">
      <input type="text" name="q" value="<?= h($q) ?>" placeholder="Поиск (имя/логин/email/таб№/группа)">
      <label class="muted" style="display:flex;gap:8px;align-items:center;">
        <input type="checkbox" name="show_inactive" value="1" <?= $showInactive ? 'checked' : '' ?>>
        Показать неактивных
      </label>
      <button class="btn" type="submit">Найти</button>
      <span class="muted" style="margin-left:auto">Найдено: <b><?= (int)count($rows) ?></b></span>
    </form>
  </div>

  <div class="card" style="margin-top:12px;">
    <?php if (!$rows): ?>
      <div class="muted">Сотрудников нет</div>
    <?php else: ?>
      <table>
        <thead>
          <tr>
            <th style="width:70px;">ID</th>
            <th>Имя</th>
            <th style="width:120px;">Группа</th>
            <th style="width:120px;">Роль</th>
            <th style="width:120px;">Таб№</th>
            <th style="width:170px;">Логин</th>
            <th>Email</th>
            <th style="width:120px;">Статус</th>
            <th style="width:70px;"></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $e): ?>
            <?php
              $email = trim((string)($e['user_email'] ?? ''));
              if ($email === '') $email = trim((string)($e['employee_email'] ?? ''));
              $isActive = !empty($e['is_active']);
            ?>
            <tr style="<?= $isActive ? '' : 'opacity:0.6;' ?>">
              <td><?= (int)$e['id'] ?></td>
              <td><?= h((string)$e['full_name']) ?></td>
              <td><?= h((string)($e['group_code'] ?? '')) ?></td>
              <td><?= h((string)($e['role'] ?? '')) ?></td>
              <td><?= h((string)($e['tab_no'] ?? '')) ?></td>
              <td><?= h((string)($e['login'] ?? '')) ?></td>
              <td><?= h($email) ?></td>
              <td><?= $isActive ? '✅ активен' : '⛔ неактивен' ?></td>
              <td style="text-align:right;">
                <a class="btn" href="/?r=admin_employee_edit&id=<?= (int)$e['id'] ?>">✏️</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>

</body></html>
