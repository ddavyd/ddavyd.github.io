<?php
declare(strict_types=1);

require_once __DIR__ . '/../security.php';
require_same_origin(true);

$ctx = require __DIR__ . '/../guard.php';

$role = strtolower((string)($ctx['role'] ?? ''));
if ($role !== 'owner') {
    http_response_code(403);
    json_response(['error' => 'forbidden']);
    exit;
}

// CSRF
$csrf = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if ($csrf === '' || !hash_equals($_SESSION['csrf'] ?? '', $csrf)) {
    http_response_code(403);
    json_response(['error' => 'csrf_failed']);
    exit;
}

// Удаляем файлы лимита
$files = glob(sys_get_temp_dir() . '/planning_rl_*.json') ?: [];
$deleted = 0;

foreach ($files as $f) {
    if (is_file($f) && @unlink($f)) {
        $deleted++;
    }
}

// Аудит (коротко, без деталей)
try {
    $pdo = $ctx['pdo'];
    $stmt = $pdo->prepare("
        INSERT INTO audit_log
        (tenant_id, user_id, action, summary, created_at)
        VALUES (:tid, :uid, 'reset_rate_limits', :summary, now())
    ");
    $stmt->execute([
        ':tid' => $ctx['tid'],
        ':uid' => $ctx['uid'],
        ':summary' => "Deleted {$deleted} rate-limit files",
    ]);
} catch (\Throwable $e) {
    // аудит не должен ломать функционал
}

json_response([
    'ok' => true,
    'deleted' => $deleted,
]);
