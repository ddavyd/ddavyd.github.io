<?php
// admin/tenant_join_code.php — код регистрации (owner)

declare(strict_types=1);

$ctx = require __DIR__ . '/../guard.php';
$pdo  = $ctx['pdo'];
$user = $ctx['user'];
$role = $ctx['role'];
$tid  = (int)$ctx['tid'];

require __DIR__ . '/_header.php';


if ($role !== 'owner') {
    http_response_code(403);
    echo 'no_permission';
    exit;
}

$err = '';
$ok  = '';

$tenantId = (int)($_GET['tenant_id'] ?? $tid);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $tenantId = (int)($_POST['tenant_id'] ?? 0);
        if ($tenantId <= 0) throw new RuntimeException('Выберите подразделение');

        $newCode = bin2hex(random_bytes(4)); // 8 символов
        $st = $pdo->prepare("UPDATE tenants SET join_code = :jc WHERE id = :id");
        $st->execute([':jc' => $newCode, ':id' => $tenantId]);

        $ok = 'Код обновлён';
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$tenants = [];
try {
    $st = $pdo->query("SELECT id, name, code, join_code FROM tenants ORDER BY id ASC");
    $tenants = $st ? ($st->fetchAll(PDO::FETCH_ASSOC) ?: []) : [];
} catch (Throwable $e) {
    $tenants = [];
}

?>
<div class="app-container" style="max-width:980px;">
  <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
    <h2 style="margin:0;">Код регистрации</h2>
    <a class="btn" href="/?r=admin">← Назад</a>
  </div>

  <?php if ($err): ?><div class="error" style="margin-top:10px;"><?= h($err) ?></div><?php endif; ?>
  <?php if ($ok): ?><div class="ok" style="margin-top:10px;"><?= h($ok) ?></div><?php endif; ?>

  <div class="card" style="margin-top:12px;">
    <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:end">
      <div>
        <label>Подразделение<br>
          <select name="tenant_id" required>
            <option value="">— выбери —</option>
            <?php foreach ($tenants as $t): ?>
              <?php
                $id = (int)$t['id'];
                $label = trim((string)$t['name'] . ((string)$t['code'] !== '' ? ' (' . (string)$t['code'] . ')' : ''));
              ?>
              <option value="<?= $id ?>" <?= ($id === $tenantId ? 'selected' : '') ?>>
                <?= h($label !== '' ? $label : ('#'.$id)) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </label>
      </div>

      <button type="submit">Сгенерировать новый код</button>
    </form>
  </div>

  <div class="card" style="margin-top:12px;">
    <h3 style="margin-top:0;">Текущие коды</h3>
    <table class="table" style="width:100%;border-collapse:collapse;">
      <thead>
        <tr>
          <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">ID</th>
          <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Name</th>
          <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Code</th>
          <th style="text-align:left;padding:8px;border-bottom:1px solid #e5e7eb;">Join code</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($tenants as $t): ?>
          <tr>
            <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= (int)$t['id'] ?></td>
            <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= h((string)$t['name']) ?></td>
            <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= h((string)$t['code']) ?></td>
            <td style="padding:8px;border-bottom:1px solid #f1f5f9;"><?= h((string)($t['join_code'] ?? '')) ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</body></html>
