<?php
// admin/index.php — главная админки (анти-502, без метрик)

declare(strict_types=1);

@ini_set('display_errors', '0');
error_reporting(E_ALL);

// warnings/notices -> exception
set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

// фатал -> нормальный HTML (чтобы увидеть, что именно)
register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo "<pre style='white-space:pre-wrap;font:14px/1.3 monospace;background:#fff3cd;border:1px solid #ffeeba;padding:12px;border-radius:10px'>";
    echo "ADMIN FATAL:\n";
    echo htmlspecialchars(($e['message'] ?? 'unknown') . "\n" . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0), ENT_QUOTES, 'UTF-8');
    echo "</pre>";
});

try {
    if (!isset($ctx) || !is_array($ctx)) {
        $ctx = require __DIR__ . '/../guard.php';
    }

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $user = $ctx['user'] ?? [];
    $role = strtolower(trim((string)($ctx['role'] ?? '')));
    $tid  = (int)($ctx['tid'] ?? 0);

    // ✅ переключение подразделения через POST (owner), без API
    if ($role === 'owner' && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST'
        && (string)($_POST['action'] ?? '') === 'switch_tenant') {

        if (session_status() === PHP_SESSION_NONE) @session_start();

        $newTid = (int)($_POST['tenant_id'] ?? 0);
        if ($newTid > 0) {
            $sql = "SELECT id FROM tenants WHERE id = :id" . active_where($pdo, 'tenants', 'is_active') . " LIMIT 1";
            $st = $pdo->prepare($sql);
            $st->execute([':id' => $newTid]);
            if ((int)$st->fetchColumn() > 0) {
                $_SESSION['owner_tid'] = $newTid;
            }
        }

        session_write_close();
        header('Location: /?r=admin');
        exit;
    }

    require __DIR__ . '/_header.php';

    // tenant info
    $tenantName = '';
    $tenantCode = '';
    try {
        if ($tid > 0) {
            $st = $pdo->prepare("SELECT name, code FROM tenants WHERE id = :id LIMIT 1");
            $st->execute([':id' => $tid]);
            $t = $st->fetch(PDO::FETCH_ASSOC) ?: [];
            $tenantName = (string)($t['name'] ?? '');
            $tenantCode = (string)($t['code'] ?? '');
        }
    } catch (Throwable $ignore) {}

    ?>
    <style>
      .wrap{max-width:980px;margin:0 auto;padding:12px}
      .card{background:#fff;border:1px solid rgba(0,0,0,.10);border-radius:16px;padding:14px;box-shadow:0 4px 12px rgba(0,0,0,.06)}
      .pill{display:inline-block;padding:3px 10px;border-radius:999px;background:#f1f5f9;border:1px solid #e5e7eb;margin-left:6px;font-size:13px}
      .muted{color:#64748b}
      .row{display:flex;gap:10px;flex-wrap:wrap}
    </style>

    <div class="wrap">
      <div class="card">
        <div style="font-size:18px;font-weight:700;">Админка</div>

        <div class="muted" style="margin-top:6px;">
          <b>Подразделение:</b>
          <?= htmlspecialchars($tenantName !== '' ? $tenantName : ('#' . $tid), ENT_QUOTES, 'UTF-8') ?>
          <span class="pill">#<?= (int)$tid ?></span>
          <?php if ($tenantCode !== ''): ?>
            <span class="pill"><?= htmlspecialchars($tenantCode, ENT_QUOTES, 'UTF-8') ?></span>
          <?php endif; ?>
        </div>

        <div style="margin-top:10px;">
          <b>Пользователь:</b> <?= htmlspecialchars((string)($user['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?>
          <span class="pill"><?= htmlspecialchars((string)$role, ENT_QUOTES, 'UTF-8') ?></span>
        </div>

        <?php if ($role === 'owner' && !empty($tenantsList ?? [])): ?>
          <hr style="margin:14px 0;border:none;border-top:1px solid #e5e7eb">

          <div style="font-weight:700;margin-bottom:8px;">Переключить подразделение</div>

          <form method="post" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:0;">
            <input type="hidden" name="action" value="switch_tenant">
            <select name="tenant_id">
              <?php foreach (($tenantsList ?? []) as $t): ?>
                <option value="<?= (int)$t['id'] ?>" <?= ((int)$t['id'] === (int)($tid_eff ?? 0) ? 'selected' : '') ?>>
                  <?= htmlspecialchars((string)$t['label'], ENT_QUOTES, 'UTF-8') ?>
                </option>
              <?php endforeach; ?>
            </select>
            <button class="btn" type="submit">Применить</button>
            <span class="muted">Страница перезагрузится</span>
          </form>
        <?php endif; ?>

        <hr style="margin:14px 0;border:none;border-top:1px solid #e5e7eb">

        <div class="row">
  <a class="btn" href="/?r=admin_employees">👥 Сотрудники</a>
  <a class="btn" href="/?r=admin_groups">🗂 Группы</a>
  

  <?php if ($role === 'owner' || $role === 'tenant_admin'): ?>
    <a class="btn" href="/?r=admin_audit">🧾 Журнал</a>
  <?php endif; ?>

  <?php if ($role === 'owner'): ?>
    <a class="btn" href="/?r=admin_tenants">🏢 Подразделения</a>
  <?php endif; ?>
</div>

      </div>
    </div>

    </body></html>
    <?php
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: text/html; charset=utf-8');
    echo "<pre style='white-space:pre-wrap;font:14px/1.3 monospace;background:#fee2e2;border:1px solid #fecaca;padding:12px;border-radius:10px'>";
    echo "ADMIN ERROR:\n";
    echo htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
    echo "\n\n";
    echo htmlspecialchars($e->getFile() . ':' . $e->getLine(), ENT_QUOTES, 'UTF-8');
    echo "</pre>";
    exit;
}
