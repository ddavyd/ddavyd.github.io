<?php
// api/admin/guard.php — алиас на общий guard
// ВАЖНО: чтобы admin-эндпоинты и обычные API использовали один и тот же tenant/role/scope

declare(strict_types=1);

return require __DIR__ . '/../guard.php';