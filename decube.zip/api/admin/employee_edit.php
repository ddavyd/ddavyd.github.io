<?php
// admin/employee_edit.php — создание/редактирование сотрудника + user
// FIX:
// 1) перенос schedule_days при смене группы через карточку сотрудника
// 2) employees.role (emp_role) — бизнес-роль сотрудника
// 3) users.role НЕ перезаписываем из emp_role, если текущая users.role = 'owner' (и вообще не даём понизить owner)
// + AUDIT: employee_create / employee_update в public.audit_log

declare(strict_types=1);

$ctx = require __DIR__ . '/../guard.php';

$pdo  = $ctx['pdo'];
$role = strtolower(trim((string)($ctx['role'] ?? '')));
$tid  = (int)($ctx['tid'] ?? 0);
$user = $ctx['user'] ?? [];

if (!in_array($role, ['owner', 'tenant_admin', 'admin'], true)) {
    http_response_code(403);
    echo 'no_permission';
    exit;
}

require __DIR__ . '/_header.php';
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function ensure_employee_active_column(PDO $pdo): string {
    // вернёт тип: 'boolean'|'integer'|'missing'
    try {
        $st = $pdo->prepare("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='employees' AND column_name='is_active'
            LIMIT 1
        ");
        $st->execute();
        $t = strtolower((string)($st->fetchColumn() ?: ''));
        if ($t !== '') return $t;
    } catch (Throwable $e) {}

    // нет колонки -> добавим boolean
    try {
        $pdo->exec("ALTER TABLE employees ADD COLUMN is_active boolean NOT NULL DEFAULT TRUE");
        return 'boolean';
    } catch (Throwable $e) {
        return 'missing';
    }
}

function get_actor_user_id(array $ctx): int {
    $u = $ctx['user'] ?? null;
    if (is_array($u) && isset($u['id'])) return (int)$u['id'];
    if (isset($ctx['uid'])) return (int)$ctx['uid'];
    return 0;
}

function norm_bool($v): bool {
    if (is_bool($v)) return $v;
    if (is_numeric($v)) return ((int)$v) !== 0;
    $s = strtolower(trim((string)$v));
    return in_array($s, ['1','true','t','yes','y','on'], true);
}

function audit_insert(PDO $pdo, array $ctx, int $tid, string $action, string $entityType, ?string $entityId, array $meta, array $changes): void {
    if (empty($changes)) return;

    $actorId = get_actor_user_id($ctx);
    $actorRole = strtolower(trim((string)($ctx['role'] ?? '')));
    if ($actorId <= 0) return;

    $st = $pdo->prepare('
        INSERT INTO public.audit_log (tenant_id, actor_user_id, actor_role, action, entity_type, entity_id, meta, changes)
        VALUES (:tid, :uid, :arole, :action, :etype, :eid, :meta::jsonb, :changes::jsonb)
    ');
    $st->execute([
        ':tid'     => $tid,
        ':uid'     => $actorId,
        ':arole'   => $actorRole,
        ':action'  => $action,
        ':etype'   => $entityType,
        ':eid'     => $entityId,
        ':meta'    => json_encode($meta, JSON_UNESCAPED_UNICODE),
        ':changes' => json_encode($changes, JSON_UNESCAPED_UNICODE),
    ]);
}

$activeType = ensure_employee_active_column($pdo);

$id = (int)($_GET['id'] ?? 0);
$isNew = ($id <= 0);

$err = '';
$ok  = '';

// groups list
$groups = [];
try {
    $st = $pdo->prepare('SELECT code, title, (COALESCE(is_active,0)::int <> 0) AS active FROM "groups" WHERE tenant_id = :tid ORDER BY sort_order, title');
    $st->execute([':tid' => $tid]);
    $groups = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {}

$employee = [
    'id'         => 0,
    'full_name'  => '',
    'group_code' => 'unassigned',
    'role'       => 'viewer',
    'tab_no'     => '',
    'birth_date' => '',
    'email'      => '',
    'is_active'  => 1,
];

$userRow = ['username' => '', 'email' => '', 'role' => 'viewer', 'id' => 0];

if (!$isNew) {
    $st = $pdo->prepare('SELECT * FROM employees WHERE id = :id AND tenant_id = :tid LIMIT 1');
    $st->execute([':id' => $id, ':tid' => $tid]);
    $employee = $st->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$employee) {
        echo "<div class='card' style='max-width:900px;margin:12px auto;color:#b91c1c'>Сотрудник не найден</div></body></html>";
        exit;
    }

    $st = $pdo->prepare('SELECT id, username, email, role FROM users WHERE tenant_id = :tid AND employee_id = :eid LIMIT 1');
    $st->execute([':tid' => $tid, ':eid' => $id]);
    $u = $st->fetch(PDO::FETCH_ASSOC);
    if ($u) $userRow = $u + $userRow;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // --- старые значения из БД (важно для переноса schedule_days и защиты owner) ---
        $oldGroupCode = 'unassigned';
        $currentEmpRole = 'viewer';
        $currentUserRole = null;
        $currentUserId = 0;

        // для аудита
        $beforeEmployee = null; // array|null
        $beforeUser = null;     // array|null

        if (!$isNew) {
            $st = $pdo->prepare('SELECT id, tenant_id, group_code, full_name, role, tab_no, birth_date, email, is_active FROM employees WHERE id = :id AND tenant_id = :tid LIMIT 1');
            $st->execute([':id' => $id, ':tid' => $tid]);
            $beforeEmployee = $st->fetch(PDO::FETCH_ASSOC) ?: null;

            $oldGroupCode = trim((string)($beforeEmployee['group_code'] ?? ''));
            if ($oldGroupCode === '') $oldGroupCode = 'unassigned';

            $currentEmpRole = trim((string)($beforeEmployee['role'] ?? 'viewer'));
            if ($currentEmpRole === '') $currentEmpRole = 'viewer';

            $st = $pdo->prepare('SELECT id, username, email, role FROM users WHERE tenant_id = :tid AND employee_id = :eid LIMIT 1');
            $st->execute([':tid' => $tid, ':eid' => $id]);
            $beforeUser = $st->fetch(PDO::FETCH_ASSOC) ?: null;

            if ($beforeUser) {
                $currentUserId = (int)($beforeUser['id'] ?? 0);
                $currentUserRole = strtolower(trim((string)($beforeUser['role'] ?? '')));
            }
        }

        $full_name  = trim((string)($_POST['full_name'] ?? ''));
        $group_code = trim((string)($_POST['group_code'] ?? ''));
        $tab_no     = trim((string)($_POST['tab_no'] ?? ''));
        $birth_date = trim((string)($_POST['birth_date'] ?? ''));
        $emp_email  = trim((string)($_POST['emp_email'] ?? ''));

        $emp_role = trim((string)($_POST['emp_role'] ?? 'viewer')); // бизнес-роль сотрудника (НЕ для users.role)

        $isActiveBool = !empty($_POST['is_active']);

        $login      = trim((string)($_POST['login'] ?? ''));
        $user_email = trim((string)($_POST['user_email'] ?? ''));
        $new_pass   = (string)($_POST['new_password'] ?? '');

        if ($full_name === '') throw new RuntimeException('Укажи имя сотрудника');
        if ($group_code === '') $group_code = 'unassigned';

        $allowedEmpRoles = ['tenant_admin','admin','viewer'];
        if ($emp_role === '') $emp_role = 'viewer';
        if (!in_array($emp_role, $allowedEmpRoles, true)) throw new RuntimeException('Некорректная роль сотрудника');

        if ($birth_date !== '' && !preg_match('~^\d{4}-\d{2}-\d{2}$~', $birth_date)) {
            throw new RuntimeException('Дата рождения должна быть в формате YYYY-MM-DD');
        }

        // active value depends on column type
        if ($activeType === 'integer') {
            $activeVal = $isActiveBool ? 1 : 0;
        } else {
            $activeVal = $isActiveBool ? 'true' : 'false';
        }

        $pdo->beginTransaction();
        try {
            $actionForAudit = $isNew ? 'employee_create' : 'employee_update';
            $scheduleMoved = false;

            if ($isNew) {
                $st = $pdo->prepare('
                    INSERT INTO employees (tenant_id, group_code, full_name, role, tab_no, birth_date, email, is_active)
                    VALUES (:tid, :g, :n, :r, :tab, :bd, :em, :act)
                    RETURNING id
                ');
                $st->execute([
                    ':tid' => $tid,
                    ':g'   => $group_code,
                    ':n'   => $full_name,
                    ':r'   => $emp_role,
                    ':tab' => ($tab_no !== '' ? $tab_no : null),
                    ':bd'  => ($birth_date !== '' ? $birth_date : null),
                    ':em'  => ($emp_email !== '' ? $emp_email : null),
                    ':act' => $activeVal,
                ]);
                $id = (int)($st->fetchColumn() ?: 0);
                if ($id <= 0) throw new RuntimeException('Не удалось создать сотрудника');
                $isNew = false;

                $oldGroupCode = $group_code;
                $currentEmpRole = $emp_role;

                $currentUserRole = null;
                $currentUserId = 0;

            } else {
                $st = $pdo->prepare('
                    UPDATE employees
                    SET group_code = :g, full_name = :n, role = :r, tab_no = :tab, birth_date = :bd, email = :em, is_active = :act
                    WHERE id = :id AND tenant_id = :tid
                ');
                $st->execute([
                    ':g'   => $group_code,
                    ':n'   => $full_name,
                    ':r'   => $emp_role,
                    ':tab' => ($tab_no !== '' ? $tab_no : null),
                    ':bd'  => ($birth_date !== '' ? $birth_date : null),
                    ':em'  => ($emp_email !== '' ? $emp_email : null),
                    ':act' => $activeVal,
                    ':id'  => $id,
                    ':tid' => $tid,
                ]);

                // перенос расписания при смене группы
                $newGroupCode = trim($group_code);
                if ($newGroupCode === '') $newGroupCode = 'unassigned';

                if (trim($oldGroupCode) !== $newGroupCode) {
                    $sqlDel = "
                        DELETE FROM schedule_days t
                        USING schedule_days s
                        WHERE t.tenant_id = :tid
                          AND TRIM(t.group_code) = TRIM(:to)
                          AND s.tenant_id = :tid
                          AND TRIM(s.group_code) = TRIM(:from)
                          AND t.date = s.date
                          AND t.employee_id = s.employee_id
                          AND t.employee_id = :eid
                    ";
                    $pdo->prepare($sqlDel)->execute([
                        ':tid'  => $tid,
                        ':to'   => $newGroupCode,
                        ':from' => $oldGroupCode,
                        ':eid'  => $id,
                    ]);

                    $sqlUpd = "
                        UPDATE schedule_days
                        SET group_code = :to
                        WHERE tenant_id = :tid
                          AND employee_id = :eid
                          AND TRIM(group_code) = TRIM(:from)
                    ";
                    $pdo->prepare($sqlUpd)->execute([
                        ':tid'  => $tid,
                        ':eid'  => $id,
                        ':to'   => $newGroupCode,
                        ':from' => $oldGroupCode,
                    ]);

                    $scheduleMoved = true;
                }
            }

            // ===== USERS: create/update (НО: не понижаем owner) =====
            // Маппинг бизнес-роли сотрудника в роль пользователя (если надо)
            // Важно: owner — отдельная системная роль, её НЕ трогаем тут.
            $userRoleToSet = $emp_role;

            $passwordChanged = false;

            if ($login !== '') {
                $st = $pdo->prepare('SELECT id, role, username, email FROM users WHERE tenant_id = :tid AND employee_id = :eid LIMIT 1');
                $st->execute([':tid' => $tid, ':eid' => $id]);
                $uu = $st->fetch(PDO::FETCH_ASSOC) ?: null;
                $uid = $uu ? (int)($uu['id'] ?? 0) : 0;
                $existingUserRole = $uu ? strtolower(trim((string)($uu['role'] ?? ''))) : '';

                if ($uid <= 0) {
                    $passHash = password_hash($new_pass !== '' ? $new_pass : bin2hex(random_bytes(6)), PASSWORD_DEFAULT);
                    $st = $pdo->prepare('
                        INSERT INTO users (tenant_id, username, password_hash, role, employee_id, email)
                        VALUES (:tid, :u, :ph, :role, :eid, :em)
                    ');
                    $st->execute([
                        ':tid'  => $tid,
                        ':u'    => $login,
                        ':ph'   => $passHash,
                        ':role' => $userRoleToSet,
                        ':eid'  => $id,
                        ':em'   => ($user_email !== '' ? $user_email : null),
                    ]);
                    $passwordChanged = true; // пароль создан/задан
                } else {
                    $setRoleSql = '';
                    $params = [
                        ':u'   => $login,
                        ':em'  => ($user_email !== '' ? $user_email : null),
                        ':id'  => $uid,
                        ':tid' => $tid,
                    ];

                    if ($new_pass !== '') {
                        $params[':ph'] = password_hash($new_pass, PASSWORD_DEFAULT);
                        $setRoleSql = ', password_hash = :ph';
                        $passwordChanged = true;
                    }

                    // role обновляем только если существующая роль НЕ owner
                    if ($existingUserRole !== 'owner') {
                        $setRoleSql .= ', role = :role';
                        $params[':role'] = $userRoleToSet;
                    }

                    $st = $pdo->prepare("
                        UPDATE users
                        SET username = :u, email = :em{$setRoleSql}
                        WHERE id = :id AND tenant_id = :tid
                    ");
                    $st->execute($params);
                }
            } else {
                // логин не меняли: роль пользователя НЕ трогаем здесь вообще
                // (иначе снова есть шанс перетереть owner на viewer)
            }

            // ===== AUDIT: собираем before/after и пишем одним событием =====

            // after employee
            $st = $pdo->prepare('SELECT id, tenant_id, group_code, full_name, role, tab_no, birth_date, email, is_active FROM employees WHERE id = :id AND tenant_id = :tid LIMIT 1');
            $st->execute([':id' => $id, ':tid' => $tid]);
            $afterEmployee = $st->fetch(PDO::FETCH_ASSOC) ?: null;

            // after user (если есть)
            $st = $pdo->prepare('SELECT id, username, email, role FROM users WHERE tenant_id = :tid AND employee_id = :eid LIMIT 1');
            $st->execute([':tid' => $tid, ':eid' => $id]);
            $afterUser = $st->fetch(PDO::FETCH_ASSOC) ?: null;

            $changes = [];

            // helper to push diff
            $pushDiff = function(string $field, $b, $a) use (&$changes): void {
                // normalize null/'' for comparison
                $bn = ($b === '' ? null : $b);
                $an = ($a === '' ? null : $a);
                if ($bn === $an) return;
                $changes[] = ['field' => $field, 'before' => $bn, 'after' => $an];
            };

            if ($beforeEmployee === null) {
                // create: логируем все ключевые поля
                $changes[] = ['field' => 'employee.id', 'before' => null, 'after' => (int)($afterEmployee['id'] ?? 0)];
                $pushDiff('employee.full_name', null, (string)($afterEmployee['full_name'] ?? ''));
                $pushDiff('employee.group_code', null, (string)($afterEmployee['group_code'] ?? ''));
                $pushDiff('employee.role', null, (string)($afterEmployee['role'] ?? ''));
                $pushDiff('employee.tab_no', null, (string)($afterEmployee['tab_no'] ?? ''));
                $pushDiff('employee.birth_date', null, (string)($afterEmployee['birth_date'] ?? ''));
                $pushDiff('employee.email', null, (string)($afterEmployee['email'] ?? ''));
                $pushDiff('employee.is_active', null, norm_bool($afterEmployee['is_active'] ?? true));
            } else {
                $pushDiff('employee.full_name', (string)($beforeEmployee['full_name'] ?? ''), (string)($afterEmployee['full_name'] ?? ''));
                $pushDiff('employee.group_code', (string)($beforeEmployee['group_code'] ?? ''), (string)($afterEmployee['group_code'] ?? ''));
                $pushDiff('employee.role', (string)($beforeEmployee['role'] ?? ''), (string)($afterEmployee['role'] ?? ''));
                $pushDiff('employee.tab_no', (string)($beforeEmployee['tab_no'] ?? ''), (string)($afterEmployee['tab_no'] ?? ''));
                $pushDiff('employee.birth_date', (string)($beforeEmployee['birth_date'] ?? ''), (string)($afterEmployee['birth_date'] ?? ''));
                $pushDiff('employee.email', (string)($beforeEmployee['email'] ?? ''), (string)($afterEmployee['email'] ?? ''));
                $pushDiff('employee.is_active', norm_bool($beforeEmployee['is_active'] ?? true), norm_bool($afterEmployee['is_active'] ?? true));
            }

            // users diff (если что-то было/стало)
            if ($beforeUser === null && $afterUser !== null) {
                $pushDiff('user.username', null, (string)($afterUser['username'] ?? ''));
                $pushDiff('user.email', null, (string)($afterUser['email'] ?? ''));
                $pushDiff('user.role', null, (string)($afterUser['role'] ?? ''));
                if ($passwordChanged) {
                    $changes[] = ['field' => 'user.password', 'before' => null, 'after' => 'changed'];
                }
            } elseif ($beforeUser !== null && $afterUser === null) {
                // теоретически (удаления тут нет)
                $changes[] = ['field' => 'user', 'before' => 'exists', 'after' => null];
            } elseif ($beforeUser !== null && $afterUser !== null) {
                $pushDiff('user.username', (string)($beforeUser['username'] ?? ''), (string)($afterUser['username'] ?? ''));
                $pushDiff('user.email', (string)($beforeUser['email'] ?? ''), (string)($afterUser['email'] ?? ''));
                // роль могла не поменяться (owner не трогаем)
                $pushDiff('user.role', (string)($beforeUser['role'] ?? ''), (string)($afterUser['role'] ?? ''));
                if ($passwordChanged) {
                    $changes[] = ['field' => 'user.password', 'before' => null, 'after' => 'changed'];
                }
            } else {
                // нет аккаунта — ничего
            }

            $meta = [
                'employee_id' => (int)$id,
                'full_name'   => (string)($afterEmployee['full_name'] ?? $full_name),
                'group_code'  => (string)($afterEmployee['group_code'] ?? $group_code),
            ];

            // удобные подсказки для директора
            if ($beforeEmployee !== null) {
                $fromG = trim((string)($beforeEmployee['group_code'] ?? ''));
                $toG   = trim((string)($afterEmployee['group_code'] ?? ''));
                if ($fromG !== $toG) {
                    $meta['from_group'] = ($fromG !== '' ? $fromG : 'unassigned');
                    $meta['to_group'] = ($toG !== '' ? $toG : 'unassigned');
                    $meta['schedule_moved'] = $scheduleMoved;
                }
            }

            audit_insert($pdo, $ctx, $tid, $actionForAudit, 'employee', (string)$id, $meta, $changes);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        header('Location: /?r=admin_employee_edit&id=' . $id . '&ok=1');
        exit;

    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$ok = !empty($_GET['ok']) ? 'Сохранено' : '';
$isActiveNow = !empty($employee['is_active']);

?>
<div class="app-container" style="max-width:1100px;">
  <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
    <h2 style="margin:0;">Редактирование сотрудника</h2>
    <a class="btn" href="/?r=admin_employees">← К списку</a>
  </div>

  <?php if ($ok): ?>
    <div class="card" style="margin-top:12px;color:#166534;background:#ecfdf5;border:1px solid #bbf7d0;">
      <?= h($ok) ?>
    </div>
  <?php endif; ?>

  <?php if ($err): ?>
    <div class="card" style="margin-top:12px;color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;">
      <?= h($err) ?>
    </div>
  <?php endif; ?>

  <form method="post" class="card" style="margin-top:12px;" autocomplete="off">
    <!-- анти-автозаполнение Chrome -->
    <input type="text" name="__fake_user" value="" autocomplete="username" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;opacity:0;">
    <input type="password" name="__fake_pass" value="" autocomplete="current-password" style="position:absolute;left:-10000px;top:auto;width:1px;height:1px;opacity:0;">

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <div>
        <div class="muted" style="margin-bottom:6px;">Имя</div>
        <input type="text" name="full_name" autocomplete="off" value="<?= h((string)($employee['full_name'] ?? '')) ?>" required>
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Группа</div>
        <select name="group_code" required autocomplete="off">
          <option value="unassigned" <?= ((string)($employee['group_code'] ?? '') === 'unassigned' || (string)($employee['group_code'] ?? '') === '' ) ? 'selected' : '' ?>>Без группы</option>
          <?php foreach ($groups as $g): ?>
            <option value="<?= h((string)$g['code']) ?>" <?= ((string)($employee['group_code'] ?? '') === (string)$g['code']) ? 'selected' : '' ?>>
              <?= h((string)$g['title']) ?><?= !empty($g['active']) ? '' : ' (неактивна)' ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="muted" style="font-size:12px;margin-top:6px;">Можно менять — это и есть “перемещение между группами”.</div>
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Роль сотрудника</div>
        <select name="emp_role" required autocomplete="off">
          <option value="tenant_admin" <?= ((string)($employee['role'] ?? 'viewer') === 'tenant_admin') ? 'selected' : '' ?>>Директор ОП</option>
          <option value="admin" <?= ((string)($employee['role'] ?? 'viewer') === 'admin') ? 'selected' : '' ?>>Руководитель Торгового сектора</option>
          <option value="viewer" <?= ((string)($employee['role'] ?? 'viewer') === 'viewer') ? 'selected' : '' ?>>Продавец</option>
        </select>
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Табельный №</div>
        <input type="text" name="tab_no" autocomplete="off" value="<?= h((string)($employee['tab_no'] ?? '')) ?>">
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Дата рождения</div>
        <input type="date" name="birth_date" autocomplete="off" value="<?= h((string)($employee['birth_date'] ?? '')) ?>">
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Email (в employees)</div>
        <input type="email" name="emp_email" autocomplete="off" value="<?= h((string)($employee['email'] ?? '')) ?>">
      </div>
      
      <div>
      Оклад: <input name="salary_base">
      </div>
      
      
    </div>

    <div style="margin-top:10px;">
      <label class="muted" style="display:flex;gap:8px;align-items:center;">
        <input type="checkbox" name="is_active" value="1" <?= $isActiveNow ? 'checked' : '' ?>>
        Сотрудник активен (если снять — не показывать в списках/расписании)
      </label>
    </div>

    <hr style="margin:14px 0;border:none;border-top:1px solid #eef2f7">

    <div style="font-weight:700;margin-bottom:8px;">Аккаунт для входа (users)</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
      <div>
        <div class="muted" style="margin-bottom:6px;">Логин</div>
        <input type="text" name="login" autocomplete="off" value="<?= h((string)($userRow['username'] ?? '')) ?>" placeholder="например: ivanov">
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Email пользователя</div>
        <input type="email" name="user_email" autocomplete="off" value="<?= h((string)($userRow['email'] ?? '')) ?>">
      </div>

      <div>
        <div class="muted" style="margin-bottom:6px;">Новый пароль (если нужно поменять)</div>
        <input type="password" name="new_password" autocomplete="new-password" value="" placeholder="оставь пустым — не меняем">
      </div>
    </div>

    <div style="margin-top:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
      <button class="btn" type="submit">💾 Сохранить</button>
    </div>
  </form>
</div>

</body></html>
