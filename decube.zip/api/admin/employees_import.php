<?php
// admin/employees_import.php — импорт сотрудников (Excel .xlsx или .csv)
// + AUDIT: employee_import (одна запись) со сводкой и списком изменений (ограничение размера)

declare(strict_types=1);

$ctx = require __DIR__ . '/../guard.php';

$pdo  = $ctx['pdo'];
$role = strtolower(trim((string)($ctx['role'] ?? '')));
$tid  = (int)($ctx['tid'] ?? 0);

if (!in_array($role, ['owner', 'tenant_admin'], true)) {
    http_response_code(403);
    echo 'no_permission';
    exit;
}

require __DIR__ . '/_header.php';
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

function get_actor_user_id(array $ctx): int {
    $u = $ctx['user'] ?? null;
    if (is_array($u) && isset($u['id'])) return (int)$u['id'];
    if (isset($ctx['uid'])) return (int)$ctx['uid'];
    return 0;
}

function audit_insert(PDO $pdo, array $ctx, int $tid, string $action, string $entityType, ?string $entityId, array $meta, array $changes): void {
    if (empty($changes)) return;

    $actorId = get_actor_user_id($ctx);
    $actorRole = strtolower(trim((string)($ctx['role'] ?? '')));
    if ($actorId <= 0) return;

    $st = $pdo->prepare('
        INSERT INTO public.audit_log (tenant_id, actor_user_id, actor_role, action, entity_type, entity_id, meta, changes)
        VALUES (:tid, :uid, :arole, :action, :etype, :eid, :meta::jsonb, :changes::jsonb)
    ');
    $st->execute([
        ':tid'     => $tid,
        ':uid'     => $actorId,
        ':arole'   => $actorRole,
        ':action'  => $action,
        ':etype'   => $entityType,
        ':eid'     => $entityId,
        ':meta'    => json_encode($meta, JSON_UNESCAPED_UNICODE),
        ':changes' => json_encode($changes, JSON_UNESCAPED_UNICODE),
    ]);
}

$err = '';
$ok = '';

function xlsx_read_first_sheet_rows(string $path): array {
    if (!class_exists('ZipArchive')) throw new RuntimeException('ZipArchive не доступен на сервере (нужен для XLSX)');

    $zip = new ZipArchive();
    if ($zip->open($path) !== true) throw new RuntimeException('Не удалось открыть XLSX');

    $shared = [];
    $idx = $zip->locateName('xl/sharedStrings.xml');
    if ($idx !== false) {
        $xml = $zip->getFromIndex($idx);
        if (is_string($xml)) {
            $sx = @simplexml_load_string($xml);
            if ($sx) {
                foreach ($sx->si as $si) {
                    if (isset($si->t)) {
                        $shared[] = (string)$si->t;
                    } else {
                        $t = '';
                        foreach ($si->r as $r) $t .= (string)($r->t ?? '');
                        $shared[] = $t;
                    }
                }
            }
        }
    }

    $sheetXml = $zip->getFromName('xl/worksheets/sheet1.xml');
    if (!is_string($sheetXml) || $sheetXml === '') throw new RuntimeException('В XLSX нет xl/worksheets/sheet1.xml');

    $sx = @simplexml_load_string($sheetXml);
    if (!$sx) throw new RuntimeException('Не удалось прочитать sheet1.xml');

    $rows = [];
    foreach ($sx->sheetData->row as $row) {
        $cells = [];
        foreach ($row->c as $c) {
            $r = (string)($c['r'] ?? ''); // A1, B1...
            $t = (string)($c['t'] ?? '');
            $v = (string)($c->v ?? '');

            $col = preg_replace('~\d+~', '', $r);
            if ($col === '') continue;

            $val = $v;
            if ($t === 's') {
                $si = (int)$v;
                $val = $shared[$si] ?? '';
            }
            $cells[$col] = (string)$val;
        }

        if ($cells) {
            ksort($cells);
            $rows[] = array_values($cells);
        }
    }

    $zip->close();
    return $rows;
}

function csv_read_rows(string $path): array {
    $rows = [];
    $fh = fopen($path, 'rb');
    if (!$fh) throw new RuntimeException('Не удалось открыть CSV');

    $line = fgets($fh);
    if ($line === false) return [];
    $delim = (substr_count($line, ';') >= substr_count($line, ',')) ? ';' : ',';
    rewind($fh);

    while (($r = fgetcsv($fh, 0, $delim)) !== false) {
        $rows[] = array_map(static fn($x) => is_string($x) ? trim($x) : '', $r);
    }
    fclose($fh);
    return $rows;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (empty($_FILES['file']['tmp_name'])) throw new RuntimeException('Файл не загружен');

        $tmp = (string)$_FILES['file']['tmp_name'];
        $name = (string)($_FILES['file']['name'] ?? '');
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

        if (!in_array($ext, ['xlsx', 'csv'], true)) {
            throw new RuntimeException('Нужен файл .xlsx (Excel) или .csv');
        }

        $rows = ($ext === 'xlsx') ? xlsx_read_first_sheet_rows($tmp) : csv_read_rows($tmp);
        if (!$rows) throw new RuntimeException('Файл пустой');

        $hdr = array_map(static fn($x) => strtolower(trim((string)$x)), $rows[0]);
        $col = [];
        foreach ($hdr as $i => $h) {
            $h = preg_replace('~\s+~', '_', $h);
            $col[$h] = $i;
        }

        $pick = function(array $row, array $keys) use ($col): string {
            foreach ($keys as $k) {
                if (isset($col[$k])) {
                    $i = $col[$k];
                    return isset($row[$i]) ? trim((string)$row[$i]) : '';
                }
            }
            return '';
        };

        $inserted = 0;
        $updated  = 0;
        $usersTouched = 0;

        // audit changes (один лог на весь импорт)
        $auditChanges = [];
        $auditLimit = 200;
        $auditTruncated = false;

        $pdo->beginTransaction();
        try {
            for ($ri = 1; $ri < count($rows); $ri++) {
                $r = $rows[$ri];
                if (!is_array($r) || count($r) === 0) continue;

                $full_name  = $pick($r, ['full_name', 'name', 'fio']);
                $group_code = $pick($r, ['group_code', 'group', 'groupcode']);
                $tab_no     = $pick($r, ['tab_no', 'tabnum', 'tab']);
                $emp_email  = $pick($r, ['email', 'emp_email']);
                $birth_date = $pick($r, ['birth_date', 'birthday', 'birth']);
                $emp_role   = $pick($r, ['role', 'emp_role']);

                $login      = $pick($r, ['login', 'username']);
                $user_email = $pick($r, ['user_email', 'login_email']);
                $password   = $pick($r, ['password', 'pass']);

                if ($full_name === '') continue;
                if ($group_code === '') $group_code = 'unassigned';
                if ($emp_role === '') $emp_role = 'viewer';

                // find existing
                $st = $pdo->prepare('
                    SELECT id, group_code, full_name, role, tab_no, birth_date, email
                    FROM employees
                    WHERE tenant_id = :tid AND full_name = :n AND COALESCE(tab_no, \'\') = :tab
                    LIMIT 1
                ');
                $st->execute([':tid'=>$tid, ':n'=>$full_name, ':tab'=>$tab_no]);
                $before = $st->fetch(PDO::FETCH_ASSOC) ?: null;
                $eid = $before ? (int)($before['id'] ?? 0) : 0;

                $fieldsChanged = [];

                if ($eid > 0) {
                    // update employee
                    $st = $pdo->prepare('
                        UPDATE employees
                        SET group_code=:g, role=:r, email=:em, birth_date=:bd, tab_no=:tab
                        WHERE id=:id AND tenant_id=:tid
                    ');
                    $st->execute([
                        ':g'=>$group_code,
                        ':r'=>$emp_role,
                        ':em'=>($emp_email !== '' ? $emp_email : null),
                        ':bd'=>($birth_date !== '' ? $birth_date : null),
                        ':tab'=>($tab_no !== '' ? $tab_no : null),
                        ':id'=>$eid,
                        ':tid'=>$tid,
                    ]);
                    $updated++;

                    // compute simple diffs vs $before
                    $cmp = function(string $f, $b, $a) use (&$fieldsChanged): void {
                        $bn = ($b === '' ? null : $b);
                        $an = ($a === '' ? null : $a);
                        if ($bn === $an) return;
                        $fieldsChanged[] = ['field'=>$f,'before'=>$bn,'after'=>$an];
                    };
                    $cmp('employee.group_code', (string)($before['group_code'] ?? ''), $group_code);
                    $cmp('employee.role', (string)($before['role'] ?? ''), $emp_role);
                    $cmp('employee.email', (string)($before['email'] ?? ''), ($emp_email !== '' ? $emp_email : null));
                    $cmp('employee.birth_date', (string)($before['birth_date'] ?? ''), ($birth_date !== '' ? $birth_date : null));
                    $cmp('employee.tab_no', (string)($before['tab_no'] ?? ''), ($tab_no !== '' ? $tab_no : null));

                } else {
                    // insert employee
                    $st = $pdo->prepare('
                        INSERT INTO employees(tenant_id, group_code, full_name, role, tab_no, birth_date, email)
                        VALUES(:tid, :g, :n, :r, :tab, :bd, :em)
                        RETURNING id
                    ');
                    $st->execute([
                        ':tid'=>$tid, ':g'=>$group_code, ':n'=>$full_name, ':r'=>$emp_role,
                        ':tab'=>($tab_no !== '' ? $tab_no : null),
                        ':bd'=>($birth_date !== '' ? $birth_date : null),
                        ':em'=>($emp_email !== '' ? $emp_email : null),
                    ]);
                    $eid = (int)($st->fetchColumn() ?: 0);
                    $inserted++;

                    $fieldsChanged[] = ['field'=>'employee.full_name','before'=>null,'after'=>$full_name];
                    $fieldsChanged[] = ['field'=>'employee.group_code','before'=>null,'after'=>$group_code];
                    $fieldsChanged[] = ['field'=>'employee.role','before'=>null,'after'=>$emp_role];
                    if ($tab_no !== '') $fieldsChanged[] = ['field'=>'employee.tab_no','before'=>null,'after'=>$tab_no];
                    if ($birth_date !== '') $fieldsChanged[] = ['field'=>'employee.birth_date','before'=>null,'after'=>$birth_date];
                    if ($emp_email !== '') $fieldsChanged[] = ['field'=>'employee.email','before'=>null,'after'=>$emp_email];
                }

                // optional user account
                $userTouchedThisRow = false;
                if ($eid > 0 && $login !== '') {
                    $st = $pdo->prepare('SELECT id, username, email, role FROM users WHERE tenant_id=:tid AND employee_id=:eid LIMIT 1');
                    $st->execute([':tid'=>$tid, ':eid'=>$eid]);
                    $ub = $st->fetch(PDO::FETCH_ASSOC) ?: null;
                    $uid = $ub ? (int)($ub['id'] ?? 0) : 0;

                    if ($uid <= 0) {
                        $ph = password_hash($password !== '' ? $password : bin2hex(random_bytes(6)), PASSWORD_DEFAULT);
                        $st = $pdo->prepare('
                            INSERT INTO users(tenant_id, username, password_hash, role, employee_id, email)
                            VALUES(:tid, :u, :ph, :role, :eid, :em)
                        ');
                        $st->execute([
                            ':tid'=>$tid, ':u'=>$login, ':ph'=>$ph, ':role'=>'viewer', ':eid'=>$eid,
                            ':em'=>($user_email !== '' ? $user_email : null),
                        ]);
                        $userTouchedThisRow = true;
                        $fieldsChanged[] = ['field'=>'user.username','before'=>null,'after'=>$login];
                        $fieldsChanged[] = ['field'=>'user.email','before'=>null,'after'=>($user_email !== '' ? $user_email : null)];
                        $fieldsChanged[] = ['field'=>'user.role','before'=>null,'after'=>'viewer'];
                        $fieldsChanged[] = ['field'=>'user.password','before'=>null,'after'=>'changed'];
                    } else {
                        if ($password !== '') {
                            $st = $pdo->prepare('UPDATE users SET username=:u, email=:em, password_hash=:ph WHERE id=:id AND tenant_id=:tid');
                            $st->execute([
                                ':u'=>$login, ':em'=>($user_email !== '' ? $user_email : null),
                                ':ph'=>password_hash($password, PASSWORD_DEFAULT),
                                ':id'=>$uid, ':tid'=>$tid
                            ]);
                            $fieldsChanged[] = ['field'=>'user.password','before'=>null,'after'=>'changed'];
                        } else {
                            $st = $pdo->prepare('UPDATE users SET username=:u, email=:em WHERE id=:id AND tenant_id=:tid');
                            $st->execute([
                                ':u'=>$login, ':em'=>($user_email !== '' ? $user_email : null),
                                ':id'=>$uid, ':tid'=>$tid
                            ]);
                        }

                        // diff user fields (username/email only; role not touched here)
                        $userTouchedThisRow = true;
                        $bU = (string)($ub['username'] ?? '');
                        $bE = (string)($ub['email'] ?? '');
                        if ($bU !== $login) $fieldsChanged[] = ['field'=>'user.username','before'=>($bU !== '' ? $bU : null),'after'=>$login];
                        $newUE = ($user_email !== '' ? $user_email : null);
                        $oldUE = ($bE !== '' ? $bE : null);
                        if ($oldUE !== $newUE) $fieldsChanged[] = ['field'=>'user.email','before'=>$oldUE,'after'=>$newUE];
                    }

                    $usersTouched++;
                }

                // add per-row change record into import log (если есть что писать)
                if (!empty($fieldsChanged)) {
                    if (count($auditChanges) < $auditLimit) {
                        $auditChanges[] = [
                            'employee_id' => (int)$eid,
                            'full_name'   => $full_name,
                            'type'        => ($before ? 'updated' : 'created'),
                            'changes'     => $fieldsChanged,
                        ];
                    } else {
                        $auditTruncated = true;
                    }
                }
            }

            // one audit log for import
            $meta = [
                'file' => $name,
                'inserted' => $inserted,
                'updated' => $updated,
                'users_touched' => $usersTouched,
                'items_logged' => count($auditChanges),
                'truncated' => $auditTruncated,
            ];

            audit_insert($pdo, $ctx, $tid, 'employee_import', 'employee', null, $meta, $auditChanges);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        $ok = "Готово. Добавлено: {$inserted}, обновлено: {$updated}, аккаунтов затронуто: {$usersTouched}";
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}
?>
<div class="app-container" style="max-width:900px;">
  <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
    <h2 style="margin:0;">Импорт сотрудников</h2>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a href="/?r=admin_employees" class="btn">← Назад</a>
    </div>
  </div>

  <?php if ($err !== ''): ?>
    <div class="card" style="margin-top:12px;border-color:#fecaca;background:#fff1f2;color:#991b1b;"><?= h($err) ?></div>
  <?php endif; ?>
  <?php if ($ok !== ''): ?>
    <div class="card" style="margin-top:12px;border-color:#bbf7d0;background:#f0fdf4;color:#166534;"><?= h($ok) ?></div>
  <?php endif; ?>

  <div class="card" style="margin-top:12px;">
    <div class="muted" style="margin-bottom:10px;">
      Поддержка: <b>.xlsx</b> (Excel) и <b>.csv</b>. Заголовки колонок: full_name/name, group_code/group, tab_no/tabnum, email, birth_date, role, login, user_email, password.
    </div>

    <form method="post" enctype="multipart/form-data" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:0;">
      <input type="file" name="file" accept=".xlsx,.csv" required>
      <button class="btn" type="submit">⬆️ Импортировать</button>
    </form>
  </div>
</div>

</body></html>
