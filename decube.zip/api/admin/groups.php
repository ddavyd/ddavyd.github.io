<?php
// admin/groups.php — группы (PG): форма спрятана под "Новая группа", PRG redirect, toggle/save для bool/int
// + AUDIT LOG: create/update/toggle/move_employees

declare(strict_types=1);

$ctx = require __DIR__ . '/../guard.php';

$pdo  = $ctx['pdo'];
$role = strtolower(trim((string)($ctx['role'] ?? '')));
$tid  = (int)($ctx['tid'] ?? 0);
$user = $ctx['user'] ?? [];

if (!in_array($role, ['owner', 'tenant_admin', 'admin'], true)) {
    http_response_code(403);
    echo 'no_permission';
    exit;
}

// ===== AUDIT helper =====
function audit_add(PDO $pdo, int $tenantId, int $actorUserId, string $actorRole, string $action, string $entityType, ?string $entityId, array $meta = [], array $changes = []): void {
    if ($tenantId <= 0 || $actorUserId <= 0) return; // если нет юзера — не пишем
    try {
        $st = $pdo->prepare('
            INSERT INTO public.audit_log
              (tenant_id, actor_user_id, actor_role, action, entity_type, entity_id, meta, changes)
            VALUES
              (:tid, :uid, :role, :act, :etype, :eid, :meta::jsonb, :changes::jsonb)
        ');
        $st->execute([
            ':tid'     => $tenantId,
            ':uid'     => $actorUserId,
            ':role'    => $actorRole,
            ':act'     => $action,
            ':etype'   => $entityType,
            ':eid'     => $entityId,
            ':meta'    => json_encode($meta, JSON_UNESCAPED_UNICODE),
            ':changes' => json_encode($changes, JSON_UNESCAPED_UNICODE),
        ]);
    } catch (Throwable $ignore) {
        // журнал не должен ломать бизнес-операции
    }
}

function is_truthy($v): bool {
    if (is_bool($v)) return $v;
    if ($v === null) return false;
    $s = strtolower(trim((string)$v));
    if ($s === 'true' || $s === 't' || $s === '1' || $s === 'yes' || $s === 'y') return true;
    if ($s === 'false' || $s === 'f' || $s === '0' || $s === 'no' || $s === 'n' || $s === '') return false;
    return (bool)$v;
}

// тип is_active (boolean/integer)
$isActiveType = '';
try {
    $st = $pdo->prepare("
        SELECT data_type
        FROM information_schema.columns
        WHERE table_schema='public'
          AND table_name='groups'
          AND column_name='is_active'
        LIMIT 1
    ");
    $st->execute();
    $isActiveType = strtolower((string)($st->fetchColumn() ?: ''));
} catch (Throwable $ignore) {}

$actorUserId = (int)($user['id'] ?? 0);
$actorRole   = $role;

// POST обработка ДО вывода HTML
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $action = (string)($_POST['action'] ?? '');

        if ($action === 'save') {
            $id    = (int)($_POST['id'] ?? 0);
            $code  = trim((string)($_POST['code'] ?? ''));
            $title = trim((string)($_POST['title'] ?? ''));
            $activeBool = !empty($_POST['is_active']);

            if ($code === '') throw new RuntimeException('Укажи code');
            if ($title === '') throw new RuntimeException('Укажи title');

            $activeVal = ($isActiveType === 'boolean') ? $activeBool : ($activeBool ? 1 : 0);

            // before
            $before = null;
            if ($id > 0) {
                $st = $pdo->prepare('SELECT id, code, title, is_active FROM "groups" WHERE id = :id AND tenant_id = :tid LIMIT 1');
                $st->execute([':id'=>$id, ':tid'=>$tid]);
                $before = $st->fetch(PDO::FETCH_ASSOC) ?: null;
                if (!$before) throw new RuntimeException('Группа не найдена');
            }

            if ($id > 0) {
                $st = $pdo->prepare('
                    UPDATE "groups"
                    SET code = :c, title = :t, is_active = :a
                    WHERE id = :id AND tenant_id = :tid
                ');
                $st->execute([':c'=>$code, ':t'=>$title, ':a'=>$activeVal, ':id'=>$id, ':tid'=>$tid]);

                // after
                $st = $pdo->prepare('SELECT id, code, title, is_active FROM "groups" WHERE id = :id AND tenant_id = :tid LIMIT 1');
                $st->execute([':id'=>$id, ':tid'=>$tid]);
                $after = $st->fetch(PDO::FETCH_ASSOC) ?: null;

                $changes = [];
                if ($before && $after) {
                    $bActive = is_truthy($before['is_active'] ?? null);
                    $aActive = is_truthy($after['is_active'] ?? null);

                    if ((string)($before['code'] ?? '') !== (string)($after['code'] ?? '')) {
                        $changes[] = ['field'=>'group.code','before'=>$before['code'] ?? null,'after'=>$after['code'] ?? null];
                    }
                    if ((string)($before['title'] ?? '') !== (string)($after['title'] ?? '')) {
                        $changes[] = ['field'=>'group.title','before'=>$before['title'] ?? null,'after'=>$after['title'] ?? null];
                    }
                    if ($bActive !== $aActive) {
                        $changes[] = ['field'=>'group.is_active','before'=>$bActive,'after'=>$aActive];
                    }
                }

                audit_add(
                    $pdo,
                    $tid,
                    $actorUserId,
                    $actorRole,
                    'group_update',
                    'group',
                    (string)$id,
                    [
                        'group_id' => $id,
                        'code'     => $code,
                        'title'    => $title,
                    ],
                    $changes
                );

            } else {
                $st = $pdo->prepare('
                    INSERT INTO "groups"(tenant_id, code, title, is_active)
                    VALUES(:tid, :c, :t, :a)
                    RETURNING id
                ');
                $st->execute([':tid'=>$tid, ':c'=>$code, ':t'=>$title, ':a'=>$activeVal]);
                $newId = (int)($st->fetchColumn() ?: 0);

                audit_add(
                    $pdo,
                    $tid,
                    $actorUserId,
                    $actorRole,
                    'group_create',
                    'group',
                    $newId > 0 ? (string)$newId : null,
                    [
                        'group_id' => $newId,
                        'code'     => $code,
                        'title'    => $title,
                    ],
                    [
                        ['field'=>'group.code','before'=>null,'after'=>$code],
                        ['field'=>'group.title','before'=>null,'after'=>$title],
                        ['field'=>'group.is_active','before'=>null,'after'=>(bool)$activeBool],
                    ]
                );
            }

            header('Location: /?r=admin_groups&ok=1');
            exit;
        }

        if ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('bad id');

            $st = $pdo->prepare('SELECT id, code, title, is_active FROM "groups" WHERE id = :id AND tenant_id = :tid LIMIT 1');
            $st->execute([':id'=>$id, ':tid'=>$tid]);
            $before = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            if (!$before) throw new RuntimeException('Группа не найдена');

            if ($isActiveType === 'boolean') {
                $st = $pdo->prepare('
                    UPDATE "groups"
                    SET is_active = NOT is_active
                    WHERE id = :id AND tenant_id = :tid
                ');
                $st->execute([':id'=>$id, ':tid'=>$tid]);
            } else {
                $st = $pdo->prepare('
                    UPDATE "groups"
                    SET is_active = CASE WHEN COALESCE(is_active,0) = 1 THEN 0 ELSE 1 END
                    WHERE id = :id AND tenant_id = :tid
                ');
                $st->execute([':id'=>$id, ':tid'=>$tid]);
            }

            $st = $pdo->prepare('SELECT id, code, title, is_active FROM "groups" WHERE id = :id AND tenant_id = :tid LIMIT 1');
            $st->execute([':id'=>$id, ':tid'=>$tid]);
            $after = $st->fetch(PDO::FETCH_ASSOC) ?: null;

            $bActive = is_truthy($before['is_active'] ?? null);
            $aActive = $after ? is_truthy($after['is_active'] ?? null) : !$bActive;

            audit_add(
                $pdo,
                $tid,
                $actorUserId,
                $actorRole,
                'group_toggle_active',
                'group',
                (string)$id,
                [
                    'group_id' => $id,
                    'code'     => (string)($after['code'] ?? $before['code'] ?? ''),
                    'title'    => (string)($after['title'] ?? $before['title'] ?? ''),
                ],
                [
                    ['field'=>'group.is_active','before'=>$bActive,'after'=>$aActive],
                ]
            );

            header('Location: /?r=admin_groups&ok=1');
            exit;
        }

        if ($action === 'move_employees') {
            $group_id = (int)($_POST['group_id'] ?? 0);
            $target   = trim((string)($_POST['target_group_code'] ?? ''));
            $ids      = $_POST['emp_ids'] ?? [];

            if ($group_id <= 0) throw new RuntimeException('bad group_id');
            if ($target === '') throw new RuntimeException('Укажи целевую группу');

            // текущая группа
            $st = $pdo->prepare('SELECT code, title FROM "groups" WHERE id = :id AND tenant_id = :tid LIMIT 1');
            $st->execute([':id'=>$group_id, ':tid'=>$tid]);
            $gr = $st->fetch(PDO::FETCH_ASSOC) ?: null;
            $fromCode = $gr ? (string)($gr['code'] ?? '') : '';
            $fromTitle = $gr ? (string)($gr['title'] ?? '') : '';
            if ($fromCode === '') throw new RuntimeException('Группа не найдена');

            // title target (для журнала)
            $toTitle = '';
            try {
                if ($target !== 'unassigned') {
                    $st = $pdo->prepare('SELECT title FROM "groups" WHERE tenant_id = :tid AND code = :c LIMIT 1');
                    $st->execute([':tid'=>$tid, ':c'=>$target]);
                    $toTitle = (string)($st->fetchColumn() ?: '');
                }
            } catch (Throwable $ignore) {}

            if (!is_array($ids) || !$ids) {
                header('Location: /?r=admin_groups&edit=' . $group_id . '&err=' . rawurlencode('Не выбраны сотрудники'));
                exit;
            }

            // нормализуем id'шники
            $empIds = [];
            foreach ($ids as $v) {
                $n = (int)$v;
                if ($n > 0) $empIds[] = $n;
            }
            $empIds = array_values(array_unique($empIds));
            if (!$empIds) {
                header('Location: /?r=admin_groups&edit=' . $group_id . '&err=' . rawurlencode('Не выбраны сотрудники'));
                exit;
            }

            // имена сотрудников (для журнала)
            $empNames = [];
            try {
                $place = implode(',', array_fill(0, count($empIds), '?'));
                $sqlN = "SELECT id, full_name FROM employees WHERE tenant_id = ? AND id IN ($place) ORDER BY full_name";
                $st = $pdo->prepare($sqlN);
                $st->execute(array_merge([$tid], $empIds));
                while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
                    $empNames[] = [
                        'id' => (int)($r['id'] ?? 0),
                        'full_name' => (string)($r['full_name'] ?? ''),
                    ];
                }
            } catch (Throwable $ignore) {}

            // update + перенос расписания (schedule_days)
            $placeholders = implode(',', array_fill(0, count($empIds), '?'));

            $pdo->beginTransaction();
            try {
                // 1) перенос сотрудника в employees
                $sqlEmp = "UPDATE employees SET group_code = ? WHERE tenant_id = ? AND group_code = ? AND id IN ($placeholders)";
                $paramsEmp = array_merge([$target, $tid, $fromCode], $empIds);
                $pdo->prepare($sqlEmp)->execute($paramsEmp);

                // 2) защита от конфликтов уникальности в schedule_days
                $sqlDel = "DELETE FROM schedule_days t
                           USING schedule_days s
                           WHERE t.tenant_id = ?
                             AND t.group_code = ?
                             AND s.tenant_id = ?
                             AND s.group_code = ?
                             AND t.date = s.date
                             AND t.employee_id = s.employee_id
                             AND t.employee_id IN ($placeholders)";
                $paramsDel = array_merge([$tid, $target, $tid, $fromCode], $empIds);
                $pdo->prepare($sqlDel)->execute($paramsDel);

                // 3) перенос строк расписания
                $sqlSched = "UPDATE schedule_days
                             SET group_code = ?
                             WHERE tenant_id = ?
                               AND group_code = ?
                               AND employee_id IN ($placeholders)";
                $paramsSched = array_merge([$target, $tid, $fromCode], $empIds);
                $pdo->prepare($sqlSched)->execute($paramsSched);

                // audit (внутри транзакции — ок)
                audit_add(
                    $pdo,
                    $tid,
                    $actorUserId,
                    $actorRole,
                    'group_move_employees',
                    'group',
                    (string)$group_id,
                    [
                        'from_group_code' => $fromCode,
                        'from_group_title'=> $fromTitle,
                        'to_group_code'   => $target,
                        'to_group_title'  => $target === 'unassigned' ? 'Без группы' : $toTitle,
                        'moved_count'     => count($empIds),
                        'employees'       => $empNames, // список id+имя
                    ],
                    [] // changes не нужны, meta достаточно
                );

                $pdo->commit();
            } catch (Throwable $e) {
                $pdo->rollBack();
                throw $e;
            }

            header('Location: /?r=admin_groups&edit=' . $group_id . '&ok=1');
            exit;
        }

        header('Location: /?r=admin_groups&err=' . rawurlencode('unknown_action'));
        exit;

    } catch (Throwable $e) {
        header('Location: /?r=admin_groups&err=' . rawurlencode($e->getMessage()));
        exit;
    }
}

require __DIR__ . '/_header.php';
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

$err = (string)($_GET['err'] ?? '');
$ok  = !empty($_GET['ok']) ? 'Обновлено' : '';

// редактирование / создание
$edit = null;
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0) {
    try {
        $st = $pdo->prepare('SELECT id, code, title, is_active FROM "groups" WHERE id = :id AND tenant_id = :tid LIMIT 1');
        $st->execute([':id'=>$editId, ':tid'=>$tid]);
        $edit = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Throwable $e) {
        $err = $e->getMessage();
    }
}

$isNew = !empty($_GET['new']);
$showForm = ($editId > 0) || $isNew;

// список групп
$activeExpr = ($isActiveType === 'boolean')
    ? '(is_active = TRUE)'
    : '(COALESCE(is_active,0)::int <> 0)';

$rows = [];
try {
    $st = $pdo->prepare("
        SELECT id, code, title, {$activeExpr} AS active
        FROM \"groups\"
        WHERE tenant_id = :tid
        ORDER BY title
    ");
    $st->execute([':tid'=>$tid]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    $err = $e->getMessage();
}

?>
<div class="app-container" style="max-width:1000px;">
  <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center">
    <h2 style="margin:0;">Группы</h2>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a href="/?r=admin" class="btn">← Назад</a>
      <a href="/?r=admin_groups&new=1" class="btn">➕ Новая группа</a>
    </div>
  </div>

  <?php if ($ok): ?>
    <div class="card" style="margin-top:12px;color:#166534;background:#ecfdf5;border:1px solid #bbf7d0;">
      <?= h($ok) ?>
    </div>
  <?php endif; ?>

  <?php if ($err): ?>
    <div class="card" style="margin-top:12px;color:#b91c1c;background:#fef2f2;border:1px solid #fecaca;">
      <?= h($err) ?>
    </div>
  <?php endif; ?>

  <?php if ($showForm): ?>
    <div class="card" style="margin-top:12px;">
      <div style="font-weight:700;margin-bottom:8px;display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <?= $editId > 0 ? 'Редактирование группы' : 'Новая группа' ?>
        <?php if ($editId > 0): ?>
          <span class="muted">(#<?= (int)$editId ?>)</span>
        <?php endif; ?>
      </div>

      <form method="post" style="display:grid;grid-template-columns:1fr 1fr auto;gap:10px;align-items:end;margin:0;">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">

        <div>
          <div class="muted" style="margin-bottom:6px;">Code</div>
          <input type="text" name="code" value="<?= h((string)($edit['code'] ?? '')) ?>" required>
        </div>

        <div>
          <div class="muted" style="margin-bottom:6px;">Название</div>
          <input type="text" name="title" value="<?= h((string)($edit['title'] ?? '')) ?>" required>
        </div>

        <div style="display:flex;gap:10px;align-items:center;justify-content:flex-end;">
          <label class="muted" style="display:flex;gap:6px;align-items:center;margin:0;">
            <input type="checkbox" name="is_active" value="1" <?= !empty($edit) ? (!empty($edit['is_active']) ? 'checked' : '') : 'checked' ?>>
            Активна
          </label>
          <button class="btn" type="submit">💾 Сохранить</button>
        </div>
      </form>
    </div>
  <?php endif; ?>

  <?php if ($editId > 0 && $edit): ?>
    <?php
      // сотрудники в группе
      $empRows = [];
      try {
          $st = $pdo->prepare('
              SELECT id, full_name, tab_no, role, email, group_code
              FROM employees
              WHERE tenant_id = :tid AND group_code = :gc
              ORDER BY full_name
          ');
          $st->execute([':tid'=>$tid, ':gc'=>(string)$edit['code']]);
          $empRows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      } catch (Throwable $e) {
          $err = $err !== '' ? $err : $e->getMessage();
      }
    ?>
    <div class="card" style="margin-top:12px;">
      <div style="font-weight:700;margin-bottom:8px;">Сотрудники в группе “<?= h((string)$edit['title']) ?>”</div>

      <form method="post" style="margin:0;">
        <input type="hidden" name="action" value="move_employees">
        <input type="hidden" name="group_id" value="<?= (int)$edit['id'] ?>">

        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:end;">
          <label class="muted" style="display:flex;flex-direction:column;gap:4px;min-width:260px;">
            Переместить выбранных в:
            <select name="target_group_code" required>
              <option value="unassigned">Без группы</option>
              <?php foreach ($rows as $gr): ?>
                <?php if ((string)$gr['code'] === (string)$edit['code']) continue; ?>
                <option value="<?= h((string)$gr['code']) ?>"><?= h((string)$gr['title']) ?></option>
              <?php endforeach; ?>
            </select>
          </label>

          <button class="btn" type="submit">Подтвердить перенос</button>

          <span class="muted" style="margin-left:auto">
            В группе: <b><?= (int)count($empRows) ?></b>
          </span>
        </div>

        <?php if (!$empRows): ?>
          <div class="muted" style="margin-top:10px;">В этой группе пока нет сотрудников.</div>
        <?php else: ?>
          <div style="overflow:auto;margin-top:10px;">
            <table class="table" style="min-width:780px;">
              <thead>
                <tr>
                  <th style="width:34px;"><input type="checkbox" id="chkAll" checked></th>
                  <th>Сотрудник</th>
                  <th>Таб№</th>
                  <th>Роль</th>
                  <th>Email</th>
                  <th style="text-align:right;">Действия</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($empRows as $e): ?>
                  <tr>
                    <td><input type="checkbox" class="chkEmp" name="emp_ids[]" value="<?= (int)$e['id'] ?>" checked></td>
                    <td><?= h((string)$e['full_name']) ?></td>
                    <td><?= h((string)($e['tab_no'] ?? '')) ?></td>
                    <td><?= h((string)($e['role'] ?? '')) ?></td>
                    <td><?= h((string)($e['email'] ?? '')) ?></td>
                    <td style="text-align:right;white-space:nowrap;">
                      <a class="btn" href="/?r=admin_employee_edit&id=<?= (int)$e['id'] ?>">Открыть</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>

          <script>
            (function(){
              const all = document.getElementById('chkAll');
              const boxes = () => Array.from(document.querySelectorAll('.chkEmp'));
              if (all) {
                all.addEventListener('change', () => {
                  boxes().forEach(b => b.checked = all.checked);
                });
              }
            })();
          </script>
        <?php endif; ?>
      </form>
    </div>
  <?php endif; ?>

  <div class="card" style="margin-top:12px;">
    <table>
      <thead>
        <tr>
          <th style="width:70px;">ID</th>
          <th style="width:160px;">Code</th>
          <th>Название</th>
          <th style="width:120px;">Активна</th>
          <th style="width:220px;text-align:right;">Действия</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($rows as $g): ?>
          <tr>
            <td><?= (int)$g['id'] ?></td>
            <td><?= h((string)$g['code']) ?></td>
            <td><?= h((string)$g['title']) ?></td>
            <td><?= !empty($g['active']) ? '✅' : '⛔' ?></td>
            <td style="text-align:right;white-space:nowrap;">
              <a class="btn" href="/?r=admin_groups&edit=<?= (int)$g['id'] ?>">✏️</a>
              <form method="post" style="display:inline;margin:0;">
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?= (int)$g['id'] ?>">
                <button class="btn" type="submit"><?= !empty($g['active']) ? 'Сделать неактивной' : 'Сделать активной' ?></button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

</body></html>
