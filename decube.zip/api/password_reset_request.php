<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$sec = __DIR__ . '/security.php';
if (is_file($sec)) {
    require_once $sec;
    if (function_exists('require_same_origin')) {
        require_same_origin();
    }
}

// rate-limit (hotfix)
require_once __DIR__ . '/rate_limit.php';

require_once __DIR__ . '/db.php';

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function norm(string $s): string {
    $s = trim($s);
    $s = preg_replace('~\s+~u', ' ', $s) ?? $s;
    return trim($s);
}

function b64url(string $bin): string {
    return rtrim(strtr(base64_encode($bin), '+/', '-_'), '=');
}

function send_fallback_mail(string $to, string $subject, string $html, string $text, string $fromEmail, string $fromName='Planning646'): void {
    $subjEnc = '=?UTF-8?B?' . base64_encode($subject) . '?=';
    $fromHeader = '=?UTF-8?B?' . base64_encode($fromName) . '?= <' . $fromEmail . '>';
    $boundary = 'b' . bin2hex(random_bytes(12));

    $headers = [];
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'From: ' . $fromHeader;
    $headers[] = 'Reply-To: <' . $fromEmail . '>';
    $headers[] = 'Content-Type: multipart/alternative; boundary="' . $boundary . '"';

    $msg  = "--$boundary\r\n";
    $msg .= "Content-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$text}\r\n\r\n";
    $msg .= "--$boundary\r\n";
    $msg .= "Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n\r\n{$html}\r\n\r\n";
    $msg .= "--$boundary--\r\n";

    @mail($to, $subjEnc, $msg, implode("\r\n", $headers), '-f ' . $fromEmail);
}

function ensure_password_resets_table(PDO $pdo): void {
    // не трогаем если уже есть
    $st = $pdo->query("SELECT to_regclass('public.password_resets') AS t");
    $row = $st ? $st->fetch(PDO::FETCH_ASSOC) : null;
    if (!empty($row['t'])) return;

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS password_resets (
            id BIGSERIAL PRIMARY KEY,
            user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            token_hash CHAR(64) NOT NULL,
            expires_at TIMESTAMP WITHOUT TIME ZONE NOT NULL,
            used_at TIMESTAMP WITHOUT TIME ZONE NULL,
            created_at TIMESTAMP WITHOUT TIME ZONE NOT NULL DEFAULT NOW(),
            ip TEXT NULL,
            ua TEXT NULL
        )
    ");
    $pdo->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_password_resets_token_hash ON password_resets(token_hash)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_password_resets_user_id ON password_resets(user_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_password_resets_expires_at ON password_resets(expires_at)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_password_resets_used_at ON password_resets(used_at)");
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        json_out(['error' => 'method_not_allowed'], 405);
    }

    $pdo = get_db();

    $input = $_POST;
    if (!$input) {
        $raw = file_get_contents('php://input');
        $decoded = json_decode((string)$raw, true);
        $input = is_array($decoded) ? $decoded : [];
    }

    $username = norm((string)($input['username'] ?? ''));
    $email    = norm((string)($input['email'] ?? ''));

    $okAnswer = ['ok' => true, 'message' => 'Если данные верные — письмо отправлено.'];

    if ($username === '') json_out($okAnswer);
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) json_out($okAnswer);

    // rate-limit: 3 запроса в час на IP и на username
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $uKey = strtolower($username);
    $s1 = rl_check('reset:ip:' . $ip, 3, 3600);
    $s2 = rl_check('reset:user:' . $uKey, 3, 3600);
    if (!$s1['ok'] || !$s2['ok']) {
        // не раскрываем лимиты/наличие пользователя — отвечаем как обычно
        json_out($okAnswer);
    }

    ensure_password_resets_table($pdo);

    // чистка (NOW() приводим к timestamp без TZ)
    try {
        $pdo->exec("DELETE FROM password_resets WHERE used_at IS NOT NULL OR expires_at <= (NOW()::timestamp)");
    } catch (Throwable $e) {}

    // ищем пользователя
    if ($email !== '') {
        $st = $pdo->prepare("SELECT id, username, email FROM users WHERE username = :u AND email = :e LIMIT 1");
        $st->execute([':u' => $username, ':e' => $email]);
    } else {
        $st = $pdo->prepare("SELECT id, username, email FROM users WHERE username = :u LIMIT 1");
        $st->execute([':u' => $username]);
    }
    $user = $st->fetch(PDO::FETCH_ASSOC);
    if (!$user || empty($user['email'])) json_out($okAnswer);

    $uid = (int)$user['id'];
    $toEmail = (string)$user['email'];

    $token = b64url(random_bytes(32));
    $tokenHash = hash('sha256', $token);

    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    $ua = (string)($_SERVER['HTTP_USER_AGENT'] ?? '');

    // 60 минут — кладём как timestamp string, но поле в БД timestamp
    $expires = (new DateTimeImmutable('now'))->modify('+60 minutes')->format('Y-m-d H:i:s');

    // удалить активные токены пользователя
    try {
        $del = $pdo->prepare("DELETE FROM password_resets WHERE user_id = :uid AND used_at IS NULL");
        $del->execute([':uid' => $uid]);
    } catch (Throwable $e) {}

    $ins = $pdo->prepare("
        INSERT INTO password_resets (user_id, token_hash, expires_at, used_at, created_at, ip, ua)
        VALUES (:uid, :th, :exp::timestamp, NULL, NOW()::timestamp, :ip, :ua)
    ");
    $ins->execute([
        ':uid' => $uid,
        ':th'  => $tokenHash,
        ':exp' => $expires,
        ':ip'  => $ip !== '' ? $ip : null,
        ':ua'  => $ua !== '' ? $ua : null,
    ]);

    // APP_URL из конфига (защита от Host Header Injection)
    $cfg = [];
    $cfgFile = __DIR__ . '/config.php';
    if (is_file($cfgFile)) {
        $tmp = require $cfgFile;
        if (is_array($tmp)) $cfg = $tmp;
    }
    $appUrl = rtrim((string)($cfg['APP_URL'] ?? ''), '/');
    if ($appUrl === '') {
        // fallback (лучше всегда задать APP_URL)
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host   = (string)($_SERVER['HTTP_HOST'] ?? '');
        $appUrl = ($host !== '') ? ($scheme . '://' . $host) : '';
    }

    $resetLink = rtrim($appUrl, '/') . '/reset_password.html?token=' . rawurlencode($token);

    $subject = 'Сброс пароля';
    $safeUser = htmlspecialchars($username, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $safeLink = htmlspecialchars($resetLink, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

    $html = '<p>Запрошен сброс пароля для логина: <b>' . $safeUser . '</b></p>'
          . '<p>Чтобы задать новый пароль, открой ссылку (действует 60 минут):</p>'
          . '<p><a href="' . $safeLink . '">' . $safeLink . '</a></p>'
          . '<p>Если это был не ты — просто проигнорируй письмо.</p>';

    $text = "Запрошен сброс пароля для логина: {$username}\n\n"
          . "Чтобы задать новый пароль, открой ссылку (действует 60 минут):\n{$resetLink}\n\n"
          . "Если это был не ты — просто проигнорируй письмо.\n";

    $fromEmail = 'no-reply@planning646.ru';
    $fromName  = 'Planning646';

    $sent = false;
    try {
        @require_once __DIR__ . '/smtp_send.php';
        if (function_exists('smtp_send_mail')) {
            $cfg = [];
            $cfgFile = __DIR__ . '/smtp_config.php';
            if (is_file($cfgFile)) {
                $tmp = require $cfgFile;
                if (is_array($tmp)) $cfg = $tmp;
            }
            $cfg['from_email'] = $fromEmail;
            $cfg['from_name']  = $fromName;
            $cfg['reply_to']   = $fromEmail;

            smtp_send_mail($cfg, $toEmail, $subject, $html, $text);
            $sent = true;
        }
    } catch (Throwable $e) {
        $sent = false;
    }

    if (!$sent) {
        send_fallback_mail($toEmail, $subject, $html, $text, $fromEmail, $fromName);
    }

    json_out($okAnswer);

} catch (Throwable $e) {
    error_log('[password_reset_request] ' . $e->getMessage());
    json_out(['ok' => true, 'message' => 'Если данные верные — письмо отправлено.']);
}
