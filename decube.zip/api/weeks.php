<?php
// api/weeks.php
declare(strict_types=1);

require_once __DIR__ . '/security.php';
require_same_origin();

require_once __DIR__ . '/utils.php'; // для json_response()

$year = isset($_GET['year']) ? (int)$_GET['year'] : (int)date('Y');
if ($year < 2000 || $year > 2100) $year = (int)date('Y');

/**
 * ISO-недели для ISO-года $year:
 * - week 1 = неделя, содержащая 4 января
 * - неделя начинается в понедельник
 */
$weeks = [];
$dt = new DateTimeImmutable(sprintf('%04d-01-04', $year));      // 4 января всегда в ISO-week 1 нужного ISO-года
$monday = $dt->modify('monday this week');                     // понедельник недели 1

for ($i = 0; $i < 60; $i++) {                                  // 60 с запасом
    $isoYear = (int)$monday->format('o');                      // ISO week-year
    $isoWeek = (int)$monday->format('W');                      // ISO week number

    if ($isoYear > $year) break;
    if ($isoYear === $year) {
        $start = $monday;
        $end   = $monday->modify('+6 days');

        $weeks[] = [
            'index' => $isoWeek,
            'start' => $start->format('Y-m-d'),
            'end'   => $end->format('Y-m-d'),
            'label' => sprintf(
                'Неделя %d (%s–%s)',
                $isoWeek,
                $start->format('d.m'),
                $end->format('d.m')
            ),
        ];
    }

    $monday = $monday->modify('+1 week');
}

json_response(['year' => $year, 'weeks' => $weeks]);
