<?php
// api/db.php — PostgreSQL, multi-tenant (устойчивый к legacy is_active INTEGER)

declare(strict_types=1);

/**
 * PG secrets must live OUTSIDE webroot:
 * /var/www/ddavyd/.planning_pg.php
 *
 * return [
 *   'host' => '127.0.0.1',
 *   'port' => 5432,
 *   'db'   => 'planning',
 *   'user' => 'planning_user',
 *   'pass' => '...',
 * ];
 */

const PG_SECRETS_FILE = '/var/www/ddavyd/.planning_pg.inc';

function pg_config(): array
{
    static $cfg = null;
    if (is_array($cfg)) return $cfg;

    if (!is_file(PG_SECRETS_FILE)) {
        // важно: db.php подключается много где, поэтому ответ максимально понятный
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'missing_pg_secrets', 'file' => PG_SECRETS_FILE], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $data = require PG_SECRETS_FILE;
    if (!is_array($data)) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'bad_pg_secrets_format'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $cfg = [
        'host' => (string)($data['host'] ?? '127.0.0.1'),
        'port' => (int)($data['port'] ?? 5432),
        'db'   => (string)($data['db'] ?? 'planning'),
        'user' => (string)($data['user'] ?? ''),
        'pass' => (string)($data['pass'] ?? ''),
    ];

    if ($cfg['user'] === '' || $cfg['db'] === '') {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'incomplete_pg_secrets'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    return $cfg;
}

function get_db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $cfg = pg_config();

    $dsn = sprintf(
        "pgsql:host=%s;port=%d;dbname=%s;options='--client_encoding=UTF8'",
        $cfg['host'],
        $cfg['port'],
        $cfg['db']
    );

    $pdo = new PDO($dsn, $cfg['user'], $cfg['pass'], [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);

    // migrate_schema_pg($pdo); // НЕ вызываем на каждый запрос. Запускаем миграции вручную при деплое.

    return $pdo;
}

// совместимость со старым кодом
function db(): PDO { return get_db(); }

/* =========================
   TENANT CONTEXT
========================= */

function tenant_id(PDO $pdo): int {
    return (int)current_tenant($pdo)['id'];
}

function current_tenant(PDO $pdo): array {
    static $cache = null;
    if (is_array($cache)) return $cache;

    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }

    $ownerTid = (int)($_SESSION['owner_tid'] ?? 0);
    if ($ownerTid > 0) {
        $st = $pdo->prepare('SELECT * FROM tenants WHERE id = :id LIMIT 1');
        $st->execute([':id' => $ownerTid]);
        $t = $st->fetch();
        if ($t) return $cache = $t;
    }

    $tid = (int)($_SESSION['tenant_id'] ?? 0);
    if ($tid > 0) {
        $st = $pdo->prepare('SELECT * FROM tenants WHERE id = :id LIMIT 1');
        $st->execute([':id' => $tid]);
        $t = $st->fetch();
        if ($t) return $cache = $t;
    }

    return $cache = get_or_create_default_tenant($pdo);
}

function get_or_create_default_tenant(PDO $pdo): array {
    $st = $pdo->query("SELECT * FROM tenants WHERE code='default' LIMIT 1");
    $t = $st ? $st->fetch() : null;
    if ($t) return $t;

    // вставляем мягко: значение is_active подберём по факту типа колонки
    $lit = tenants_is_active_literal($pdo);

    $pdo->exec("
        INSERT INTO tenants(code,name,is_active)
        VALUES('default','Основное подразделение',{$lit})
        ON CONFLICT (code) DO NOTHING
    ");

    $st2 = $pdo->query("SELECT * FROM tenants WHERE code='default' LIMIT 1");
    $t2 = $st2 ? $st2->fetch() : null;

    return $t2 ?: [
        'id' => 1,
        'code' => 'default',
        'name' => 'Основное подразделение',
        'is_active' => true,
    ];
}

function tenants_is_active_literal(PDO $pdo): string {
    // TRUE если колонка boolean, иначе 1 (для integer)
    try {
        $st = $pdo->query("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='tenants' AND column_name='is_active'
            LIMIT 1
        ");
        $type = strtolower((string)($st ? $st->fetchColumn() : ''));
        return ($type === 'boolean') ? 'TRUE' : '1';
    } catch (Throwable $e) {
        return '1';
    }
}

/* =========================
   AUTH HELPERS (legacy)
========================= */

function db_get_current_user(PDO $pdo): ?array {
    if (session_status() !== PHP_SESSION_ACTIVE) {
        @session_start();
    }

    if (empty($_SESSION['user_id']) || empty($_SESSION['tenant_id'])) {
        return null;
    }

    $st = $pdo->prepare("
        SELECT
            u.*,
            e.full_name  AS employee_name,
            e.group_code AS employee_group
        FROM users u
        LEFT JOIN employees e ON e.id = u.employee_id
        WHERE u.id = :uid AND u.tenant_id = :tid
        LIMIT 1
    ");
    $st->execute([
        ':uid' => (int)$_SESSION['user_id'],
        ':tid' => (int)$_SESSION['tenant_id'],
    ]);

    return $st->fetch() ?: null;
}

function require_login(PDO $pdo): array {
    $u = db_get_current_user($pdo);
    if (!$u) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'not_authenticated'], JSON_UNESCAPED_UNICODE);
        exit;
    }
    return $u;
}

/* =========================
   GROUPS
========================= */

function get_groups(PDO $pdo, int $tenantId): array {
    // is_active::int <> 0 работает И для boolean, И для integer
    $st = $pdo->prepare('
        SELECT code, title
        FROM "groups"
        WHERE tenant_id = :tid AND (is_active::int <> 0)
        ORDER BY sort_order, title
    ');
    $st->execute([':tid' => $tenantId]);

    $out = [];
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $out[(string)$r['code']] = (string)$r['title'];
    }

    if (!$out) {
        $out['unassigned'] = 'Без группы';
    }

    return $out;
}

/* =========================
   MIGRATIONS (PG)
========================= */

function migrate_schema_pg(PDO $pdo): void {

    // 1) create tables (если есть — не трогает)
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tenants (
            id SERIAL PRIMARY KEY,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            is_active BOOLEAN NOT NULL DEFAULT TRUE
        )
    ");

    $pdo->exec('
        CREATE TABLE IF NOT EXISTS "groups" (
            id SERIAL PRIMARY KEY,
            tenant_id INTEGER NOT NULL REFERENCES tenants(id),
            code TEXT NOT NULL,
            title TEXT NOT NULL,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            sort_order INTEGER NOT NULL DEFAULT 0
        )
    ');

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS employees (
            id SERIAL PRIMARY KEY,
            tenant_id INTEGER NOT NULL REFERENCES tenants(id),
            group_code TEXT NOT NULL,
            full_name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'viewer',
            tab_no TEXT,
            birth_date DATE,
            email TEXT
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            tenant_id INTEGER NOT NULL REFERENCES tenants(id),
            username TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            employee_id INTEGER REFERENCES employees(id),
            email TEXT
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS schedule_days (
            id SERIAL PRIMARY KEY,
            tenant_id INTEGER NOT NULL REFERENCES tenants(id),
            date DATE NOT NULL,
            group_code TEXT NOT NULL,
            employee_id INTEGER NOT NULL REFERENCES employees(id),
            status TEXT NOT NULL,
            slots TEXT NOT NULL
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS change_log (
            id SERIAL PRIMARY KEY,
            tenant_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            ts TIMESTAMP NOT NULL,
            action TEXT NOT NULL,
            details TEXT NOT NULL
        )
    ");

    // 2) попытка конвертации legacy integer -> boolean (без DO $$)
    // tenants
    try {
        $st = $pdo->query("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='tenants' AND column_name='is_active'
            LIMIT 1
        ");
        $type = strtolower((string)($st ? $st->fetchColumn() : ''));
        if ($type !== 'boolean' && $type !== '') {
            $pdo->exec("ALTER TABLE tenants ALTER COLUMN is_active TYPE boolean USING (is_active::int <> 0)");
        }
    } catch (Throwable $e) {
        // оставим как есть, но insert ниже подстроится
        error_log('[db.php] tenants is_active convert failed: ' . $e->getMessage());
    }

    // groups
    try {
        $st = $pdo->query("
            SELECT data_type
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='groups' AND column_name='is_active'
            LIMIT 1
        ");
        $type = strtolower((string)($st ? $st->fetchColumn() : ''));
        if ($type !== 'boolean' && $type !== '') {
            $pdo->exec("ALTER TABLE \"groups\" ALTER COLUMN is_active TYPE boolean USING (is_active::int <> 0)");
        }
    } catch (Throwable $e) {
        error_log('[db.php] groups is_active convert failed: ' . $e->getMessage());
    }

    // 3) indexes
    $pdo->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_tenant_username ON users(tenant_id, username)");
    $pdo->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_groups_tenant_code ON "groups"(tenant_id, code)');
    $pdo->exec("CREATE UNIQUE INDEX IF NOT EXISTS idx_sched ON schedule_days(tenant_id,date,group_code,employee_id)");

    // 4) default tenant — значение подбираем по факту типа колонки
    $lit = tenants_is_active_literal($pdo);
    $pdo->exec("
        INSERT INTO tenants(code,name,is_active)
        VALUES('default','Основное подразделение',{$lit})
        ON CONFLICT (code) DO NOTHING
    ");
}
