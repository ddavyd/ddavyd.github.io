<?php
// api/audit_get.php — чтение журнала изменений (audit_log)

declare(strict_types=1);

require_once __DIR__ . '/security.php';
require_same_origin();

require_once __DIR__ . '/utils.php';

try {
    $ctx = require __DIR__ . '/guard.php';

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $role = (string)($ctx['role'] ?? '');
    $tid  = (int)($ctx['tid'] ?? 0);

    $roleNorm = strtolower(trim($role));
    $isAllowed = ($roleNorm === 'owner' || $roleNorm === 'tenant_admin');
    if (!$isAllowed) {
        http_response_code(403);
        json_response(['error' => 'forbidden']);
        exit;
    }

    $limit  = (int)($_GET['limit']  ?? 50);
    $offset = (int)($_GET['offset'] ?? 0);

    if ($limit < 1) $limit = 1;
    if ($limit > 200) $limit = 200;
    if ($offset < 0) $offset = 0;

    $action = trim((string)($_GET['action'] ?? ''));
    $type   = trim((string)($_GET['entity_type'] ?? ''));
    $q      = trim((string)($_GET['q'] ?? ''));
    $from   = trim((string)($_GET['from'] ?? ''));
    $to     = trim((string)($_GET['to'] ?? ''));

    $fromTs = null;
    if ($from !== '') {
        $fromTs = date_create($from);
        if (!$fromTs) {
            http_response_code(400);
            json_response(['error' => 'invalid_from']);
            exit;
        }
    }
    $toTs = null;
    if ($to !== '') {
        $toTs = date_create($to);
        if (!$toTs) {
            http_response_code(400);
            json_response(['error' => 'invalid_to']);
            exit;
        }
    }

    $where = [];
    $args  = [];

    $where[] = 'a.tenant_id = ?';
    $args[]  = $tid;

    if ($action !== '') {
        $where[] = 'a.action = ?';
        $args[]  = $action;
    }
    if ($type !== '') {
        $where[] = 'a.entity_type = ?';
        $args[]  = $type;
    }
    if ($fromTs) {
        $where[] = 'a.created_at >= ?';
        $args[]  = $fromTs->format('Y-m-d H:i:sP');
    }
    if ($toTs) {
        $where[] = 'a.created_at <= ?';
        $args[]  = $toTs->format('Y-m-d H:i:sP');
    }

    if ($q !== '') {
        $where[] = "(u.username ILIKE ? OR a.entity_id ILIKE ? OR a.action ILIKE ?)";
        $like = '%' . $q . '%';
        $args[] = $like;
        $args[] = $like;
        $args[] = $like;
    }

    $sql =
        "SELECT
            a.id,
            a.tenant_id,
            a.actor_user_id,
            u.username AS actor_username,
            a.actor_role,
            a.action,
            a.entity_type,
            a.entity_id,
            a.meta,
            a.changes,
            a.created_at
         FROM public.audit_log a
         LEFT JOIN public.users u
           ON u.id = a.actor_user_id
         WHERE " . implode(' AND ', $where) . "
         ORDER BY a.created_at DESC, a.id DESC
         LIMIT ? OFFSET ?";

    $argsWithPage = $args;
    $argsWithPage[] = $limit;
    $argsWithPage[] = $offset;

    $st = $pdo->prepare($sql);
    $st->execute($argsWithPage);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);

    // decode jsonb -> array (чтобы UI не видел экранированные строки)
    $allEmpIds = [];

    foreach ($rows as &$r) {
        if (isset($r['meta']) && is_string($r['meta']) && $r['meta'] !== '') {
            $m = json_decode($r['meta'], true);
            $r['meta'] = is_array($m) ? $m : null;
        } else {
            $r['meta'] = null;
        }

        if (isset($r['changes']) && is_string($r['changes']) && $r['changes'] !== '') {
            $c = json_decode($r['changes'], true);
            $r['changes'] = is_array($c) ? $c : null;
        } else {
            $r['changes'] = null;
        }

        // collect employee ids from schedule changes (for names)
        if ($r['entity_type'] === 'schedule' && is_array($r['changes'])) {
            foreach ($r['changes'] as $ch) {
                if (is_array($ch) && isset($ch['employee_id'])) {
                    $eid = (int)$ch['employee_id'];
                    if ($eid > 0) $allEmpIds[$eid] = true;
                }
            }
        }
    }
    unset($r);

    // batch load employee names
    $empNameById = [];
    if (!empty($allEmpIds)) {
        $ids = array_keys($allEmpIds);
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $sqlEmp = "SELECT id, full_name FROM public.employees WHERE tenant_id = ? AND id IN ($ph)";
        $argsEmp = array_merge([$tid], $ids);

        $ste = $pdo->prepare($sqlEmp);
        $ste->execute($argsEmp);
        while ($er = $ste->fetch(PDO::FETCH_ASSOC)) {
            $eid = (int)($er['id'] ?? 0);
            if ($eid > 0) $empNameById[$eid] = (string)($er['full_name'] ?? '');
        }

        // inject employee_name into each change
        foreach ($rows as &$r) {
            if ($r['entity_type'] === 'schedule' && is_array($r['changes'])) {
                foreach ($r['changes'] as &$ch) {
                    if (is_array($ch) && isset($ch['employee_id'])) {
                        $eid = (int)$ch['employee_id'];
                        if ($eid > 0 && !isset($ch['employee_name'])) {
                            $ch['employee_name'] = $empNameById[$eid] ?? '';
                        }
                    }
                }
                unset($ch);
            }
        }
        unset($r);
    }

    $withTotal = (int)($_GET['with_total'] ?? 0) === 1;
    $total = null;

    if ($withTotal) {
        $sqlCount =
            "SELECT COUNT(*)::bigint AS c
             FROM public.audit_log a
             LEFT JOIN public.users u
               ON u.id = a.actor_user_id AND u.tenant_id = a.tenant_id
             WHERE " . implode(' AND ', $where);

        $stc = $pdo->prepare($sqlCount);
        $stc->execute($args);
        $total = (int)($stc->fetchColumn() ?: 0);
    }

    json_response([
        'ok' => true,
        'items' => $rows,
        'limit' => $limit,
        'offset' => $offset,
        'total' => $total,
    ]);
} catch (Throwable $e) {
    http_response_code(500);
    json_response([
        'error' => 'audit_get_failed',
        'details' => $e->getMessage(),
    ]);
}
