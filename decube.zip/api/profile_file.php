<?php
// api/profile_file.php — загрузка файла профиля (аватар/документ)

declare(strict_types=1);

$ctx = require __DIR__ . '/guard.php';

$pdo  = $ctx['pdo'];
$user = $ctx['user'];
$role = $ctx['role'];
$tid  = $ctx['tid'];

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

$employeeId = (int)($_POST['employee_id'] ?? 0);

// viewer/admin — только свой профиль
if (in_array($role, ['admin', 'viewer'], true)) {
    if ((int)$user['employee_id'] !== $employeeId) {
        http_response_code(403);
        echo json_encode(['error' => 'forbidden'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if ($employeeId <= 0 || empty($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_input'], JSON_UNESCAPED_UNICODE);
    exit;
}

// проверить сотрудника
$st = $pdo->prepare("
    SELECT id FROM employees
    WHERE id = :eid AND tenant_id = :tid
    LIMIT 1
");
$st->execute([
    ':eid' => $employeeId,
    ':tid' => $tid,
]);
if (!$st->fetchColumn()) {
    http_response_code(404);
    echo json_encode(['error' => 'employee_not_found'], JSON_UNESCAPED_UNICODE);
    exit;
}

$uploadDir = __DIR__ . '/../data/profile_files/' . $tid;
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true);
    @chmod($uploadDir, 0777);
}

$file = $_FILES['file'];
if ($file['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['error' => 'upload_failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$allowed = ['jpg', 'jpeg', 'png', 'webp', 'pdf'];
if (!in_array($ext, $allowed, true)) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_file_type'], JSON_UNESCAPED_UNICODE);
    exit;
}

$filename = 'emp_' . $employeeId . '.' . $ext;
$path = $uploadDir . '/' . $filename;

if (!move_uploaded_file($file['tmp_name'], $path)) {
    http_response_code(500);
    echo json_encode(['error' => 'save_failed'], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode([
    'ok'       => true,
    'filename' => $filename,
], JSON_UNESCAPED_UNICODE);
exit;
