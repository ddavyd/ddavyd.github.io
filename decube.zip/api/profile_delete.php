<?php
// api/profile_delete.php — удаление профиля сотрудника

declare(strict_types=1);

$ctx = require __DIR__ . '/guard.php';

$pdo  = $ctx['pdo'];
$user = $ctx['user'];
$role = $ctx['role'];
$tid  = $ctx['tid'];

header('Content-Type: application/json; charset=utf-8');

// удалять могут только owner / tenant_admin
if (!in_array($role, ['owner', 'tenant_admin'], true)) {
    http_response_code(403);
    echo json_encode(['error' => 'forbidden'], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method_not_allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

// input
$input = $_POST;
if (!$input) {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: [];
}

$employeeId = (int)($input['employee_id'] ?? 0);

if ($employeeId <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'invalid_employee'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $pdo->beginTransaction();

    // проверить сотрудника
    $st = $pdo->prepare("
        SELECT id FROM employees
        WHERE id = :eid AND tenant_id = :tid
        LIMIT 1
    ");
    $st->execute([
        ':eid' => $employeeId,
        ':tid' => $tid,
    ]);
    if (!$st->fetchColumn()) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['error' => 'not_found'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // удалить пользователя (если есть)
    $st = $pdo->prepare("
        DELETE FROM users
        WHERE employee_id = :eid AND tenant_id = :tid
    ");
    $st->execute([
        ':eid' => $employeeId,
        ':tid' => $tid,
    ]);

    // удалить расписание
    $st = $pdo->prepare("
        DELETE FROM schedule_days
        WHERE employee_id = :eid AND tenant_id = :tid
    ");
    $st->execute([
        ':eid' => $employeeId,
        ':tid' => $tid,
    ]);

    // удалить сотрудника
    $st = $pdo->prepare("
        DELETE FROM employees
        WHERE id = :eid AND tenant_id = :tid
    ");
    $st->execute([
        ':eid' => $employeeId,
        ':tid' => $tid,
    ]);

    $pdo->commit();

    echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => 'delete_failed'], JSON_UNESCAPED_UNICODE);
    exit;
}
