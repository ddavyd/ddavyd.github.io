<?php
// api/register.php — стабильная версия регистрации сотрудника

declare(strict_types=1);

$ctx = require __DIR__ . '/guard.php';

$pdo  = $ctx['pdo'];
$user = $ctx['user'];
$role = $ctx['role'];
$tid  = $ctx['tid'];

header('Content-Type: application/json; charset=utf-8');

// Регистрировать могут только owner / tenant_admin
if (!in_array($role, ['owner', 'tenant_admin'], true)) {
    http_response_code(403);
    echo json_encode(['error' => 'forbidden'], JSON_UNESCAPED_UNICODE);
    exit;
}

// input
$input = $_POST;
if (!$input) {
    $raw = file_get_contents('php://input');
    $input = json_decode($raw, true) ?: [];
}

$username   = trim((string)($input['username'] ?? ''));
$password   = (string)($input['password'] ?? '');
$full_name  = trim((string)($input['full_name'] ?? ''));
$group_code = trim((string)($input['group_code'] ?? ''));
$user_role  = trim((string)($input['role'] ?? 'viewer'));

if ($username === '' || $password === '' || $full_name === '' || $group_code === '') {
    http_response_code(400);
    echo json_encode(['error' => 'missing_fields'], JSON_UNESCAPED_UNICODE);
    exit;
}

// допустимые роли
$allowedRoles = ['tenant_admin', 'admin', 'viewer'];
if (!in_array($user_role, $allowedRoles, true)) {
    $user_role = 'viewer';
}

try {
    $pdo->beginTransaction();

    // проверить логин
    $st = $pdo->prepare("
        SELECT 1 FROM users
        WHERE tenant_id = :tid AND username = :u
        LIMIT 1
    ");
    $st->execute([
        ':tid' => $tid,
        ':u'   => $username,
    ]);
    if ($st->fetchColumn()) {
        $pdo->rollBack();
        http_response_code(409);
        echo json_encode(['error' => 'username_exists'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // создать сотрудника
    $st = $pdo->prepare("
        INSERT INTO employees (tenant_id, group_code, full_name)
        VALUES (:tid, :group, :name)
    ");
    $st->execute([
        ':tid'   => $tid,
        ':group' => $group_code,
        ':name'  => $full_name,
    ]);
    $employeeId = (int)$pdo->lastInsertId();

    // создать пользователя
    $st = $pdo->prepare("
        INSERT INTO users (tenant_id, username, password_hash, role, employee_id)
        VALUES (:tid, :u, :p, :r, :eid)
    ");
    $st->execute([
        ':tid' => $tid,
        ':u'   => $username,
        ':p'   => password_hash($password, PASSWORD_DEFAULT),
        ':r'   => $user_role,
        ':eid' => $employeeId,
    ]);

    $pdo->commit();

    echo json_encode(['ok' => true], JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['error' => 'register_failed'], JSON_UNESCAPED_UNICODE);
    exit;
}
