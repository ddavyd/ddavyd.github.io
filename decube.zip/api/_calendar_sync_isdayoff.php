<?php
declare(strict_types=1);

// SECURITY: this script must not be accessible over HTTP
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo "not_found\n";
    exit;
}


if (php_sapi_name() !== 'cli') { echo "CLI only\n"; exit(1); }

require_once __DIR__ . '/db.php';

$from = (int)($argv[1] ?? date('Y'));
$to   = (int)($argv[2] ?? $from);

if ($from < 2000 || $from > 2100 || $to < 2000 || $to > 2100 || $to < $from) {
    fwrite(STDERR, "Usage: php _calendar_sync_isdayoff.php <fromYear> [toYear]\n");
    exit(1);
}

$cc  = 'ru';
$pre = 1; // сокращённые дни
$sd  = 0; // 5-дневка

function http_get(string $url): string {
    $ctx = stream_context_create([
        'http' => [
            'timeout' => 20,
            'header'  => "User-Agent: planning646-calendar-sync\r\n",
        ],
    ]);
    $s = @file_get_contents($url, false, $ctx);
    if ($s === false) {
        $err = error_get_last();
        throw new RuntimeException("HTTP failed: " . ($err['message'] ?? 'unknown'));
    }
    return trim($s);
}

$pdo = get_db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$pdo->exec("
    CREATE TABLE IF NOT EXISTS calendar_days (
      date DATE PRIMARY KEY,
      code SMALLINT NOT NULL,
      is_workday BOOLEAN NOT NULL,
      norm_hours NUMERIC(4,1) NOT NULL DEFAULT 0.0,
      updated_at TIMESTAMP NOT NULL DEFAULT now()
    )
");

$up = $pdo->prepare("
    INSERT INTO calendar_days(date, code, is_workday, norm_hours, updated_at)
    VALUES (:d, :code, :work, :h, now())
    ON CONFLICT (date) DO UPDATE
      SET code = EXCLUDED.code,
          is_workday = EXCLUDED.is_workday,
          norm_hours = EXCLUDED.norm_hours,
          updated_at = now()
");

$inserted = 0;

for ($y = $from; $y <= $to; $y++) {
    for ($m = 1; $m <= 12; $m++) {
        $mm = str_pad((string)$m, 2, '0', STR_PAD_LEFT);
        $url = "https://isdayoff.ru/api/getdata?year={$y}&month={$mm}&cc={$cc}&pre={$pre}&sd={$sd}&delimeter=%0A";
        $body = http_get($url);

        if (preg_match('/^\d{3}$/', $body)) {
            throw new RuntimeException("isdayoff returned error code {$body} for {$y}-{$mm}");
        }

        $lines = array_values(array_filter(explode("\n", $body), fn($x) => $x !== ''));

        $dt = new DateTimeImmutable(sprintf('%04d-%02d-01', $y, $m));
        $last = (int)$dt->modify('last day of this month')->format('j');

        if (count($lines) !== $last) {
            if (count($lines) === 1 && strlen($lines[0]) >= $last) {
                $lines = str_split(substr($lines[0], 0, $last));
            }
        }
        if (count($lines) !== $last) {
            throw new RuntimeException("Bad response length for {$y}-{$mm}: got " . count($lines) . ", expected {$last}. Body: {$body}");
        }

        $pdo->beginTransaction();
        try {
            for ($d = 1; $d <= $last; $d++) {
                $date = sprintf('%04d-%02d-%02d', $y, $m, $d);
                $code = (int)trim($lines[$d - 1]);

                $isWork = in_array($code, [0, 2, 4], true);
                $hours = 0.0;
                if ($code === 2) $hours = 7.0;
                else if ($code === 0 || $code === 4) $hours = 8.0;

                $up->execute([
                    ':d' => $date,
                    ':code' => $code,
                    ':work' => $isWork ? 1 : 0,
                    ':h' => $hours,
                ]);
                $inserted++;
            }
            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        echo "OK {$y}-{$mm}\n";
    }
}

echo "DONE. rows upserted: {$inserted}\n";
