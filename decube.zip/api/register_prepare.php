<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$sec = __DIR__ . '/security.php';
if (is_file($sec)) {
    require_once $sec;
    if (function_exists('require_same_origin')) {
        require_same_origin();
    }
}

require_once __DIR__ . '/db.php';

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function norm_str(string $s): string {
    $s = trim($s);
    $s = preg_replace('~\s+~u', ' ', $s) ?? $s;
    return trim($s);
}

function tenants_column(PDO $pdo, string $col): bool {
    static $cache = [];
    $k = $col;
    if (isset($cache[$k])) return (bool)$cache[$k];
    try {
        $st = $pdo->prepare("
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='tenants' AND column_name=:c
            LIMIT 1
        ");
        $st->execute([':c' => $col]);
        $cache[$k] = (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        $cache[$k] = false;
    }
    return (bool)$cache[$k];
}

function tenant_by_join_code(PDO $pdo, string $joinCode): ?array {
    // приоритет как в старом проекте: join_code
    if (tenants_column($pdo, 'join_code')) {
        $st = $pdo->prepare("SELECT id, name, is_active FROM tenants WHERE join_code = :c LIMIT 1");
        $st->execute([':c' => $joinCode]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    // fallback: registration_code
    if (tenants_column($pdo, 'registration_code')) {
        $st = $pdo->prepare("SELECT id, name, is_active FROM tenants WHERE registration_code = :c LIMIT 1");
        $st->execute([':c' => $joinCode]);
        $t = $st->fetch(PDO::FETCH_ASSOC);
        if ($t) return $t;
    }
    // fallback: code
    $st = $pdo->prepare("SELECT id, name, is_active FROM tenants WHERE code = :c LIMIT 1");
    $st->execute([':c' => $joinCode]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

// ==== логика генерации логина (как в старом) ====
function translit_ru(string $s): string {
    $map = [
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'y',
        'к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f',
        'х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
    ];
    $s = mb_strtolower($s, 'UTF-8');
    $out = '';
    $len = mb_strlen($s, 'UTF-8');
    for ($i=0; $i<$len; $i++) {
        $ch = mb_substr($s, $i, 1, 'UTF-8');
        if (isset($map[$ch])) $out .= $map[$ch];
        else if (preg_match('~[a-z0-9]~', $ch)) $out .= $ch;
    }
    return $out;
}

function makeLogin(string $fullName, string $birthDate): string {
    $fullName = trim($fullName);
    $parts = preg_split('~\s+~u', $fullName) ?: [];
    $surname = (string)($parts[0] ?? '');
    $name    = (string)($parts[1] ?? '');

    $surname = translit_ru($surname);
    $name    = translit_ru($name);

    $firstLetterName = ($name !== '') ? substr($name, 0, 1) : 'u';
    $fiveSurname     = ($surname !== '') ? substr($surname, 0, 5) : 'user';

    $day = '00';
    if (preg_match('~^\d{4}-\d{2}-(\d{2})$~', $birthDate, $m)) {
        $day = $m[1];
    }

    $base = $firstLetterName . $fiveSurname . $day;
    $base = strtolower(preg_replace('~[^a-z0-9]+~', '', $base) ?? '');
    if ($base === '') $base = 'user' . $day;

    return $base;
}

function make_unique_username(PDO $pdo, string $base): string {
    // Глобальная уникальность username во всей таблице users
    // Формат суффикса: base, base-1, base-2, ...
    $base = trim($base);
    if ($base === '') $base = 'user';

    $st = $pdo->prepare("SELECT username FROM users WHERE username LIKE :p");
    $st->execute([':p' => $base . '%']);
    $taken = $st->fetchAll(PDO::FETCH_COLUMN) ?: [];

    if (!in_array($base, $taken, true)) {
        return $base;
    }

    $max = 0;
    $prefix = $base . '-';

    foreach ($taken as $u) {
        if (!is_string($u)) continue;
        if (strpos($u, $prefix) === 0) {
            $tail = substr($u, strlen($prefix));
            if ($tail !== '' && ctype_digit($tail)) {
                $n = (int)$tail;
                if ($n > $max) $max = $n;
            }
        }
    }

    return $base . '-' . ($max + 1);
}

try {
    $pdo = get_db();

    // ===== режим 1: как в текущем HTML (GET ?join_code=...) =====
    $method = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if ($method === 'GET') {
        $joinCode = norm_str((string)($_GET['join_code'] ?? ''));
        if ($joinCode === '') {
            json_out(['ok' => false, 'error' => 'missing_parameters'], 400);
        }

        $tenant = tenant_by_join_code($pdo, $joinCode);
        if (!$tenant) {
            json_out(['ok' => false, 'error' => 'tenant_not_found'], 404);
        }
        if (((int)($tenant['is_active'] ?? 1)) === 0) { // legacy int
            json_out(['ok' => false, 'error' => 'tenant_inactive'], 403);
        }
        // PG boolean -> cast:
        if (isset($tenant['is_active']) && !is_numeric($tenant['is_active'])) {
            // is_active может быть 't'/'f' или true/false — не важно, проверим через ::int запросом
            // но чтобы не усложнять, просто разрешим, а реальную проверку делаем в finish по ::int
        }

        json_out([
            'ok' => true,
            'tenant_name' => (string)($tenant['name'] ?? ''),
        ]);
    }

    // ===== режим 2: как в старом SQLite (POST JSON: join_code+tab_no+birth_date) =====
    $raw  = file_get_contents('php://input');
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        json_out(['ok' => false, 'error' => 'invalid_json'], 400);
    }

    $joinCode  = norm_str((string)($data['join_code'] ?? ''));
    $tabNo     = norm_str((string)($data['tab_no'] ?? ''));
    $birthDate = norm_str((string)($data['birth_date'] ?? ''));

    if ($joinCode === '' || $tabNo === '' || $birthDate === '') {
        json_out(['ok' => false, 'error' => 'missing_parameters'], 400);
    }

    if (!preg_match('~^\d{4}-\d{2}-\d{2}$~', $birthDate)) {
        json_out(['ok' => false, 'error' => 'bad_birth_date_format'], 400);
    }

    $tenant = tenant_by_join_code($pdo, $joinCode);
    if (!$tenant) {
        json_out(['ok' => false, 'error' => 'tenant_not_found'], 404);
    }

    // в PG is_active может быть boolean — безопаснее проверять так:
    $tid = (int)$tenant['id'];
    $stA = $pdo->prepare("SELECT (is_active::int) FROM tenants WHERE id=:id LIMIT 1");
    $stA->execute([':id'=>$tid]);
    $act = (int)($stA->fetchColumn() ?? 0);
    if ($act !== 1) {
        json_out(['ok' => false, 'error' => 'tenant_inactive'], 403);
    }

    // сотрудник: tenant_id + tab_no + birth_date (как в старом)
    $st = $pdo->prepare("
        SELECT id, full_name, role, birth_date
        FROM employees
        WHERE tenant_id = :tid AND tab_no = :tab
        LIMIT 1
    ");
    $st->execute([':tid' => $tid, ':tab' => $tabNo]);
    $emp = $st->fetch(PDO::FETCH_ASSOC);
    if (!$emp) {
        json_out(['ok' => false, 'error' => 'not_matched'], 404);
    }

    $dbBirth = (string)($emp['birth_date'] ?? '');
    if ($dbBirth === '' || $dbBirth !== $birthDate) {
        json_out(['ok' => false, 'error' => 'not_matched'], 404);
    }

    $base = makeLogin((string)$emp['full_name'], $birthDate);
    $username = make_unique_username($pdo, $base);

    json_out([
        'ok' => true,
        'tenant' => [
            'id' => $tid,
            'name' => (string)($tenant['name'] ?? ''),
        ],
        'employee' => [
            'id' => (int)$emp['id'],
            'full_name' => (string)$emp['full_name'],
            'role' => (string)($emp['role'] ?? 'viewer'),
        ],
        'suggested_username' => $username
    ]);

} catch (Throwable $e) {
    json_out(['ok' => false, 'error' => 'fatal', 'details' => $e->getMessage()], 500);
}
