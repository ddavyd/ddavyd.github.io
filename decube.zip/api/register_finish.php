<?php
declare(strict_types=1);

ini_set('display_errors', '0');
error_reporting(E_ALL);

header('Content-Type: application/json; charset=utf-8');

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$sec = __DIR__ . '/security.php';
if (is_file($sec)) {
    require_once $sec;
    if (function_exists('require_same_origin')) {
        require_same_origin();
    }
}

require_once __DIR__ . '/db.php';

function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function norm_str(string $s): string {
    $s = trim($s);
    $s = preg_replace('~\s+~u', ' ', $s) ?? $s;
    return trim($s);
}

/**
 * Нормализует дату рождения к YYYY-MM-DD.
 * Принимает: YYYY-MM-DD, DD.MM.YYYY, DD/MM/YYYY, DD-MM-YYYY.
 * Возвращает '' если формат/дата некорректные.
 */
function normalize_birth_date(string $s): string {
    $s = trim($s);
    if ($s === '') return '';

    // YYYY-MM-DD
    if (preg_match('~^(\d{4})-(\d{2})-(\d{2})$~', $s, $m)) {
        $y = (int)$m[1]; $mo = (int)$m[2]; $d = (int)$m[3];
        if (!checkdate($mo, $d, $y)) return '';
        return sprintf('%04d-%02d-%02d', $y, $mo, $d);
    }

    // DD.MM.YYYY or DD/MM/YYYY or DD-MM-YYYY
    if (preg_match('~^(\d{1,2})[.\-\/](\d{1,2})[.\-\/](\d{4})$~', $s, $m)) {
        $d = (int)$m[1]; $mo = (int)$m[2]; $y = (int)$m[3];
        if (!checkdate($mo, $d, $y)) return '';
        return sprintf('%04d-%02d-%02d', $y, $mo, $d);
    }

    return '';
}

function tenants_column(PDO $pdo, string $col): bool {
    static $cache = [];
    $k = $col;
    if (isset($cache[$k])) return (bool)$cache[$k];
    try {
        $st = $pdo->prepare("
            SELECT 1
            FROM information_schema.columns
            WHERE table_schema='public' AND table_name='tenants' AND column_name=:c
            LIMIT 1
        ");
        $st->execute([':c' => $col]);
        $cache[$k] = (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        $cache[$k] = false;
    }
    return (bool)$cache[$k];
}

function tenant_by_join_code(PDO $pdo, string $joinCode): ?array {
    if (tenants_column($pdo, 'join_code')) {
        $st = $pdo->prepare("SELECT id, name, is_active FROM tenants WHERE join_code = :c LIMIT 1");
        $st->execute([':c' => $joinCode]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }
    if (tenants_column($pdo, 'registration_code')) {
        $st = $pdo->prepare("SELECT id, name, is_active FROM tenants WHERE registration_code = :c LIMIT 1");
        $st->execute([':c' => $joinCode]);
        $t = $st->fetch(PDO::FETCH_ASSOC);
        if ($t) return $t;
    }
    $st = $pdo->prepare("SELECT id, name, is_active FROM tenants WHERE code = :c LIMIT 1");
    $st->execute([':c' => $joinCode]);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
}

function translit_ru(string $s): string {
    $map = [
        'а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'e','ж'=>'zh','з'=>'z','и'=>'i','й'=>'y',
        'к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f',
        'х'=>'h','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sch','ъ'=>'','ы'=>'y','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',
    ];
    $s = mb_strtolower($s, 'UTF-8');
    $out = '';
    $len = mb_strlen($s, 'UTF-8');
    for ($i=0; $i<$len; $i++) {
        $ch = mb_substr($s, $i, 1, 'UTF-8');
        if (isset($map[$ch])) $out .= $map[$ch];
        else if (preg_match('~[a-z0-9]~', $ch)) $out .= $ch;
    }
    return $out;
}

function makeLogin(string $fullName, string $birthDate): string {
    $fullName = trim($fullName);
    $parts = preg_split('~\s+~u', $fullName) ?: [];
    $surname = (string)($parts[0] ?? '');
    $name    = (string)($parts[1] ?? '');

    $surname = translit_ru($surname);
    $name    = translit_ru($name);

    $firstLetterName = ($name !== '') ? substr($name, 0, 1) : 'u';
    $fiveSurname     = ($surname !== '') ? substr($surname, 0, 5) : 'user';

    $day = '00';
    if (preg_match('~^\d{4}-\d{2}-(\d{2})$~', $birthDate, $m)) {
        $day = $m[1];
    }

    $base = $firstLetterName . $fiveSurname . $day;
    $base = strtolower(preg_replace('~[^a-z0-9]+~', '', $base) ?? '');
    if ($base === '') $base = 'user' . $day;

    return $base;
}

/**
 * Глобально-уникальный username, суффиксы: base, base-1, base-2, ...
 * Устойчиво к регистру (lower).
 */
function make_unique_username(PDO $pdo, string $base): string {
    $base = strtolower(trim($base));
    if ($base === '') $base = 'user';

    $st = $pdo->prepare("SELECT username FROM users WHERE lower(username) LIKE :p");
    $st->execute([':p' => $base . '%']);
    $taken = $st->fetchAll(PDO::FETCH_COLUMN) ?: [];

    $takenLower = [];
    foreach ($taken as $u) {
        if (is_string($u)) $takenLower[] = strtolower($u);
    }

    if (!in_array($base, $takenLower, true)) {
        return $base;
    }

    $max = 0;
    $prefix = $base . '-';

    foreach ($takenLower as $u) {
        if (strpos($u, $prefix) === 0) {
            $tail = substr($u, strlen($prefix));
            if ($tail !== '' && ctype_digit($tail)) {
                $n = (int)$tail;
                if ($n > $max) $max = $n;
            }
        }
    }

    return $base . '-' . ($max + 1);
}

try {
    $pdo = get_db();

    $raw  = file_get_contents('php://input');
    $data = json_decode((string)$raw, true);
    if (!is_array($data)) {
        json_out(['ok' => false, 'error' => 'invalid_json'], 400);
    }

    $joinCode  = norm_str((string)($data['join_code'] ?? ''));
    $tabNo     = norm_str((string)($data['tab_no'] ?? ''));
    $birthRaw  = norm_str((string)($data['birth_date'] ?? ''));
    $birthDate = normalize_birth_date($birthRaw);

    $emailRaw  = norm_str((string)($data['email'] ?? ''));
    $email     = mb_strtolower($emailRaw, 'UTF-8');
    $pass1     = (string)($data['password'] ?? '');
    $pass2     = (string)($data['password2'] ?? '');
    
        // Согласие на обработку ПДн (обязательно)
    $pdConsent = (bool)($data['pd_consent'] ?? false);
    if (!$pdConsent) {
        json_out(['ok' => false, 'error' => 'pd_consent_required'], 400);
    }


    if ($joinCode === '' || $tabNo === '' || $birthRaw === '' || $email === '' || $pass1 === '' || $pass2 === '') {
        json_out(['ok' => false, 'error' => 'missing_parameters'], 400);
    }

    if ($birthDate === '') {
        json_out(['ok' => false, 'error' => 'bad_birth_date_format'], 400);
    }

    if ($pass1 !== $pass2) {
        json_out(['ok' => false, 'error' => 'password_mismatch'], 400);
    }

    if (mb_strlen($pass1, 'UTF-8') < 8) {
        json_out(['ok' => false, 'error' => 'password_too_short'], 400);
    }

    // 1) tenant по join_code
    $tenant = tenant_by_join_code($pdo, $joinCode);
    if (!$tenant) {
        json_out(['ok' => false, 'error' => 'tenant_not_found'], 404);
    }

    $tid = (int)$tenant['id'];

    $stA = $pdo->prepare("SELECT (is_active::int) FROM tenants WHERE id=:id LIMIT 1");
    $stA->execute([':id' => $tid]);
    $act = (int)($stA->fetchColumn() ?? 0);
    if ($act !== 1) {
        json_out(['ok' => false, 'error' => 'tenant_inactive'], 403);
    }

    // 2) сотрудник по tab_no + сверка ДР
    $st = $pdo->prepare("
        SELECT id, full_name, role, birth_date
        FROM employees
        WHERE tenant_id = :tid AND tab_no = :tab
        LIMIT 1
    ");
    $st->execute([':tid' => $tid, ':tab' => $tabNo]);
    $emp = $st->fetch(PDO::FETCH_ASSOC);
    if (!$emp) {
        json_out(['ok' => false, 'error' => 'not_matched'], 404);
    }

    // сравниваем уже с нормализованной YYYY-MM-DD
    $dbBirth = (string)($emp['birth_date'] ?? '');
    if ($dbBirth === '' || $dbBirth !== $birthDate) {
        json_out(['ok' => false, 'error' => 'not_matched'], 404);
    }

    $eid = (int)$emp['id'];
    $role = (string)($emp['role'] ?? 'viewer');

    // 3) уже зарегистрирован?
    $st = $pdo->prepare("SELECT id FROM users WHERE tenant_id = :tid AND employee_id = :eid LIMIT 1");
    $st->execute([':tid' => $tid, ':eid' => $eid]);
    if ($st->fetchColumn()) {
        json_out(['ok' => false, 'error' => 'already_registered'], 409);
    }

    // 4) email уже занят? (в рамках tenant как было)
    $st = $pdo->prepare("SELECT id FROM users WHERE tenant_id = :tid AND lower(email) = :em LIMIT 1");
    $st->execute([':tid' => $tid, ':em' => $email]);
    if ($st->fetchColumn()) {
        json_out(['ok' => false, 'error' => 'email_taken'], 409);
    }

    // 5) генерим username (глобально уникальный)
    $base = makeLogin((string)$emp['full_name'], $birthDate);
    $username = make_unique_username($pdo, $base);

    $hash = password_hash($pass1, PASSWORD_DEFAULT);

    $pdo->beginTransaction();

    $ins = $pdo->prepare("
        INSERT INTO users (tenant_id, username, password_hash, role, employee_id, email)
        VALUES (:tid, :u, :h, :r, :eid, :em)
        RETURNING id
    ");
    $ins->execute([
        ':tid' => $tid,
        ':u'   => $username,
        ':h'   => $hash,
        ':r'   => $role,
        ':eid' => $eid,
        ':em'  => $email,
    ]);

    $newUserId = (int)$ins->fetchColumn();

    // записать email в employees (для админки)
    $up = $pdo->prepare("UPDATE employees SET email = :em WHERE id = :id");
    $up->execute([':em' => $email, ':id' => $eid]);

    $pdo->commit();

    // 6) АВТОЛОГИН
    @session_regenerate_id(true);
    $_SESSION['user_id']   = $newUserId;
    $_SESSION['tenant_id'] = $tid;

    json_out([
        'ok' => true,
        'user' => [
            'id' => $newUserId,
            'username' => $username,
            'role' => $role,
        ],
        'tenant' => [
            'id' => $tid,
            'name' => (string)($tenant['name'] ?? ''),
        ],
        'redirect' => '/?r=schedule'
    ]);

} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    json_out(['ok' => false, 'error' => 'fatal', 'details' => $e->getMessage()], 500);
}
