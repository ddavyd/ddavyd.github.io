<?php
// api/guard.php — быстрый и стабильный контекст (owner switch) + sync session vars

declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    @session_start();
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/utils.php';

// 1) Считываем из сессии всё нужное и сразу отпускаем lock
$uid      = (int)($_SESSION['user_id'] ?? 0);
$baseTid  = (int)($_SESSION['tenant_id'] ?? 0);
$ownerTid = (int)($_SESSION['owner_tid'] ?? 0);
$csrf     = (string)($_SESSION['csrf'] ?? '');

session_write_close();

if ($uid <= 0 || $baseTid <= 0) {
    http_response_code(401);
    exit('401');
}

$pdo = get_db();

// 2) Грузим пользователя только в его базовом tenant
$st = $pdo->prepare("
    SELECT u.*
    FROM users u
    WHERE u.id = :id AND u.tenant_id = :tid
    LIMIT 1
");
$st->execute([':id' => $uid, ':tid' => $baseTid]);

$user = $st->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    http_response_code(401);
    exit('401');
}

$role = strtolower(trim((string)($user['role'] ?? '')));

// 3) Эффективный tenant
$tid = (int)($user['tenant_id'] ?? 0);

if ($role === 'owner' && $ownerTid > 0) {
    $st = $pdo->prepare("SELECT id FROM tenants WHERE id = :id LIMIT 1");
    $st->execute([':id' => $ownerTid]);
    if ((int)$st->fetchColumn() > 0) {
        $tid = $ownerTid;
    } else {
        // битый ownerTid — сбросим коротко
        if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
        $_SESSION['owner_tid'] = 0;
        session_write_close();
    }
}

// 4) employee_group
$employee_group = '';
if (!empty($user['employee_id'])) {
    $st = $pdo->prepare("
        SELECT group_code
        FROM employees
        WHERE id = :eid AND tenant_id = :tid
        LIMIT 1
    ");
    $st->execute([':eid' => (int)$user['employee_id'], ':tid' => $tid]);
    $employee_group = (string)($st->fetchColumn() ?: '');
}
$user['employee_group'] = trim($employee_group);

// 5) scopeGroup
$scopeGroup = '';
if (!in_array($role, ['owner', 'tenant_admin'], true)) {
    $scopeGroup = $user['employee_group'] ?: '';
}

// 6) CSRF (создадим если не было) + IMPORTANT session sync (current_tid/scope_group)
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();

if ($csrf === '') {
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    $csrf = (string)$_SESSION['csrf'];
} else {
    // убедимся что в сессии тоже есть
    $_SESSION['csrf'] = $csrf;
}

// ключевая синхронизация для старого фронта/эндпоинтов
$_SESSION['current_tid'] = (int)$tid;
$_SESSION['scope_group'] = (string)$scopeGroup;

session_write_close();

return [
    'pdo'        => $pdo,
    'user'       => $user,
    'role'       => $role,
    'tid'        => (int)$tid,
    'scopeGroup' => (string)$scopeGroup,
    'csrf'       => $csrf,
];
