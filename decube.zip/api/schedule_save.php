<?php
// api/schedule_save.php — сохранение расписания (PostgreSQL) + audit_log
//
// PERF: batched UPSERT (1 сохранение = несколько SQL-запросов вместо тысяч)

declare(strict_types=1);

require_once __DIR__ . '/security.php';
require_same_origin();
require_csrf();

require_once __DIR__ . '/utils.php';

try {
    $ctx = require __DIR__ . '/guard.php';

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $role = (string)($ctx['role'] ?? '');
    $tid  = (int)($ctx['tid'] ?? 0);
    $user = $ctx['user'] ?? [];

    $roleNorm = strtolower(trim($role));
    // $isOwner  = ($roleNorm === 'owner');
    $isOwner = in_array($roleNorm, ['owner', 'tenant_admin'], true);

    // actor id (кто менял)
    $actorUserId = 0;
    if (is_array($user) && isset($user['id'])) {
        $actorUserId = (int)$user['id'];
    } elseif (isset($ctx['uid'])) {
        $actorUserId = (int)$ctx['uid'];
    }
    if ($actorUserId <= 0) {
        http_response_code(401);
        json_response(['error' => 'unauthorized']);
        exit;
    }

    // JSON body
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);
    if (!is_array($data)) {
        http_response_code(400);
        json_response(['error' => 'invalid_json']);
        exit;
    }

    $group = trim((string)($data['group'] ?? ''));
    $year  = (int)($data['year'] ?? 0);
    $week  = (int)($data['week'] ?? 0);
    $days  = $data['days'] ?? null;

    if ($group === '' || $year <= 0 || $week <= 0 || !is_array($days)) {
        http_response_code(400);
        json_response(['error' => 'missing_parameters']);
        exit;
    }

    // Ограничение по группе: только для admin/viewer
    $scopeGroup = trim((string)($ctx['scopeGroup'] ?? ''));
    if (in_array($roleNorm, ['admin', 'viewer'], true)) {
        if ($scopeGroup !== '' && $group !== $scopeGroup) {
            http_response_code(403);
            json_response(['error' => 'forbidden']);
            exit;
        }
    }

    // ===== ОГРАНИЧЕНИЕ РЕДАКТИРОВАНИЯ ПРОШЛЫХ ДАТ =====
    // Разрешено редактировать: вчера, сегодня и дальше.
    // Всё что раньше вчера — только owner.
    //
    // ВАЖНО: фронт может слать всю неделю, включая прошлые дни.
    // Чтобы это НЕ ломало сохранение, для НЕ-owner просто ИГНОРИРУЕМ дни < вчера.
    $tzName = (string)($ctx['tz'] ?? 'Europe/Amsterdam');
    $tz = new DateTimeZone($tzName);

    $today = (new DateTimeImmutable('now', $tz))->setTime(0, 0, 0);
    $yesterday = $today->modify('-1 day'); // cutoff (вчера)

    $skippedPastDates = [];

    if (!$isOwner) {
        $filtered = [];

        foreach ($days as $day) {
            if (!is_array($day)) continue;

            $date = trim((string)($day['date'] ?? ''));
            if ($date === '') continue;

            $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $date, $tz);
            if (!$dt) {
                // дата кривая — лучше не сохранять вообще
                continue;
            }

            if ($dt < $yesterday) {
                $skippedPastDates[] = $date;
                continue;
            }

            $filtered[] = $day;
        }

        $days = $filtered;
    }
    // ===== /ОГРАНИЧЕНИЕ =====

    // prepare audit insert
    $auditIns = $pdo->prepare('
        INSERT INTO audit_log (tenant_id, actor_user_id, actor_role, action, entity_type, entity_id, meta, changes)
        VALUES (:tid, :uid, :arole, :action, :etype, :eid, :meta::jsonb, :changes::jsonb)
    ');

    // ===== Соберём ключи (date/employee_id) для сравнения "до" =====
    $uniqDates = [];
    $uniqEids  = [];

    foreach ($days as $day) {
        if (!is_array($day)) continue;

        $date = trim((string)($day['date'] ?? ''));
        if ($date === '') continue;

        $employees = $day['employees'] ?? null;
        if (!is_array($employees)) continue;

        $uniqDates[$date] = true;

        foreach ($employees as $e) {
            if (!is_array($e)) continue;
            $eid = (int)($e['employee_id'] ?? 0);
            if ($eid <= 0) continue;
            $uniqEids[$eid] = true;
        }
    }

    $datesList = array_keys($uniqDates);
    $eidsList  = array_keys($uniqEids);

    $beforeMap = []; // "$date:$eid" => ['status'=>..., 'slots'=>...]

    if (!empty($datesList) && !empty($eidsList)) {
        // динамические плейсхолдеры
        $phD = implode(',', array_fill(0, count($datesList), '?'));
        $phE = implode(',', array_fill(0, count($eidsList), '?'));

        $sqlBefore = "
            SELECT date, employee_id, status, slots
            FROM schedule_days
            WHERE tenant_id = ?
              AND group_code = ?
              AND date IN ($phD)
              AND employee_id IN ($phE)
        ";

        $args = [];
        $args[] = $tid;
        $args[] = $group;
        foreach ($datesList as $d) $args[] = $d;
        foreach ($eidsList as $eid) $args[] = (int)$eid;

        $stBefore = $pdo->prepare($sqlBefore);
        $stBefore->execute($args);
        while ($r = $stBefore->fetch(PDO::FETCH_ASSOC)) {
            $d = (string)($r['date'] ?? '');
            $eid = (int)($r['employee_id'] ?? 0);
            if ($d === '' || $eid <= 0) continue;
            $k = $d . ':' . $eid;
            $beforeMap[$k] = [
                'status' => (string)($r['status'] ?? ''),
                'slots'  => (string)($r['slots'] ?? ''),
            ];
        }
    }

    $pdo->beginTransaction();

    $saved = 0;
    $changes = [];
    $rowsToUpsert = [];

    foreach ($days as $day) {
        if (!is_array($day)) continue;

        $date = trim((string)($day['date'] ?? ''));
        if ($date === '') continue;

        $employees = $day['employees'] ?? null;
        if (!is_array($employees)) continue;

        foreach ($employees as $e) {
            if (!is_array($e)) continue;

            $eid = (int)($e['employee_id'] ?? 0);
            if ($eid <= 0) continue;

            $status = (string)($e['status'] ?? '');
            $slots  = (string)($e['slots'] ?? '');

            // нормализуем slots (48 символов)
            if ($slots === '' || strlen($slots) !== 48) {
                $slots = str_pad(substr($slots, 0, 48), 48, '0');
            }

            // сравнение before/after для аудита
            $k = $date . ':' . $eid;
            $before = $beforeMap[$k] ?? null;

            $after = ['status' => $status, 'slots' => $slots];

            $isDifferent = false;
            if ($before === null) {
                $isDifferent = true; // создание
            } else {
                if ((string)($before['status'] ?? '') !== $status) $isDifferent = true;
                if ((string)($before['slots'] ?? '') !== $slots) $isDifferent = true;
            }

            // соберём строки для батч-upsert
            // row: [tenant_id, date, group_code, employee_id, status, slots]
            $rowsToUpsert[] = [$tid, $date, $group, $eid, $status, $slots];
            $saved++;

            if ($isDifferent) {
                $changes[] = [
                    'employee_id' => $eid,
                    'date'        => $date,
                    'before'      => $before, // может быть null
                    'after'       => $after,
                ];
            }
        }
    }

    // ===== BATched UPSERT =====
    if (!empty($rowsToUpsert)) {
    
        // 6 параметров на строку.
        // 800 строк => 4800 параметров — безопасно по лимитам PDO/PG и по размеру SQL.
        $chunkSize = 800;

        for ($i = 0; $i < count($rowsToUpsert); $i += $chunkSize) {
            $chunk = array_slice($rowsToUpsert, $i, $chunkSize);
            
            $vals = [];
            $args = [];

            foreach ($chunk as $row) {
                $vals[] = "(?, ?, ?, ?, ?, ?)";
                foreach ($row as $v) $args[] = $v;
            }

            $sql = "
                INSERT INTO schedule_days (tenant_id, date, group_code, employee_id, status, slots)
                VALUES " . implode(',', $vals) . "
                ON CONFLICT (tenant_id, date, group_code, employee_id)
                DO UPDATE SET status = EXCLUDED.status, slots = EXCLUDED.slots
            ";

            $stUp = $pdo->prepare($sql);
            $stUp->execute($args);
        }
    }
    // ===== /BATched UPSERT =====

    // если есть реальные изменения — пишем audit_log (summary + sample)
    if (!empty($changes)) {
        $changesCount = count($changes);
        $sampleLimit = 120;
        $changesSample = array_slice($changes, 0, $sampleLimit);
        $truncated = ($changesCount > $sampleLimit);

        $meta = [
            'group_code' => $group,
            'year' => $year,
            'week' => $week,
            'saved' => $saved,
            'changes_count' => $changesCount,
            'changes_sample_size' => count($changesSample),
            'changes_truncated' => $truncated,
        ];
        if (!$isOwner && !empty($skippedPastDates)) {
            $meta['skipped_past_dates'] = array_values(array_unique($skippedPastDates));
            $meta['cutoff'] = $yesterday->format('Y-m-d');
        }

        $auditIns->execute([
            ':tid'     => $tid,
            ':uid'     => $actorUserId,
            ':arole'   => $roleNorm,
            ':action'  => 'schedule_save',
            ':etype'   => 'schedule',
            ':eid'     => null,
            ':meta'    => json_encode($meta, JSON_UNESCAPED_UNICODE),
            ':changes' => json_encode($changesSample, JSON_UNESCAPED_UNICODE),
        ]);
    }

    $pdo->commit();

    $resp = ['ok' => true, 'saved' => $saved];

    // опционально: покажем, что прошлое было проигнорировано
    if (!$isOwner && !empty($skippedPastDates)) {
        $resp['skipped_past_dates'] = array_values(array_unique($skippedPastDates));
        $resp['cutoff'] = $yesterday->format('Y-m-d');
    }

    $resp['audit_logged'] = !empty($changes);
    $resp['audit_changes'] = count($changes);

    json_response($resp);
    exit;

} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    json_response(['error' => 'save_failed', 'details' => $e->getMessage()]);
    exit;
}
