<?php
// api/schedule_copy.php — копирование предыдущей недели -> текущую (PG)
// + защита прошлых дат (как в schedule_save): все что раньше вчера — только owner
// + scopeGroup restriction для admin/viewer (как в schedule_save)
// + audit_log (action = schedule_copy) с before/after (создано/удалено/изменено)
// + rollback на исключениях
// + BATCH INSERT (perf): вместо N INSERT по строке — пачки multi-values

declare(strict_types=1);

if (!function_exists('str_contains')) {
    function str_contains(string $haystack, string $needle): bool {
        return $needle === '' || strpos($haystack, $needle) !== false;
    }
}

set_error_handler(function($severity, $message, $file, $line) {
    if (!(error_reporting() & $severity)) return false;
    throw new ErrorException($message, 0, $severity, $file, $line);
});

register_shutdown_function(function() {
    $e = error_get_last();
    if (!$e) return;
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode([
        'error'   => 'fatal',
        'details' => ($e['message'] ?? 'unknown') . ' @ ' . ($e['file'] ?? '') . ':' . ($e['line'] ?? 0),
    ], JSON_UNESCAPED_UNICODE);
});

try {
    require_once __DIR__ . '/security.php';
    if (function_exists('require_same_origin')) {
        require_same_origin();
    }

    // fallback: если в security.php нет require_post()
    if (!function_exists('require_post')) {
        function require_post(): void {
            $m = strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET'));
            if ($m !== 'POST') {
                http_response_code(405);
                header('Content-Type: application/json; charset=utf-8');
                echo json_encode(['error' => 'method_not_allowed'], JSON_UNESCAPED_UNICODE);
                exit;
            }
        }
    }
    require_post();

    // CSRF (обязателен для state-changing)
    if (function_exists('require_csrf')) {
        require_csrf();
    }

    $ctx = require __DIR__ . '/guard.php';

    /** @var PDO $pdo */
    $pdo  = $ctx['pdo'];
    $roleRaw = (string)($ctx['role'] ?? '');
    $role = strtolower(trim($roleRaw));
    $tid  = (int)($ctx['tid'] ?? 0);
    $user = $ctx['user'] ?? [];

    $isOwner = ($role === 'owner');

    // actor id
    $actorUserId = 0;
    if (is_array($user) && isset($user['id'])) {
        $actorUserId = (int)$user['id'];
    } elseif (isset($ctx['uid'])) {
        $actorUserId = (int)$ctx['uid'];
    }
    if ($actorUserId <= 0) {
        http_response_code(401);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    header('Content-Type: application/json; charset=utf-8');

    $ct = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
    $data = [];

    if (strpos($ct, 'application/json') !== false) {
        $raw = file_get_contents('php://input') ?: '';
        $tmp = json_decode($raw, true);
        $data = is_array($tmp) ? $tmp : [];
    } else {
        $data = $_POST;
    }

    $group = trim((string)($data['group'] ?? ''));
    $year  = (int)($data['year'] ?? 0);
    $week  = (int)($data['week'] ?? 0);

    if ($group === '' || $year < 2000 || $year > 2100 || $week < 1 || $week > 53) {
        http_response_code(400);
        echo json_encode(['error' => 'invalid_input'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($role === 'viewer') {
        http_response_code(403);
        echo json_encode(['error' => 'read_only'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Ограничение по группе: только для admin/viewer (как в schedule_save)
    $scopeGroup = trim((string)($ctx['scopeGroup'] ?? ''));
    if (in_array($role, ['admin', 'viewer'], true)) {
        if ($scopeGroup !== '' && $group !== $scopeGroup) {
            http_response_code(403);
            echo json_encode(['error' => 'forbidden'], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    // ===== ОГРАНИЧЕНИЕ РЕДАКТИРОВАНИЯ ПРОШЛЫХ ДАТ (как в schedule_save) =====
    // Не-owner: разрешено менять вчера/сегодня/будущее.
    // Все что раньше вчера — игнорируем (не удаляем и не вставляем).
    $tzName = (string)($ctx['tz'] ?? 'Europe/Amsterdam');
    $tz = new DateTimeZone($tzName);

    $today = (new DateTimeImmutable('now', $tz))->setTime(0, 0, 0);
    $yesterday = $today->modify('-1 day'); // cutoff
    $cutoffStr = $yesterday->format('Y-m-d');
    $cutoffDt = DateTimeImmutable::createFromFormat('!Y-m-d', $cutoffStr, $tz);
    // ===== /ОГРАНИЧЕНИЕ =====

    // ===== ДАТЫ НЕДЕЛЬ (ISO) =====
    $cur = (new DateTimeImmutable('now', $tz))->setISODate($year, $week, 1);
    $curStart = $cur->format('Y-m-d');
    $curEnd   = $cur->modify('+6 days')->format('Y-m-d');

    $prev = $cur->modify('-7 days');
    $prevStart = $prev->format('Y-m-d');
    $prevEnd   = $prev->modify('+6 days')->format('Y-m-d');

    $diffDays = 7;

    // ===== колонки schedule_days (динамически, чтобы переживать миграции) =====
    $cols = [];
    $st = $pdo->prepare("
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema='public' AND table_name='schedule_days'
    ");
    $st->execute();
    while ($r = $st->fetch(PDO::FETCH_ASSOC)) {
        $cols[strtolower((string)$r['column_name'])] = (string)$r['column_name'];
    }

    $colTenant = $cols['tenant_id'] ?? null;
    $colDate   = $cols['date'] ?? null;
    $colGroup  = $cols['group_code'] ?? ($cols['group'] ?? null);
    $colEmp    = $cols['employee_id'] ?? ($cols['user_id'] ?? null);
    $colStatus = $cols['status'] ?? null;
    $colSlots  = $cols['slots'] ?? null;

    if (!$colTenant || !$colDate || !$colGroup || !$colEmp || !$colStatus) {
        http_response_code(500);
        echo json_encode(['error'=>'schema_mismatch','have'=>array_keys($cols)], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $q = static function(string $name): string {
        return '"' . str_replace('"', '""', $name) . '"';
    };

    // prepare audit insert (jsonb)
    $auditIns = $pdo->prepare('
        INSERT INTO public.audit_log (tenant_id, actor_user_id, actor_role, action, entity_type, entity_id, meta, changes)
        VALUES (:tid, :uid, :arole, :action, :etype, :eid, :meta::jsonb, :changes::jsonb)
    ');

    $pdo->beginTransaction();

    // 1) Берем прошлую неделю (полностью)
    $sel = $pdo->prepare("
        SELECT {$q($colDate)} AS date,
               {$q($colEmp)}  AS employee_id,
               {$q($colStatus)} AS status" . ($colSlots ? (", {$q($colSlots)} AS slots") : "") . "
        FROM {$q('schedule_days')}
        WHERE {$q($colTenant)} = :tid
          AND {$q($colGroup)}  = :g
          AND {$q($colDate)} BETWEEN :s AND :e
    ");
    $sel->execute([':tid'=>$tid, ':g'=>$group, ':s'=>$prevStart, ':e'=>$prevEnd]);
    $rows = $sel->fetchAll(PDO::FETCH_ASSOC) ?: [];

    // 2) Определяем диапазон, который реально трогаем (delete+insert)
    $delStart = $curStart;
    if (!$isOwner) {
        // если вчера позже начала недели — удаляем только с "вчера"
        if ($cutoffStr > $delStart) $delStart = $cutoffStr;

        // если вся неделя раньше cutoff — вообще ничего не делаем
        if ($delStart > $curEnd) {
            $pdo->commit();
            echo json_encode([
                'ok' => true,
                'group' => $group,
                'copied' => 0,
                'skipped_past_dates' => [$curStart . '...' . $curEnd],
                'cutoff' => $cutoffStr,
                'prev' => ['start'=>$prevStart,'end'=>$prevEnd],
                'cur'  => ['start'=>$curStart,'end'=>$curEnd],
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }
    }

    // 2.1) Считываем "до" по целевому диапазону (для аудита)
    $beforeMap = []; // "YYYY-MM-DD:EMP" => ['status'=>..,'slots'=>..]
    $selBefore = $pdo->prepare("
        SELECT {$q($colDate)} AS date,
               {$q($colEmp)}  AS employee_id,
               {$q($colStatus)} AS status" . ($colSlots ? (", {$q($colSlots)} AS slots") : "") . "
        FROM {$q('schedule_days')}
        WHERE {$q($colTenant)} = :tid
          AND {$q($colGroup)}  = :g
          AND {$q($colDate)} BETWEEN :s AND :e
    ");
    $selBefore->execute([':tid'=>$tid, ':g'=>$group, ':s'=>$delStart, ':e'=>$curEnd]);
    while ($r = $selBefore->fetch(PDO::FETCH_ASSOC)) {
        $d = trim((string)($r['date'] ?? ''));
        $eid = (int)($r['employee_id'] ?? 0);
        if ($d === '' || $eid <= 0) continue;
        $k = $d . ':' . $eid;
        $beforeMap[$k] = [
            'status' => (string)($r['status'] ?? ''),
            'slots'  => $colSlots ? (string)($r['slots'] ?? '') : '',
        ];
    }

    // 3) Чистим целевую неделю (только затрагиваемый диапазон)
    $del = $pdo->prepare("
        DELETE FROM {$q('schedule_days')}
        WHERE {$q($colTenant)} = :tid
          AND {$q($colGroup)}  = :g
          AND {$q($colDate)} BETWEEN :s AND :e
    ");
    $del->execute([':tid'=>$tid, ':g'=>$group, ':s'=>$delStart, ':e'=>$curEnd]);

    // 4) Готовим строки для вставки со сдвигом +7 дней (batch)
    $rowsToInsert = []; // each: [tid, date, group, eid, status, slots?]

    $skippedPastDates = [];
    $afterMap = []; // "YYYY-MM-DD:EMP" => ['status'=>..,'slots'=>..]

    foreach ($rows as $r) {
        $srcDate = trim((string)($r['date'] ?? ''));
        if ($srcDate === '') continue;

        $eid = (int)($r['employee_id'] ?? 0);
        if ($eid <= 0) continue;

        // исходная дата может быть date/text — приводим к YYYY-MM-DD через createFromFormat
        $srcDt = DateTimeImmutable::createFromFormat('!Y-m-d', $srcDate, $tz);
        if (!$srcDt) {
            try {
                $srcDt = new DateTimeImmutable($srcDate, $tz);
                $srcDt = $srcDt->setTime(0, 0, 0);
            } catch (Throwable $e) {
                continue;
            }
        }

        $newDt = $srcDt->modify('+' . $diffDays . ' day');
        $newDate = $newDt->format('Y-m-d');

        // мы реально трогаем только delStart..curEnd
        if ($newDate < $delStart || $newDate > $curEnd) {
            continue;
        }

        if (!$isOwner && $cutoffDt && $newDt < $cutoffDt) {
            $skippedPastDates[] = $newDate;
            continue;
        }

        $status = (string)($r['status'] ?? '');
        $slots = $colSlots ? (string)($r['slots'] ?? '') : '';

        // нормализуем slots (48 символов), чтобы журнал/расписание было консистентным
        if ($colSlots) {
            if ($slots === '' || strlen($slots) !== 48) {
                $slots = str_pad(substr($slots, 0, 48), 48, '0');
            }
        }

        if ($colSlots) {
            $rowsToInsert[] = [$tid, $newDate, $group, $eid, $status, $slots];
        } else {
            $rowsToInsert[] = [$tid, $newDate, $group, $eid, $status];
        }

        $k = $newDate . ':' . $eid;
        $afterMap[$k] = [
            'status' => $status,
            'slots'  => $slots,
        ];
    }

    // 4.1) Батч-вставка
    $saved = 0;
    if (!empty($rowsToInsert)) {
        


        $chunkSize = 800; // безопасный размер пачки

        for ($i = 0; $i < count($rowsToInsert); $i += $chunkSize) {
            $chunk = array_slice($rowsToInsert, $i, $chunkSize);
           

            $vals = [];
            $args = [];

            foreach ($chunk as $row) {
                if ($colSlots) {
                    // [tid, date, group, eid, status, slots]
                    $vals[] = '(?, ?, ?, ?, ?, ?)';
                    foreach ($row as $v) $args[] = $v;
                } else {
                    // [tid, date, group, eid, status]
                    $vals[] = '(?, ?, ?, ?, ?)';
                    foreach ($row as $v) $args[] = $v;
                }
            }

            if (empty($vals)) continue;

            $sql = "
                INSERT INTO {$q('schedule_days')}
                ({$q($colTenant)}, {$q($colDate)}, {$q($colGroup)}, {$q($colEmp)}, {$q($colStatus)}" . ($colSlots ? ", {$q($colSlots)}" : "") . ")
                VALUES " . implode(',', $vals) . "
                ON CONFLICT ({$q($colTenant)}, {$q($colDate)}, {$q($colGroup)}, {$q($colEmp)})
                DO UPDATE SET {$q($colStatus)} = EXCLUDED.{$q($colStatus)}" . ($colSlots ? ", {$q($colSlots)} = EXCLUDED.{$q($colSlots)}" : "") . "
            ";

            $stIns = $pdo->prepare($sql);
            $stIns->execute($args);
            $saved += count($chunk);
        }
    }

    // 5) Сбор diff для аудита (по затронутому диапазону)
    $changes = [];
    $keys = [];

    foreach ($beforeMap as $k => $_) $keys[$k] = true;
    foreach ($afterMap as $k => $_)  $keys[$k] = true;

    foreach (array_keys($keys) as $k) {
        $before = $beforeMap[$k] ?? null;
        $after  = $afterMap[$k]  ?? null;

        $isDifferent = false;
        if ($before === null && $after !== null) $isDifferent = true;         // создано
        elseif ($before !== null && $after === null) $isDifferent = true;     // удалено
        else {
            // и там и там есть — сравним
            if ((string)($before['status'] ?? '') !== (string)($after['status'] ?? '')) $isDifferent = true;
            if ($colSlots && (string)($before['slots'] ?? '') !== (string)($after['slots'] ?? '')) $isDifferent = true;
        }

        if (!$isDifferent) continue;

        // распарсим ключ
        $pos = strpos($k, ':');
        $date = $pos === false ? '' : substr($k, 0, $pos);
        $eidStr = $pos === false ? '' : substr($k, $pos + 1);
        $eid = (int)$eidStr;

        $changes[] = [
            'employee_id' => $eid,
            'date'        => $date,
            'before'      => $before, // может быть null
            'after'       => $after,  // может быть null
        ];
    }

    // 6) Пишем audit_log (только если есть реальные изменения)
    if (!empty($changes)) {
        $changesCount = count($changes);
        $sampleLimit = 120;
        $changesSample = array_slice($changes, 0, $sampleLimit);
        $truncated = ($changesCount > $sampleLimit);

        $meta = [
            'group_code' => $group,
            'year' => $year,
            'week' => $week,
            'prev' => ['start' => $prevStart, 'end' => $prevEnd],
            'cur'  => ['start' => $curStart,  'end' => $curEnd],
            'touched' => ['start' => $delStart, 'end' => $curEnd],
            'copied' => $saved,
            'changes_count' => $changesCount,
            'changes_sample_size' => count($changesSample),
            'changes_truncated' => $truncated,
        ];

        if (!$isOwner) {
            $meta['cutoff'] = $cutoffStr;
            if (!empty($skippedPastDates)) {
                $meta['skipped_past_dates'] = array_values(array_unique($skippedPastDates));
            }
        }

        $auditIns->execute([
            ':tid'     => $tid,
            ':uid'     => $actorUserId,
            ':arole'   => $role,
            ':action'  => 'schedule_copy',
            ':etype'   => 'schedule',
            ':eid'     => null,
            ':meta'    => json_encode($meta, JSON_UNESCAPED_UNICODE),
            ':changes' => json_encode($changesSample, JSON_UNESCAPED_UNICODE),
        ]);
    }

    // Если прошлой недели нет — просто ок (и без аудита)
    if (!$rows) {
        $pdo->commit();
        echo json_encode([
            'ok' => true,
            'group' => $group,
            'copied' => 0,
            'prev' => ['start'=>$prevStart,'end'=>$prevEnd],
            'cur'  => ['start'=>$curStart,'end'=>$curEnd],
            'audit_logged' => false,
            'audit_changes' => 0,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $pdo->commit();

    $resp = [
        'ok' => true,
        'group' => $group,
        'copied' => $saved, // сколько реально вставили
        'prev' => ['start'=>$prevStart,'end'=>$prevEnd],
        'cur'  => ['start'=>$curStart,'end'=>$curEnd],
        'audit_logged' => !empty($changes),
        'audit_changes' => count($changes),
    ];

    if (!$isOwner && !empty($skippedPastDates)) {
        $resp['skipped_past_dates'] = array_values(array_unique($skippedPastDates));
        $resp['cutoff'] = $cutoffStr;
    }

    echo json_encode($resp, JSON_UNESCAPED_UNICODE);
    exit;

} catch (Throwable $e) {
    if (isset($pdo) && $pdo instanceof PDO && $pdo->inTransaction()) {
        $pdo->rollBack();
    }
    if (!headers_sent()) header('Content-Type: application/json; charset=utf-8');
    http_response_code(500);
    echo json_encode(['error'=>'exception','details'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
}
