// frontend/app.js
let __scheduleSeq = 0;
const API_BASE = '/api';

let currentUser = null;
let CSRF = null;
let weekCache = {};
let inFlightSchedule = new Map(); // key -> Promise
// для динамических "часов за месяц" — теперь всегда берём готовые totalYaHours из табеля, по месяцу даты
let monthYaByYmByEmp = {};   // { 'YYYY-MM': { empId: hours } }
let weekBaseYaByEmp = {};    // базовые недельные часы Я (как в БД) — НЕ трогаем
let currentWeekDates = [];   // даты текущей недели (из расписания)
let scheduleMonthKey = null; // 'YYYY-MM' месяц, для которого считаем "часы за месяц" в расписании


const PROFILE_EMPLOYEES = [
  { username: 'epobed',  label: 'Побединская Е.' },
  { username: 'vmarch',  label: 'Марчишак В.' },
  { username: 'vkhabib', label: 'Хабибрахманова В.' },
  { username: 'mpozov',  label: 'Бехтер М.' },
  { username: 'bbelya',  label: 'Беляев Д.' },
  { username: 'lhomic',  label: 'Хомиченко В.' },
  { username: 'azayts',  label: 'Наринян А.' },
  { username: 'mgrigo',  label: 'Григоренко М.' },
  { username: 'jboych',  label: 'Бойченко Ю.' },
  { username: 'mbelya',  label: 'Беляева М.' },
  { username: 'echapl',  label: 'Чаплыгина Э.' },
  { username: 'eionov',  label: 'Ионова Е.' },
];

// =========================
// ГРУППЫ ИЗ БД (динамически)
// =========================

async function safeJson(res) {
  // если API вернул HTML/текст (например 500), чтобы не падало на res.json()
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  if (ct.includes('application/json')) return await res.json();
  const text = await res.text();
  throw new Error(`Non-JSON response (HTTP ${res.status}): ${text.slice(0, 200)}`);
}

async function fetchGroups() {
  try {
    const res = await fetch(`${API_BASE}/groups_list.php`, { credentials: 'include' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await safeJson(res);
    const groups = Array.isArray(data.groups) ? data.groups : [];
    if (groups.length) return groups;
  } catch (e) {
    console.warn('groups_list.php failed, using fallback', e);
  }

  // fallback, чтобы селект не был пустым совсем
  return [{ code: 'kassa', title: 'Касса' }];
}

function fillGroupSelect(selectEl, groups, selectedCode = '') {
  if (!selectEl) return;
  selectEl.innerHTML = '';
  groups.forEach(g => {
    const opt = document.createElement('option');
    opt.value = g.code;
    opt.textContent = g.title;
    if (g.code === selectedCode) opt.selected = true;
    selectEl.appendChild(opt);
  });
}

async function initGroupsUI() {
  const scheduleGroupEl = document.getElementById('scheduleGroup');
  const tabelGroupEl = document.getElementById('tabelGroup');

  // очистим на всякий случай (особенно после logout/login)
  if (scheduleGroupEl) scheduleGroupEl.innerHTML = '';
  if (tabelGroupEl) tabelGroupEl.innerHTML = '';

  const groups = await fetchGroups();

  // дефолт: группа пользователя ТОЛЬКО если она реально есть в списке, иначе первая из БД
  const want = (currentUser && currentUser.group_code) ? String(currentUser.group_code) : '';
  const has = want && groups.some(g => String(g.code) === want);
  const defaultGroup = has ? want : (groups[0] ? String(groups[0].code) : '');

  fillGroupSelect(scheduleGroupEl, groups, defaultGroup);
  fillGroupSelect(tabelGroupEl, groups, defaultGroup);

  return { groups, defaultGroup };
}

document.addEventListener('DOMContentLoaded', () => {
  initTabs();
  initLogin();
  initFilters();
  initCopyWeekInterceptor(); // <<< важное: перехват клика в capture-фазе (без inline onclick)
  checkAuth();
  initGlobalMouseUp();
});

function initTabs() {
  const tabButtons = document.querySelectorAll('.tab-button');
  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      tabButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tabId = btn.getAttribute('data-tab');
      document.querySelectorAll('.tab-content').forEach(tc => {
        tc.classList.remove('active');
      });
      document.getElementById(tabId).classList.add('active');
    });
  });
}

function initLogin() {
  const loginForm = document.getElementById('loginForm');
  const logoutBtn = document.getElementById('logoutBtn');

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errorEl = document.getElementById('loginError');
    errorEl.textContent = '';

    try {
      const res = await fetch(`${API_BASE}/auth.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'login', username, password }),
        credentials: 'include'
      });
      const data = await safeJson(res);
      if (!res.ok || !data.authenticated) {
        errorEl.textContent = data.error || 'Ошибка входа';
        return;
      }
      currentUser = data;
      CSRF = data.csrf || null;
      await onLogin();
    } catch (err) {
      errorEl.textContent = 'Ошибка соединения с сервером';
    }
  });

  logoutBtn.addEventListener('click', async (e) => {
    e.preventDefault();
    e.stopPropagation();

    try {
      await fetch(`${API_BASE}/auth.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'logout' }),
        credentials: 'include'
      });
    } catch (_) {}

    currentUser = null;
    CSRF = null;
    document.getElementById('mainPanel').style.display = 'none';
    document.getElementById('loginPanel').style.display = 'block';

    // очистим селекты групп, чтобы не оставалось старых значений
    const scheduleGroupEl = document.getElementById('scheduleGroup');
    const tabelGroupEl = document.getElementById('tabelGroup');
    if (scheduleGroupEl) scheduleGroupEl.innerHTML = '';
    if (tabelGroupEl) tabelGroupEl.innerHTML = '';
  });
}

async function checkAuth() {
  try {
    const res = await fetch(`${API_BASE}/auth.php?action=me`, { credentials: 'include' });
    const data = await safeJson(res);
    if (data.authenticated) {
      currentUser = data;
      CSRF = data.csrf || null;
      await onLogin();
    }
  } catch (e) {
    // ignore
  }
}

async function onLogin() {
  // Нормализуем роль один раз, чтобы проверки прав не ломались из-за пробелов/регистра
  currentUser.role = String(currentUser.role || '').trim().toLowerCase();
  console.log('ROLE=', currentUser.role);

  document.getElementById('loginPanel').style.display = 'none';
  document.getElementById('mainPanel').style.display = 'block';

  const info = `${currentUser.employee_name || currentUser.username} (${currentUser.role})`;
  document.getElementById('userInfo').textContent = info;

  const adminLink = document.getElementById('adminLink');
if (adminLink) {
  const canAdmin = (currentUser.role === 'owner' || currentUser.role === 'tenant_admin');

  // админка через роутер
  adminLink.href = '/?r=admin';

  // Форсим показ/скрытие (перебиваем inline display:none из HTML)
  adminLink.style.setProperty(
    'display',
    canAdmin ? 'inline-block' : 'none',
    'important'
  );
}
  // viewer не может редактировать расписание
  if (currentUser.role === 'viewer') {
    const copyBtn = document.getElementById('copyWeekBtn');
    const saveBtn = document.getElementById('saveScheduleBtn');
    if (copyBtn) copyBtn.style.display = 'none';
    if (saveBtn) saveBtn.style.display = 'none';
  } else {
    // на случай повторного логина под другой ролью
    const copyBtn = document.getElementById('copyWeekBtn');
    const saveBtn = document.getElementById('saveScheduleBtn');
    if (copyBtn) copyBtn.style.display = '';
    if (saveBtn) saveBtn.style.display = '';
  }

  // личный кабинет
  setupProfileAdminPanel();

  // ВАЖНО: сначала подгружаем группы из БД, потом выставляем дефолты и грузим расписание
  await initGroupsUI();

  loadDefaultFilters();
}


function initFilters() {
  const years = [2026, 2027];
  const months = [
    'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
    'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'
  ];

  const scheduleYear = document.getElementById('scheduleYear');
  const tabelYear = document.getElementById('tabelYear');
  const profileYear = document.getElementById('profileYear');

  years.forEach(y => {
    if (scheduleYear) {
      const o1 = document.createElement('option');
      o1.value = y;
      o1.textContent = y;
      scheduleYear.appendChild(o1);
    }
    if (tabelYear) {
      const o2 = document.createElement('option');
      o2.value = y;
      o2.textContent = y;
      tabelYear.appendChild(o2);
    }
    if (profileYear) {
      const o3 = document.createElement('option');
      o3.value = y;
      o3.textContent = y;
      profileYear.appendChild(o3);
    }
  });

  const scheduleMonth = document.getElementById('scheduleMonth');
  const tabelMonth = document.getElementById('tabelMonth');
  const profileMonth = document.getElementById('profileMonth');

  months.forEach((m, idx) => {
    const val = idx + 1;
    if (scheduleMonth) {
      const o1 = document.createElement('option');
      o1.value = val;
      o1.textContent = m;
      scheduleMonth.appendChild(o1);
    }
    if (tabelMonth) {
      const o2 = document.createElement('option');
      o2.value = val;
      o2.textContent = m;
      tabelMonth.appendChild(o2);
    }
    if (profileMonth) {
      const o3 = document.createElement('option');
      o3.value = val;
      o3.textContent = m;
      profileMonth.appendChild(o3);
    }
  });

  if (scheduleYear) scheduleYear.addEventListener('change', loadWeeksForSchedule);
  if (scheduleMonth) scheduleMonth.addEventListener('change', loadWeeksForSchedule);

  const scheduleLoadBtn = document.getElementById('scheduleLoadBtn');
  const saveScheduleBtn = document.getElementById('saveScheduleBtn');
  const exportAllGroupsBtn = document.getElementById('exportAllGroupsBtn');

  if (scheduleLoadBtn) {
    scheduleLoadBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      loadSchedule();
    });
  }

  // ВАЖНО: copyWeekBtn мы НЕ вешаем тут — его перехватывает initCopyWeekInterceptor() в capture-фазе
  if (saveScheduleBtn) {
    saveScheduleBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      saveSchedule(e);
    });
  }

  if (exportAllGroupsBtn) {
    exportAllGroupsBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      exportAllGroupsSchedule(e);
    });
  }

  const tabelLoadBtn = document.getElementById('tabelLoadBtn');
  const tabelExportBtn = document.getElementById('tabelExportBtn');

  if (tabelLoadBtn) {
    tabelLoadBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      loadTabel();
    });
  }

  if (tabelExportBtn) {
    tabelExportBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();
      exportTabel();
    });
  }
  const tabelExport2Btn = document.getElementById('tabelExport2Btn');

if (tabelExport2Btn) {
  tabelExport2Btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    exportTabel2();
  });
}

  if (profileYear) profileYear.addEventListener('change', loadProfileImage);
  if (profileMonth) profileMonth.addEventListener('change', loadProfileImage);
}

// ЖЁСТКИЙ перехват клика по "Копировать предыдущую неделю".
function initCopyWeekInterceptor() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('#copyWeekBtn');
    if (!btn) return;

    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();

    copyWeek(e);
  }, true);
}

function pad2(n){ return String(n).padStart(2,'0'); }

function isoTodayLocal() {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth()+1)}-${pad2(d.getDate())}`;
}

// если weeks.php отдаёт start/end или dates — используем их
function weekContainsDate(w, iso) {
  if (!w) return false;
  if (w.start && w.end) return (iso >= w.start && iso <= w.end);
  if (Array.isArray(w.dates)) return w.dates.includes(iso);
  return false;
}

function pickWeekIndexForToday(weeks, fallbackIndex) {
  const today = isoTodayLocal();
  const found = (weeks || []).find(w => weekContainsDate(w, today));
  return found ? found.index : fallbackIndex;
}


async function loadDefaultFilters() {
  const scheduleYearEl  = document.getElementById('scheduleYear');
  const tabelYearEl     = document.getElementById('tabelYear');
  const scheduleMonthEl = document.getElementById('scheduleMonth');
  const tabelMonthEl    = document.getElementById('tabelMonth');
  const scheduleGroupEl = document.getElementById('scheduleGroup');
  const tabelGroupEl    = document.getElementById('tabelGroup');
  const profileYearEl   = document.getElementById('profileYear');
  const profileMonthEl  = document.getElementById('profileMonth');

  // === 1) Дефолты по календарю: текущий год/месяц ===
  const now = new Date();
  const y = now.getFullYear();
  const m = now.getMonth() + 1;

  if (scheduleYearEl) scheduleYearEl.value = y;
  if (tabelYearEl)    tabelYearEl.value = y;
  if (scheduleMonthEl) scheduleMonthEl.value = m;
  if (tabelMonthEl)    tabelMonthEl.value = m;

  // === 2) Дефолт-группа (как было) ===
  const want = (currentUser && currentUser.group_code) ? String(currentUser.group_code) : '';

  const scheduleHas = scheduleGroupEl && Array.from(scheduleGroupEl.options).some(o => o.value === want);
  const tabelHas    = tabelGroupEl && Array.from(tabelGroupEl.options).some(o => o.value === want);

  if (scheduleGroupEl && scheduleGroupEl.options.length) {
    scheduleGroupEl.value = scheduleHas ? want : scheduleGroupEl.options[0].value;
  }
  if (tabelGroupEl && tabelGroupEl.options.length) {
    tabelGroupEl.value = tabelHas ? want : tabelGroupEl.options[0].value;
  }

  // профиль (оставим “текущий” год/месяц тоже, логично)
  if (profileYearEl)  profileYearEl.value = y;
  if (profileMonthEl) profileMonthEl.value = m;

  // === 3) Загружаем список недель по году, выбираем неделю с сегодняшним днём ===
  const weeks = await loadWeeksForSchedule();

  const weekEl = document.getElementById('scheduleWeek');
  if (weekEl && weekEl.options.length) {
    // fallback = первый option
    const fallbackIndex = parseInt(weekEl.options[0].value, 10) || 1;

    const bestIndex = pickWeekIndexForToday(weeks, fallbackIndex);

    // если вдруг weekSelect ещё не наполнен — подстрахуемся
    const hasIndex = Array.from(weekEl.options).some(o => parseInt(o.value, 10) === bestIndex);
    if (hasIndex) weekEl.value = String(bestIndex);
  }

  // === 4) Грузим расписание именно выбранной недели ===
  await loadSchedule(true);

  // остальное как было
  loadProfileImage();
}


async function loadWeeksForSchedule() {
  const yearEl = document.getElementById('scheduleYear');
  if (!yearEl) return [];
  const year = parseInt(yearEl.value, 10);
  if (!year) return [];

  if (weekCache[year]) {
    const weeks = weekCache[year] || [];
    fillWeekSelect(weeks);
    return weeks;
  }

  try {
    const res = await fetch(`${API_BASE}/weeks.php?year=${year}`, { credentials: 'include' });
    const data = await safeJson(res);
    const weeks = data.weeks || [];
    weekCache[year] = weeks;
    fillWeekSelect(weeks);
    return weeks;
  } catch (e) {
    console.error(e);
    return [];
  }
}


function fillWeekSelect(weeks) {
  const weekSelect = document.getElementById('scheduleWeek');
  if (!weekSelect) return;
  weekSelect.innerHTML = '';
  (weeks || []).forEach(w => {
    const opt = document.createElement('option');
    opt.value = w.index;
    opt.textContent = w.label;
    weekSelect.appendChild(opt);
  });
}

// глобальные флаги для Ctrl-протяжки
function initGlobalMouseUp() {
  window.__isSlotDrag = false;
  window.__slotDragAction = null;
  document.addEventListener('mouseup', () => {
    window.__isSlotDrag = false;
    window.__slotDragAction = null;
  });
}

async function loadSchedule(force = false) {
  const groupEl = document.getElementById('scheduleGroup');
  const yearEl  = document.getElementById('scheduleYear');
  const weekEl  = document.getElementById('scheduleWeek');
  if (!groupEl || !yearEl || !weekEl) return;

  const group = groupEl.value;
  const year  = parseInt(yearEl.value, 10);
  const week  = parseInt(weekEl.value, 10);
  if (!group || !year || !week) return;

  const key = `${group}|${year}|${week}`;
  const seq = ++__scheduleSeq;

  const container = document.getElementById('scheduleContainer');
  if (container) container.textContent = 'Загрузка...';

  // если НЕ force — можно дедуплицировать
  if (!force && inFlightSchedule.has(key)) {
    try { await inFlightSchedule.get(key); } catch(_) {}
    return;
  }

  const p = (async () => {
    const url =
      `${API_BASE}/schedule_get.php?group=${encodeURIComponent(group)}&year=${year}&week=${week}` +
      `&_v=${Date.now()}`; // на всякий случай против микро-кэша/прокси

    const res = await fetch(url, { credentials: 'include' });
    const data = await safeJson(res);

    // рендерим только самый свежий запрос
    if (seq !== __scheduleSeq) return;

    renderSchedule(data);
    initMonthTotalsForSchedule(data);
  })();

  // в force режиме мы НЕ блокируемся старым inFlight
  inFlightSchedule.set(key, p);

  try {
    await p;
  } catch (e) {
    if (container) container.textContent = 'Ошибка загрузки расписания';
  } finally {
    // удаляем только если это тот же promise
    if (inFlightSchedule.get(key) === p) inFlightSchedule.delete(key);
  }
}



function applySlotAction(cell) {
  if (!window.__slotDragAction) return;
  const shouldActivate = window.__slotDragAction === 'activate';
  if (shouldActivate) cell.classList.add('active');
  else cell.classList.remove('active');

  const tr = cell.closest('tr');
  if (tr) {
    updateRowDayHours(tr);
    const empId = tr.dataset.employeeId;
    if (empId) {
      updateWeekHoursForEmployee(empId);
      updateMonthHoursForEmployee(empId);
    }
  }
}

function renderSchedule(data) {
  const container = document.getElementById('scheduleContainer');
  container.innerHTML = '';

  currentWeekDates = (data.days || []).map(d => d.date);

  (data.days || []).forEach(day => {
    const dayDiv = document.createElement('div');
    dayDiv.className = 'day-block';

    const header = document.createElement('div');
    header.className = 'day-header';
    header.textContent = `${day.weekday} ${day.date.split('-').reverse().join('.')}`;
    dayDiv.appendChild(header);

    const table = document.createElement('table');
    table.className = 'schedule-table';

    const thead = document.createElement('thead');
    const trHead = document.createElement('tr');

    const thName = document.createElement('th');
    thName.textContent = 'Сотрудник';
    trHead.appendChild(thName);

    const thStatus = document.createElement('th');
    thStatus.textContent = 'Статус';
    trHead.appendChild(thStatus);

    const thTime = document.createElement('th');
    thTime.textContent = 'Время (06:00–05:00)';
    trHead.appendChild(thTime);

    const thDayHours = document.createElement('th');
    thDayHours.textContent = 'Часы за день';
    trHead.appendChild(thDayHours);

    const thWeekHours = document.createElement('th');
    thWeekHours.textContent = 'Часы за неделю (Я)';
    trHead.appendChild(thWeekHours);

    const thMonthHours = document.createElement('th');
    thMonthHours.textContent = 'Часы за месяц (Я)';
    trHead.appendChild(thMonthHours);

    thead.appendChild(trHead);
    table.appendChild(thead);

    const tbody = document.createElement('tbody');

    (day.employees || []).forEach(emp => {
      const tr = document.createElement('tr');
      tr.dataset.date = day.date;
      tr.dataset.employeeId = emp.employee_id;

      const tdName = document.createElement('td');
      tdName.textContent = emp.name;
      tr.appendChild(tdName);

      const tdStatus = document.createElement('td');
      const select = document.createElement('select');
      ['Я', 'В', 'ОТ', 'ОВ', 'РВ', 'РВ1', 'НН', 'Б'].forEach(st => {
        const opt = document.createElement('option');
        opt.value = st;
        opt.textContent = st;
        select.appendChild(opt);
      });
      select.value = emp.status || 'В';
      applyStatusClass(tr, select.value);
      select.addEventListener('change', () => {
        applyStatusClass(tr, select.value);
        updateRowDayHours(tr);
        updateWeekHoursForEmployee(emp.employee_id);
        updateMonthHoursForEmployee(emp.employee_id);
      });
      tdStatus.appendChild(select);
      tr.appendChild(tdStatus);

      const tdTime = document.createElement('td');
      tdTime.className = 'slots-cell';

      const timeWrapper = document.createElement('div');
      timeWrapper.className = 'slots-time-wrapper';

      const hoursRow = document.createElement('div');
      hoursRow.className = 'hours-header-row';
      for (let h = 0; h < 24; h++) {
        const hourCell = document.createElement('div');
        hourCell.className = 'hour-label-cell';
        const hour = (6 + h) % 24;
        hourCell.textContent = hour.toString().padStart(2, '0') + ':00';
        hoursRow.appendChild(hourCell);
      }
      timeWrapper.appendChild(hoursRow);

      const slotsWrapper = document.createElement('div');
      slotsWrapper.className = 'slots-wrapper';

      const slots = emp.slots || '0'.repeat(48);
      for (let i = 0; i < 48; i++) {
        const cell = document.createElement('div');
        cell.className = 'slot-cell';
        if (slots[i] === '1') cell.classList.add('active');
        cell.dataset.index = i;

        cell.addEventListener('click', (e) => {
          if (e.ctrlKey) return;
          cell.classList.toggle('active');
          updateRowDayHours(tr);
          updateWeekHoursForEmployee(emp.employee_id);
          updateMonthHoursForEmployee(emp.employee_id);
        });

        cell.addEventListener('mousedown', (e) => {
          if (!e.ctrlKey) return;
          e.preventDefault();
          window.__isSlotDrag = true;
          window.__slotDragAction = cell.classList.contains('active') ? 'deactivate' : 'activate';
          applySlotAction(cell);
        });

        cell.addEventListener('mouseenter', (e) => {
          if (!window.__isSlotDrag || !e.ctrlKey) return;
          applySlotAction(cell);
        });

        slotsWrapper.appendChild(cell);
      }

      timeWrapper.appendChild(slotsWrapper);
      tdTime.appendChild(timeWrapper);
      tr.appendChild(tdTime);

      const tdDayHours = document.createElement('td');
      tdDayHours.className = 'day-hours-cell';
      tdDayHours.textContent = '0.0';
      tr.appendChild(tdDayHours);

      const tdWeekHours = document.createElement('td');
      tdWeekHours.className = 'week-hours-cell';
      tdWeekHours.textContent = '0.0';
      tr.appendChild(tdWeekHours);

      const tdMonthHours = document.createElement('td');
      tdMonthHours.className = 'month-hours-cell';
      tdMonthHours.textContent = '0.0';
      tr.appendChild(tdMonthHours);

      tbody.appendChild(tr);

      updateRowDayHours(tr);
    });

    table.appendChild(tbody);
    dayDiv.appendChild(table);
    container.appendChild(dayDiv);
  });

  if (data.employees) {
    data.employees.forEach(emp => {
      updateWeekHoursForEmployee(emp.id);
    });
  }
}

function calcRowDayHours(tr) {
  if (!tr) return 0;
  const cells = tr.querySelectorAll('.slot-cell');
  let count = 0;
  cells.forEach(c => { if (c.classList.contains('active')) count++; });
  return count * 0.5;
}

// применение CSS-классов к строке расписания по статусу
function applyStatusClass(tr, status) {
  if (!tr) return;
  tr.classList.remove('status-ya', 'status-v', 'status-ot', 'status-ov', 'status-rv', 'status-rv1', 'status-nn', 'status-b');
  switch (status) {
    case 'Я': tr.classList.add('status-ya'); break;
    case 'В': tr.classList.add('status-v'); break;
    case 'ОТ': tr.classList.add('status-ot'); break;
    case 'ОВ': tr.classList.add('status-ov'); break;
    case 'РВ': tr.classList.add('status-rv'); break;
    case 'РВ1': tr.classList.add('status-rv1'); break;
    case 'НН': tr.classList.add('status-nn'); break;
    case 'Б': tr.classList.add('status-b'); break;
  }
}

// ЧАСЫ ЗА ДЕНЬ (Я + РВ)
function updateRowDayHours(tr) {
  if (!tr) return;
  const statusSelect = tr.querySelector('select');
  const dayHoursCell = tr.querySelector('.day-hours-cell');
  if (!statusSelect || !dayHoursCell) return;

  const status = statusSelect.value;
  let h = 0;
  if (status === 'Я' || status === 'РВ' || status === 'РВ1') h = calcRowDayHours(tr);
  dayHoursCell.textContent = h.toFixed(1);
}

// ЧАСЫ ЗА НЕДЕЛЮ (только Я)
function updateWeekHoursForEmployee(empId) {
  const empKey = String(empId);
  const rows = document.querySelectorAll(`#scheduleContainer tbody tr[data-employee-id="${empKey}"]`);
  let sum = 0;
  rows.forEach(tr => {
    const statusEl = tr.querySelector('select');
    if (!statusEl) return;
    if (statusEl.value !== 'Я') return;
    sum += calcRowDayHours(tr);
  });
  rows.forEach(tr => {
    const td = tr.querySelector('.week-hours-cell');
    if (td) td.textContent = sum.toFixed(1);
  });
}

// ИНИЦИАЛИЗАЦИЯ БАЗОВЫХ МЕСЯЧНЫХ ЧАСОВ (из табеля)
async function initMonthTotalsForSchedule(scheduleData) {
  monthBaseYaByEmp = {};
  weekBaseYaByEmp = {};

  currentWeekDates = (scheduleData.days || []).map(d => d.date);
  const weekDateSet = new Set(currentWeekDates);

  const groupEl = document.getElementById('scheduleGroup');
  const yearEl = document.getElementById('scheduleYear');
  const monthEl = document.getElementById('scheduleMonth');
  if (!groupEl || !yearEl || !monthEl) return;

  const group = groupEl.value;

// год/месяц берём от понедельника выбранной недели (как в экспорте)
const weekStart = String(scheduleData && scheduleData.start ? scheduleData.start : '');
if (!/^\d{4}-\d{2}-\d{2}$/.test(weekStart)) return;

const year  = parseInt(weekStart.slice(0, 4), 10);
const month = parseInt(weekStart.slice(5, 7), 10);
if (!group || !year || !month) return;

scheduleMonthKey = weekStart.slice(0, 7); // 'YYYY-MM'


// (не обязательно, но полезно) синхронизируем селект месяца, чтобы UI не путал
if (yearEl) yearEl.value = String(year);
if (monthEl) monthEl.value = String(month);

  try {
    const res = await fetch(
      `${API_BASE}/tabel_get.php?group=${encodeURIComponent(group)}&year=${year}&month=${month}`,
      { credentials: 'include' }
    );
    const data = await safeJson(res);

    (data.employees || []).forEach(emp => {
      const empId = String(emp.employee_id);
      const baseMonth = typeof emp.totalYaHours === 'number' ? emp.totalYaHours : 0;
      monthBaseYaByEmp[empId] = baseMonth;

      let weekYa = 0;
      (data.days || []).forEach((dayObj, idx) => {
        if (!weekDateSet.has(dayObj.date)) return;
        const dayEmp = emp.days && emp.days[idx];
        if (!dayEmp) return;
        const ya = typeof dayEmp.yaHours === 'number' ? dayEmp.yaHours : 0;
        weekYa += ya;
      });
      weekBaseYaByEmp[empId] = weekYa;

      updateWeekHoursForEmployee(empId);
      updateMonthHoursForEmployee(empId);
    });
  } catch (e) {
    console.error('Ошибка загрузки месячных часов', e);
  }
}

// ЧАСЫ ЗА МЕСЯЦ (только Я, динамически: база из табеля + разница текущей недели)
function updateMonthHoursForEmployee(empId) {
  const empKey = String(empId);

  if (typeof monthBaseYaByEmp[empKey] === 'undefined') return;

  const baseMonth = monthBaseYaByEmp[empKey] || 0;
  const baseWeek = weekBaseYaByEmp[empKey] || 0;

  const rows = document.querySelectorAll(`#scheduleContainer tbody tr[data-employee-id="${empKey}"]`);
  let currentWeekYa = 0;
  rows.forEach(tr => {
  if (!scheduleMonthKey) return;

  const d = String(tr.dataset.date || ''); // 'YYYY-MM-DD'
  // берём только дни нужного месяца (как в экспорте)
  if (!d.startsWith(scheduleMonthKey + '-')) return;

  const statusEl = tr.querySelector('select');
  if (!statusEl || statusEl.value !== 'Я') return;

  currentWeekYa += calcRowDayHours(tr);
});

  const newMonth = baseMonth - baseWeek + currentWeekYa;

  rows.forEach(tr => {
    const td = tr.querySelector('.month-hours-cell');
    if (td) td.textContent = newMonth.toFixed(1);
  });
}

function collectScheduleData() {
  const groupEl = document.getElementById('scheduleGroup');
  const yearEl = document.getElementById('scheduleYear');
  const weekEl = document.getElementById('scheduleWeek');
  const group = groupEl ? groupEl.value : null;
  const year = yearEl ? parseInt(yearEl.value, 10) : null;
  const week = weekEl ? parseInt(weekEl.value, 10) : null;

  const dayBlocks = document.querySelectorAll('#scheduleContainer .day-block');
  const days = [];

  dayBlocks.forEach(block => {
    const trs = block.querySelectorAll('tbody tr');
    if (!trs.length) return;
    const date = trs[0].dataset.date;
    const employees = [];
    trs.forEach(tr => {
      const employeeId = parseInt(tr.dataset.employeeId, 10);
      const statusEl = tr.querySelector('select');
      const slotCells = tr.querySelectorAll('.slot-cell');
      if (!statusEl) return;
      const status = statusEl.value;
      let slots = '';
      slotCells.forEach(c => { slots += c.classList.contains('active') ? '1' : '0'; });
      employees.push({ employee_id: employeeId, status, slots });
    });
    days.push({ date, employees });
  });

  return { group, year, week, days };
}

async function saveSchedule(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }

  if (!currentUser || !['owner', 'tenant_admin', 'admin'].includes(currentUser.role)) {
    alert('У вас нет прав для сохранения');
    return;
  }

  const payload = collectScheduleData();

  try {
    const res = await fetch(`${API_BASE}/schedule_save.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': CSRF || '' },
      body: JSON.stringify(payload),
      credentials: 'include'
    });

    const data = await safeJson(res);
    if (!res.ok || !data.ok) {
      alert('Ошибка сохранения: ' + (data.error || ''));
      return;
    }

    alert('Изменения сохранены');
  } catch (e2) {
    alert('Ошибка соединения');
  }
}

async function copyWeek(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
  }

  if (!currentUser || !['owner', 'tenant_admin', 'admin'].includes(currentUser.role)) {
    alert('У вас нет прав для сохранения');
    return;
  }

  const groupEl = document.getElementById('scheduleGroup');
  const yearEl = document.getElementById('scheduleYear');
  const weekEl = document.getElementById('scheduleWeek');
  if (!groupEl || !yearEl || !weekEl) return;

  const group = groupEl.value;
  const year = parseInt(yearEl.value, 10);
  const week = parseInt(weekEl.value, 10);
  if (!group || !year || !week) return;

  if (!confirm('Копировать данные из предыдущей недели? Текущая неделя будет перезаписана.')) {
    return;
  }

  try {
    const params = new URLSearchParams();
    params.set('group', String(group));
    params.set('year', String(year));
    params.set('week', String(week));

    const res = await fetch(`${API_BASE}/schedule_copy.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-CSRF-Token': CSRF || '' },
      body: params.toString(),
      credentials: 'include'
    });

    const data = await safeJson(res);
    if (!res.ok || !data.ok) {
      alert('Ошибка копирования: ' + (data.error || ''));
      return;
    }

    alert('Неделя скопирована');
    await loadSchedule(true);
  } catch (err) {
    alert('Ошибка соединения');
  }
}

async function loadTabel() {
  const groupEl = document.getElementById('tabelGroup');
  const yearEl = document.getElementById('tabelYear');
  const monthEl = document.getElementById('tabelMonth');
  if (!groupEl || !yearEl || !monthEl) return;

  const group = groupEl.value;
  const year = parseInt(yearEl.value, 10);
  const month = parseInt(monthEl.value, 10);
  if (!group || !year || !month) return;

  const container = document.getElementById('tabelContainer');
  container.textContent = 'Загрузка...';

  try {
    const res = await fetch(
      `${API_BASE}/tabel_get.php?group=${encodeURIComponent(group)}&year=${year}&month=${month}`,
      { credentials: 'include' }
    );
    const data = await safeJson(res);
    renderTabel(data);
  } catch (e) {
    container.textContent = 'Ошибка загрузки табеля';
  }
}

function renderTabel(data) {
  const container = document.getElementById('tabelContainer');
  container.innerHTML = '';

  const info = document.createElement('div');
  info.className = 'tabel-info';
  info.textContent = `${data.monthName} ${data.year}`;
  container.appendChild(info);

  const table = document.createElement('table');
  table.className = 'tabel-table';

  const thead = document.createElement('thead');

  // строка дат
  const trDates = document.createElement('tr');
  const thEmp = document.createElement('th');
  thEmp.textContent = 'Сотрудник / Дата';
  trDates.appendChild(thEmp);

  (data.days || []).forEach(d => {
    const th = document.createElement('th');
    const dt = new Date(d.date);
    th.textContent = dt.getDate();
    if (d.holiday || d.weekend) th.classList.add('tabel-weekend-header');
    trDates.appendChild(th);
  });

  const thNorm = document.createElement('th');
  thNorm.textContent = 'Норма';
  trDates.appendChild(thNorm);

  const thFact = document.createElement('th');
  thFact.textContent = 'Факт (Я)';
  trDates.appendChild(thFact);

  const thRv = document.createElement('th');
  thRv.textContent = 'РВ';
  trDates.appendChild(thRv);

  const thDiff = document.createElement('th');
  thDiff.textContent = 'Разница';
  trDates.appendChild(thDiff);

  thead.appendChild(trDates);

  // строка дней недели
  const trWeekdays = document.createElement('tr');
  const thW = document.createElement('th');
  thW.textContent = 'День недели';
  trWeekdays.appendChild(thW);

  (data.days || []).forEach(d => {
    const th = document.createElement('th');
    th.textContent = d.weekday_short || d.weekday || '';
    if (d.holiday || d.weekend) th.classList.add('tabel-weekend-header');
    trWeekdays.appendChild(th);
  });

  trWeekdays.appendChild(document.createElement('th'));
  trWeekdays.appendChild(document.createElement('th'));
  trWeekdays.appendChild(document.createElement('th'));
  trWeekdays.appendChild(document.createElement('th'));

  thead.appendChild(trWeekdays);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');

  (data.employees || []).forEach(emp => {
    const tr = document.createElement('tr');
    const tdName = document.createElement('td');
    tdName.textContent = emp.name;
    tr.appendChild(tdName);

    emp.days.forEach(d => {
      const td = document.createElement('td');

      const status = d.status || '';
      const hours = typeof d.hours === 'number' ? d.hours.toFixed(1) : '0.0';

      td.innerHTML = `${status}<br>${hours}`;
      td.classList.add('tabel-cell-combined');

      if (status === 'В') td.classList.add('tabel-status-v');
      else if (status === 'ОТ') td.classList.add('tabel-status-ot');
      else if (status === 'ОВ') td.classList.add('tabel-status-ov');
      else if (status === 'РВ') td.classList.add('tabel-status-rv');
      else if (status === 'РВ1') td.classList.add('tabel-status-rv1');
      else if (status === 'НН') td.classList.add('tabel-status-nn');
      else if (status === 'Б') td.classList.add('tabel-status-b');

      tr.appendChild(td);
    });

    const tdNorm = document.createElement('td');
    tdNorm.textContent = emp.normHoursEmployee.toFixed(1);
    tr.appendChild(tdNorm);

    const tdFact = document.createElement('td');
    tdFact.textContent = emp.totalYaHours.toFixed(1);
    tr.appendChild(tdFact);

    const tdRv = document.createElement('td');
    tdRv.textContent = emp.totalRvHours.toFixed(1);
    tr.appendChild(tdRv);

    const tdDiff = document.createElement('td');
    const diff = emp.totalYaHours - emp.normHoursEmployee;
    tdDiff.textContent = diff.toFixed(1);
    tr.appendChild(tdDiff);

    tbody.appendChild(tr);
  });

  table.appendChild(tbody);
  container.appendChild(table);
}

function exportTabel() {
  const groupEl = document.getElementById('tabelGroup');
  const yearEl = document.getElementById('tabelYear');
  const monthEl = document.getElementById('tabelMonth');
  if (!groupEl || !yearEl || !monthEl) return;

  const group = groupEl.value;
  const year = parseInt(yearEl.value, 10);
  const month = parseInt(monthEl.value, 10);
  if (!group || !year || !month) return;

  const role = (currentUser && currentUser.role) ? String(currentUser.role) : '';
  const canAll = (role === 'owner' || role === 'tenant_admin');

  // Для owner/tenant_admin по умолчанию экспортируем ВСЕ группы (как было раньше).
  const url = canAll
    ? `${API_BASE}/tabel_export.php?group=all&year=${year}&month=${month}`
    : `${API_BASE}/tabel_export.php?group=${encodeURIComponent(group)}&year=${year}&month=${month}`;
  window.open(url, '_blank');
}

function exportTabel2() {
  const groupEl = document.getElementById('tabelGroup');
  const yearEl = document.getElementById('tabelYear');
  const monthEl = document.getElementById('tabelMonth');
  if (!groupEl || !yearEl || !monthEl) return;

  const group = groupEl.value;
  const year = parseInt(yearEl.value, 10);
  const month = parseInt(monthEl.value, 10);
  if (!group || !year || !month) return;

  const role = (currentUser && currentUser.role) ? String(currentUser.role) : '';
  const canAll = (role === 'owner' || role === 'tenant_admin');

  const url = canAll
    ? `${API_BASE}/tabel_export2.php?group=all&year=${year}&month=${month}`
    : `${API_BASE}/tabel_export2.php?group=${encodeURIComponent(group)}&year=${year}&month=${month}`;

  window.open(url, '_blank');
}


function exportAllGroupsSchedule(e) {
  if (e) {
    e.preventDefault();
    e.stopPropagation();
  }

  const yearEl = document.getElementById('scheduleYear');
  const weekEl = document.getElementById('scheduleWeek');
  if (!yearEl || !weekEl) {
    alert('Сначала выберите год и неделю');
    return;
  }

  const year = parseInt(yearEl.value, 10);
  const week = parseInt(weekEl.value, 10);
  if (!year || !week) {
    alert('Сначала выберите год и неделю');
    return;
  }

  const url = `${API_BASE}/schedule_export_all.php?year=${year}&week=${week}`;
  window.open(url, '_blank');
}

// ===== ЛИЧНЫЙ КАБИНЕТ =====

function getProfileTargetUsername() {
  if (!currentUser) return null;
  if (currentUser.username === 'ddavyd') {
    const select = document.getElementById('profileEmployee');
    if (select && select.value) return select.value;
  }
  return currentUser.username;
}

function setupProfileAdminPanel() {
  const panel = document.getElementById('profileAdminPanel');
  if (!panel) return;

  if (!currentUser || currentUser.username !== 'ddavyd') {
    panel.style.display = 'none';
    return;
  }
  panel.style.display = 'block';

  const select = document.getElementById('profileEmployee');
  if (select && !select.options.length) {
    PROFILE_EMPLOYEES.forEach(p => {
      const opt = document.createElement('option');
      opt.value = p.username;
      opt.textContent = p.label;
      select.appendChild(opt);
    });
  }
  if (select && !select.value && PROFILE_EMPLOYEES.length > 0) {
    select.value = PROFILE_EMPLOYEES[0].username;
  }
  if (select) {
    select.addEventListener('change', () => {
      loadProfileImage();
    });
  }

  const uploadBtn = document.getElementById('profileUploadBtn');
  const deleteBtn = document.getElementById('profileDeleteBtn');
  const fileInput = document.getElementById('profileFile');
  const statusEl = document.getElementById('profileUploadStatus');

  if (uploadBtn) {
    uploadBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (!currentUser || currentUser.username !== 'ddavyd') return;

      const yearEl = document.getElementById('profileYear');
      const monthEl = document.getElementById('profileMonth');
      if (!yearEl || !monthEl || !select) return;

      const year = parseInt(yearEl.value, 10);
      const month = parseInt(monthEl.value, 10);
      const targetUsername = select.value;

      if (!fileInput.files.length) {
        if (statusEl) statusEl.textContent = 'Выберите файл';
        return;
      }

      const fd = new FormData();
      fd.append('year', String(year));
      fd.append('month', String(month));
      fd.append('username', targetUsername);
      fd.append('file', fileInput.files[0]);

      if (statusEl) statusEl.textContent = 'Загрузка...';

      try {
        const res = await fetch(`${API_BASE}/profile_upload.php`, {
          method: 'POST',
          body: fd,
          credentials: 'include'
        });
        const data = await safeJson(res);
        if (!res.ok || !data.ok) {
          if (statusEl) statusEl.textContent = data.error || 'Ошибка загрузки';
          return;
        }
        if (statusEl) statusEl.textContent = 'Файл загружен';
        loadProfileImage();
      } catch (e2) {
        if (statusEl) statusEl.textContent = 'Ошибка соединения';
      }
    });
  }

  if (deleteBtn) {
    deleteBtn.addEventListener('click', async (e) => {
      e.preventDefault();
      e.stopPropagation();

      if (!currentUser || currentUser.username !== 'ddavyd') return;

      const yearEl = document.getElementById('profileYear');
      const monthEl = document.getElementById('profileMonth');
      if (!yearEl || !monthEl || !select) return;

      const year = parseInt(yearEl.value, 10);
      const month = parseInt(monthEl.value, 10);
      const targetUsername = select.value;

      if (!confirm('Удалить файл для выбранного сотрудника и месяца?')) return;

      try {
        const res = await fetch(`${API_BASE}/profile_delete.php`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ year, month, username: targetUsername }),
          credentials: 'include'
        });
        const data = await safeJson(res);
        if (!res.ok || !data.ok) {
          alert(data.error || 'Ошибка удаления');
          return;
        }
        if (statusEl) statusEl.textContent = 'Файл удалён';
        loadProfileImage();
      } catch (e2) {
        alert('Ошибка соединения');
      }
    });
  }
}

async function loadProfileImage() {
    return; // TEMP: отключено, пока нет /api/profile_get.php
  const container = document.getElementById('profileImageContainer');
  const yearEl = document.getElementById('profileYear');
  const monthEl = document.getElementById('profileMonth');
  if (!container || !yearEl || !monthEl || !currentUser) return;

  const year = parseInt(yearEl.value, 10);
  const month = parseInt(monthEl.value, 10);
  if (!year || !month) return;

  const username = getProfileTargetUsername();
  if (!username) return;

  container.textContent = 'Загрузка...';

  const params = new URLSearchParams();
  params.set('year', String(year));
  params.set('month', String(month));
  if (currentUser.username === 'ddavyd') params.set('username', username);

  try {
    const res = await fetch(`${API_BASE}/profile_get.php?` + params.toString(), { credentials: 'include' });
    const data = await safeJson(res);
    container.innerHTML = '';
    if (data.exists && data.url) {
      const img = document.createElement('img');
      img.src = data.url + '?v=' + Date.now();
      img.alt = 'Файл';
      img.className = 'profile-image';
      container.appendChild(img);
    } else {
      const p = document.createElement('div');
      p.textContent = 'Файл не загружен';
      p.className = 'small-info';
      container.appendChild(p);
    }
  } catch (e) {
    container.textContent = 'Ошибка загрузки';
  }
}

// Расписание на день (FINAL: ds-namespace)

(function(){
  const btnOpen  = document.getElementById('btnDaySchedule');
  const modal    = document.getElementById('dayScheduleModal');
  const btnClose = document.getElementById('dayScheduleClose');
  const inpDate  = document.getElementById('dayScheduleDate');
  const btnLoad  = document.getElementById('dayScheduleLoad');
  const box      = document.getElementById('dayScheduleBox');

  function esc(s){
    return String(s).replace(/[&<>"']/g, m => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
    }[m]));
  }

  async function getTodayIso() {
    try {
      const r = await fetch('/api/today.php', {credentials:'same-origin'});
      const j = await r.json();
      if (j && j.today) return j.today;
    } catch(e) {}
    const d = new Date();
    const pad = n => String(n).padStart(2,'0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
  }

 function buildHoursBar(){
    // 24 часа: 06..23,00..05
    const hours = [];
    let h = 6;
    for (let i=0;i<24;i++){
      hours.push(String(h).padStart(2,'0'));
      h = (h+1)%24;
    }

    // ВАЖНО: 1 подпись на 1 час (занимает ширину hourbox = 2 клетки)
    return `
      <div class="ds-line ds-line--hours">
        <div class="ds-hourlabels">
          ${hours.map(hh => `<div class="ds-hourlabel">${hh}</div>`).join('')}
        </div>
      </div>
    `;
  }


  function renderTable(payload){
    const rows = payload.rows || [];
    if (!rows.length) {
      box.innerHTML = `<div class="ds-empty">Нет данных на выбранную дату.</div>`;
      return;
    }

    box.innerHTML = `
      <table class="ds-tbl">
        <thead>
          <tr>
            <th class="ds-col-emp">Сотрудник</th>
            <th class="ds-col-status">Статус</th>
            <th class="ds-col-time">
              <div class="ds-timehead">
                <div class="ds-timehead-title">Время (06:00–05:00)</div>
                <div class="ds-timewrap ds-timewrap--hours">${buildHoursBar()}</div>
              </div>
            </th>
            <th class="ds-col-hours">Часы за день</th>
          </tr>
        </thead>
        <tbody>
          ${rows.map(r => `
            <tr>
              <td class="ds-col-emp">${esc(r.name)}</td>
              <td class="ds-col-status">${esc(r.status)}</td>
              <td class="ds-col-time">
                <div class="ds-timewrap">${r.time_html || ''}</div>
              </td>
              <td class="ds-col-hours">${Number(r.day_hours || 0).toFixed(1)}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
  }

  async function loadDay(){
    const date = inpDate.value;
    if (!date) return;

    box.innerHTML = `<div class="ds-loading">Загрузка…</div>`;

    const r = await fetch(`/api/schedule_day_get.php?date=${encodeURIComponent(date)}`, {credentials:'same-origin'});
    const j = await r.json();

    if (!r.ok || j.error) {
      box.innerHTML = `<div class="ds-error">Ошибка: ${esc(j.details || j.error || 'unknown')}</div>`;
      return;
    }

    renderTable(j);
  }

  btnOpen?.addEventListener('click', async () => {
    modal.style.display = 'flex';
    if (!inpDate.value) inpDate.value = await getTodayIso();
    loadDay();
  });

  btnClose?.addEventListener('click', () => modal.style.display = 'none');
  modal?.addEventListener('click', (e) => { if (e.target === modal) modal.style.display = 'none'; });

  btnLoad?.addEventListener('click', loadDay);
  inpDate?.addEventListener('change', loadDay);
})();





(function () {
  const KEY = "app_version";
  const CHECK_EVERY_MS = 60 * 1000; // раз в минуту (можешь 5 мин поставить)

  async function getServerVersion() {
    const r = await fetch("/api/app_version.php", { cache: "no-store" });
    if (!r.ok) throw new Error("version_fetch_failed");
    const j = await r.json();
    return String(j.version || "0");
  }

  function showUpdateBanner(serverVer) {
    // простая UI-плашка без зависимостей
    let el = document.getElementById("appUpdateBanner");
    if (el) return;

    el = document.createElement("div");
    el.id = "appUpdateBanner";
    el.style.cssText = `
      position:fixed; left:12px; right:12px; bottom:12px;
      z-index:99999; padding:12px 14px; border-radius:12px;
      background:#111; color:#fff; display:flex; gap:10px;
      align-items:center; justify-content:space-between;
      box-shadow:0 10px 25px rgba(0,0,0,.25);
      font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;
    `;
    el.innerHTML = `
      <div style="line-height:1.25">
        <div style="font-weight:700">Доступно обновление</div>
        <div style="opacity:.85; font-size:13px">Версия: ${serverVer}</div>
      </div>
      <div style="display:flex; gap:8px; align-items:center">
        <button id="appUpdateNowBtn" style="padding:8px 10px;border-radius:10px;border:0;cursor:pointer;font-weight:700">Обновить</button>
        <button id="appUpdateCloseBtn" style="padding:8px 10px;border-radius:10px;border:0;cursor:pointer;opacity:.8">Позже</button>
      </div>
    `;
    document.body.appendChild(el);

    document.getElementById("appUpdateNowBtn").onclick = () => forceRefresh();
    document.getElementById("appUpdateCloseBtn").onclick = () => el.remove();
  }

  async function forceRefresh() {
    // мягкая “чистка” на устройстве: caches + storage (по желанию)
    try {
      if (window.caches && caches.keys) {
        const keys = await caches.keys();
        await Promise.all(keys.map(k => caches.delete(k)));
      }
    } catch (e) {}

    // ВАЖНО: обычно localStorage трогать не надо (иначе слетят настройки/сессии)
    // Но можно удалить только "служебные" ключи:
    try {
      localStorage.removeItem(KEY);
      // если есть другие ключи кэша — удаляй точечно
      // localStorage.removeItem("some_cache_key");
    } catch (e) {}

    // Принудительный reload (браузер всё равно может взять из кэша HTML),
    // поэтому добавляем cache-bust параметр:
    const u = new URL(location.href);
    u.searchParams.set("_v", String(Date.now()));
    location.replace(u.toString());
  }

  async function checkVersion() {
  try {
    const serverVer = await getServerVersion();
    const localVer = (localStorage.getItem(KEY) || "").trim();

    // первый запуск на устройстве — просто запоминаем и выходим
    if (!localVer) {
      localStorage.setItem(KEY, serverVer);
      return;
    }

    // если версия на сервере другая — показываем баннер
    if (localVer !== serverVer) {
      showUpdateBanner(serverVer);
      return;
    }

    // совпало — ничего не делаем
  } catch (e) {}
}


  // старт
  checkVersion();
  setInterval(checkVersion, CHECK_EVERY_MS);

  // экспортируем функцию на кнопку “Сброс кэша” в админке
  window.PLANNING_FORCE_REFRESH = forceRefresh;
})();

